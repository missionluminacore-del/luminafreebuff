import { createApp } from './app'
import type { Env } from './auth'

const app = createApp()

export default {
  async fetch(
    request: Request,
    env: Env,
    ctx: ExecutionContext,
  ): Promise<Response> {
    return app.fetch(request, env, ctx)
  },
}
