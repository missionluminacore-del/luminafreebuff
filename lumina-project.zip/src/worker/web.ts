/**
 * Live answers for the free tier.
 *
 * Gemini's own Google Search tool is not available on a free API key (it
 * answers 429), so Lumina gathers fresh information itself: web results,
 * recent headlines, and direct readings for weather and crypto prices.
 * No API keys, no extra services.
 */

export type WebSource = {
  title: string
  url: string
  /** Short excerpt, or the outlet and publish time for news items. */
  snippet: string
  /** Epoch ms for news items, so stale headlines can be dropped. */
  published?: number
}

export type WebContext = {
  query: string
  sources: WebSource[]
}

const USER_AGENT =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36'
const LOOKUP_TIMEOUT_MS = 5_000
const MAX_SOURCES = 6
const NEWS_MAX_AGE_MS = 60 * 24 * 60 * 60 * 1000
/** A repeat of the same question does not hit the search engines again. */
const CACHE_TTL_MS = 90_000
const CACHE_MAX = 40

const NEWS_HINTS =
  /\b(news|headlines?|today|tonight|yesterday|latest|breaking|won|winner|score|scores|results?|match|fixtures|standings|election|announce[sd]?|released?|launch(?:ed)?|this (?:week|month|year))\b/i

/** Greetings, thanks and small talk: there is nothing to look up. */
const SOCIAL =
  /^(?:hi|hey|hello|yo|sup|hiya|good (?:morning|afternoon|evening|night)|thanks|thank you|thx|ty|ok|okay|k|cool|nice|great|perfect|lol|haha|yes|yeah|no|nope|sure|bye|see you|how are you|what'?s up|how'?s it going)\b/i

/** The searchable part of a message: no "hey, can you look up…" scaffolding. */
export function searchQuery(text: string): string {
  return text
    .replace(/https?:\/\/\S+/gi, ' ')
    .replace(
      /^\s*(?:hey|hi|hello|ok|okay|please|so)?[\s,]*(?:can|could|would|will) you\s+/i,
      '',
    )
    .replace(
      /^\s*(?:please\s+)?(?:search|look\s*up|google|find|check)(?:\s+(?:for|on|about|the web))?\s*/i,
      '',
    )
    .replace(
      /\b(?:explain|describe|define|definition|meaning of|tell me about|in simple terms|simply|exactly)\b/gi,
      ' ',
    )
    .replace(/\b(?:what|whats|what's|who|when|where|why|how)\b\s+(?:is|are|was|were|does|do|did)\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[?!.]+$/, '')
    .slice(0, 240)
}

/** A dictionary page is never the answer unless the question is a definition. */
const DICTIONARY =
  /(?:^|\.)(?:merriam-webster|dictionary|cambridge|collinsdictionary|thesaurus|wiktionary|vocabulary|wordreference)\.com/i
const WANTS_DEFINITION =
  /\b(?:meaning|definition|define|synonym|spell(?:ing)?|pronounce|what does .* mean)\b/i

const ENTITIES: Record<string, string> = {
  amp: '&',
  lt: '<',
  gt: '>',
  quot: '"',
  apos: "'",
  nbsp: ' ',
  hellip: '…',
  mdash: '—',
  ndash: '–',
  rsquo: '’',
  lsquo: '‘',
  ldquo: '“',
  rdquo: '”',
}

const textOf = (html: string): string =>
  html
    .replace(/<[^>]*>/g, ' ')
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) =>
      String.fromCodePoint(Number.parseInt(hex, 16)),
    )
    .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code)))
    .replace(/&([a-z]+);/gi, (whole, name: string) => ENTITIES[name] ?? whole)
    // Feeds often carry escaped markup in a description, which only becomes
    // real tags after the entities above are decoded. Strip it again or the
    // model reads `<a href=...` as part of the headline.
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 320)

/** Search pages escape ampersands inside hrefs, which breaks URL parsing. */
const hrefOf = (html: string): string =>
  html.trim().replace(/&amp;/g, '&').replace(/&#38;/g, '&')

const safeUrl = (value: string): string | null => {
  if (!value.trim()) return null
  try {
    const url = new URL(hrefOf(value), 'https://duckduckgo.com')
    return url.protocol === 'https:' || url.protocol === 'http:'
      ? url.toString()
      : null
  } catch {
    return null
  }
}

/** DuckDuckGo wraps every result in a /l/?uddg= redirect. */
const unwrapDuckDuckGo = (href: string): string | null => {
  try {
    const url = new URL(hrefOf(href), 'https://duckduckgo.com')
    const target = url.searchParams.get('uddg')
    if (target) return safeUrl(target)
    return url.hostname.endsWith('duckduckgo.com') ? null : safeUrl(url.toString())
  } catch {
    return null
  }
}

/** Bing wraps every result in a /ck/a?…&u=a1<base64> redirect. */
const unwrapBing = (href: string): string | null => {
  const clean = hrefOf(href)
  if (!/bing\.com\/ck\/a/i.test(clean)) return safeUrl(clean)
  try {
    const target = new URL(clean, 'https://www.bing.com').searchParams.get('u')
    if (!target?.startsWith('a1')) return null
    const base64 = target.slice(2).replace(/-/g, '+').replace(/_/g, '/')
    return safeUrl(atob(base64))
  } catch {
    return null
  }
}

function parseDuckDuckGo(html: string): WebSource[] {
  const links = [
    ...html.matchAll(
      /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g,
    ),
  ]
  const snippets = [
    ...html.matchAll(
      /<(?:a|div)[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/(?:a|div)>/g,
    ),
  ]
  const out: WebSource[] = []
  links.forEach((link, index) => {
    const url = unwrapDuckDuckGo(link[1] ?? '')
    const title = textOf(link[2] ?? '')
    if (!url || !title) return
    out.push({ title, url, snippet: textOf(snippets[index]?.[1] ?? '') })
  })
  return out
}

function parseBingRss(xml: string): WebSource[] {
  const out: WebSource[] = []
  for (const item of xml.matchAll(/<item>([\s\S]*?)<\/item>/g)) {
    const body = item[1] ?? ''
    const title = rssTag(body, 'title')
    const url = safeUrl(rssTag(body, 'link'))
    if (!title || !url || /(^|\.)bing\.com$/i.test(new URL(url).hostname))
      continue
    out.push({ title, url, snippet: rssTag(body, 'description') })
    if (out.length === 6) break
  }
  return out
}

function parseBing(html: string): WebSource[] {
  const out: WebSource[] = []
  for (const block of html.split('class="b_algo"').slice(1, 9)) {
    const heading =
      /<h2[^>]*>[\s\S]*?<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i.exec(block)
    if (!heading) continue
    const url = unwrapBing(heading[1] ?? '')
    const title = textOf(heading[2] ?? '')
    if (!url || !title) continue
    const snippet = /<p[^>]*>([\s\S]*?)<\/p>/i.exec(block)
    out.push({ title, url, snippet: textOf(snippet?.[1] ?? '') })
  }
  return out
}

const rssTag = (xml: string, tag: string): string => {
  const match = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i').exec(xml)
  return match ? textOf(match[1] ?? '') : ''
}

function parseNews(xml: string): WebSource[] {
  const out: WebSource[] = []
  for (const item of xml.matchAll(/<item>([\s\S]*?)<\/item>/g)) {
    const body = item[1] ?? ''
    const title = rssTag(body, 'title')
    const link = safeUrl(rssTag(body, 'link'))
    if (!title || !link) continue
    const outlet = rssTag(body, 'source')
    const published = rssTag(body, 'pubDate')
    const when = published ? new Date(published) : null
    const time =
      when && !Number.isNaN(when.getTime()) ? when.getTime() : undefined
    // The article link, not the outlet's front page: a homepage is never the
    // answer, and every front page ranks equally badly. The outlet name still
    // travels in the snippet.
    const cleanTitle =
      outlet && title.endsWith(` - ${outlet}`)
        ? title.slice(0, -(outlet.length + 3)).trim()
        : title
    // The feed's own summary is real sentences about the story; without it a
    // headline is all the model gets, and a headline alone is not an answer.
    const summary = rssTag(body, 'description').slice(0, 220)
    out.push({
      title: cleanTitle,
      url: link,
      snippet: [
        outlet,
        time ? new Date(time).toUTCString() : published,
        summary,
      ]
        .filter(Boolean)
        .join(' · '),
      published: time,
    })
    if (out.length === 6) break
  }
  return out
}

async function fetchText(url: string, signal: AbortSignal): Promise<string> {
  const response = await fetch(url, {
    headers: {
      'user-agent': USER_AGENT,
      'accept-language': 'en-US,en;q=0.9',
      accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    },
    signal,
  })
  if (!response.ok) throw new Error(`Search responded ${response.status}`)
  return response.text()
}

async function generalSearch(
  query: string,
  signal: AbortSignal,
): Promise<WebSource[]> {
  const encoded = encodeURIComponent(query)
  // Bing's RSS view is small, clean and free of redirect links.
  try {
    const xml = await fetchText(
      `https://www.bing.com/search?q=${encoded}&format=rss&setlang=en-us&cc=US`,
      signal,
    )
    const results = parseBingRss(xml)
    if (results.length >= 2) return results.slice(0, 5)
  } catch {
    // Fall through to the HTML search engines.
  }
  try {
    const html = await fetchText(
      `https://www.bing.com/search?q=${encoded}&setlang=en-us&cc=US`,
      signal,
    )
    const results = parseBing(html)
    if (results.length >= 2) return results.slice(0, 5)
  } catch {
    // Fall through to DuckDuckGo.
  }
  try {
    const html = await fetchText(
      `https://html.duckduckgo.com/html/?q=${encoded}`,
      signal,
    )
    const results = parseDuckDuckGo(html)
    if (results.length) return results.slice(0, 5)
  } catch {
    // Fall through to Wikipedia.
  }
  return wikipediaSearch(query, signal)
}

/**
 * The reliable last resort. Search engines sometimes answer a datacenter IP
 * with nothing or with junk; Wikipedia's API always answers, and its summaries
 * are a solid base for "who/what/where" questions.
 */
async function wikipediaSearch(
  query: string,
  signal: AbortSignal,
): Promise<WebSource[]> {
  const headers = {
    accept: 'application/json',
    'user-agent': USER_AGENT,
  }
  try {
    const search = await fetch(
      `https://en.wikipedia.org/w/api.php?action=query&format=json&list=search&srlimit=2&srsearch=${encodeURIComponent(
        query,
      )}`,
      { headers, signal },
    )
    if (!search.ok) return []
    const data = (await search.json().catch(() => null)) as {
      query?: { search?: { title?: string }[] }
    } | null
    const titles = (data?.query?.search ?? [])
      .map((hit) => hit.title)
      .filter((title): title is string => Boolean(title))
      .slice(0, 2)
    const pages = await Promise.all(
      titles.map(async (title): Promise<WebSource | null> => {
        const page = await fetch(
          `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(
            title,
          )}`,
          { headers, signal },
        )
        if (!page.ok) return null
        const summary = (await page.json().catch(() => null)) as {
          title?: string
          extract?: string
          content_urls?: { desktop?: { page?: string } }
        } | null
        if (!summary?.title || !summary.extract) return null
        return {
          title: `Wikipedia · ${summary.title}`,
          url:
            summary.content_urls?.desktop?.page ??
            `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}`,
          snippet: summary.extract.replace(/\s+/g, ' ').slice(0, 300),
        }
      }),
    )
    return pages.filter((page): page is WebSource => page !== null)
  } catch {
    return []
  }
}

/**
 * Two independent news feeds, because one of them is regularly unreachable
 * from a datacenter address: Google News answers a worker with an empty or
 * blocked response often enough that a single feed silently downgraded every
 * "what's the latest" question to a vendor's front page.
 */
async function newsSearch(
  query: string,
  signal: AbortSignal,
): Promise<WebSource[]> {
  const encoded = encodeURIComponent(query)
  const feeds = [
    `https://news.google.com/rss/search?q=${encoded}&hl=en-US&gl=US&ceid=US:en`,
    `https://www.bing.com/news/search?q=${encoded}&format=rss&setlang=en-us&cc=US`,
  ]
  for (const feed of feeds) {
    try {
      const xml = await fetchText(feed, signal)
      const items = parseNews(xml)
        .filter(
          (item) =>
            item.published === undefined ||
            Date.now() - item.published < NEWS_MAX_AGE_MS,
        )
        .sort((a, b) => (b.published ?? 0) - (a.published ?? 0))
      if (items.length) return items
    } catch {
      // Try the next feed.
    }
  }
  return []
}

const WMO: Record<number, string> = {
  0: 'clear sky',
  1: 'mostly clear',
  2: 'partly cloudy',
  3: 'overcast',
  45: 'fog',
  48: 'freezing fog',
  51: 'light drizzle',
  53: 'drizzle',
  55: 'heavy drizzle',
  56: 'freezing drizzle',
  57: 'freezing drizzle',
  61: 'light rain',
  63: 'rain',
  65: 'heavy rain',
  66: 'freezing rain',
  67: 'freezing rain',
  71: 'light snow',
  73: 'snow',
  75: 'heavy snow',
  77: 'snow grains',
  80: 'light showers',
  81: 'showers',
  82: 'heavy showers',
  85: 'snow showers',
  86: 'heavy snow showers',
  95: 'thunderstorm',
  96: 'thunderstorm with hail',
  99: 'thunderstorm with heavy hail',
}

const WEATHER_HINT =
  /\b(weather|forecast|temperature|how (?:hot|cold|warm)|rain|snowing|humidity|windy)\b/i

const WEATHER_NOISE =
  /\b(what|whats|how|hows|is|it|its|the|a|an|weather|forecast|temperature|temp|like|today|tonight|tomorrow|this|week|weekend|right|now|currently|outside|there|in|at|for|of|and|please|tell|me|give|show|check|update|say|going|to|be|do|does|current|can|you|there)\b/gi

/** "what's the weather in New York today?" -> "New York" */
const weatherPlace = (text: string): string =>
  text
    .replace(/['’]/g, '')
    .replace(/[?!.,]/g, ' ')
    .replace(WEATHER_NOISE, ' ')
    .replace(/\b[a-z]\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 60)

type Place = { name: string; country?: string; admin1?: string; latitude: number; longitude: number; timezone?: string }

/** Exact weather from Open-Meteo; no key, no location permission needed. */
async function weatherLookup(
  text: string,
  signal: AbortSignal,
): Promise<WebSource[]> {
  if (!WEATHER_HINT.test(text)) return []
  const place = weatherPlace(text)
  if (place.length < 2) return []
  const geo = await fetch(
    `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
      place,
    )}&count=1&language=en&format=json`,
    { signal },
  )
  if (!geo.ok) return []
  const found = (await geo.json().catch(() => null)) as {
    results?: Place[]
  } | null
  const spot = found?.results?.[0]
  if (!spot) return []
  const forecast = await fetch(
    `https://api.open-meteo.com/v1/forecast?latitude=${spot.latitude}&longitude=${spot.longitude}` +
      '&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m' +
      '&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=2',
    { signal },
  )
  if (!forecast.ok) return []
  const data = (await forecast.json().catch(() => null)) as {
    current?: {
      time?: string
      temperature_2m?: number
      apparent_temperature?: number
      relative_humidity_2m?: number
      weather_code?: number
      wind_speed_10m?: number
    }
    current_units?: Record<string, string>
    daily?: {
      time?: string[]
      temperature_2m_max?: number[]
      temperature_2m_min?: number[]
      precipitation_probability_max?: number[]
    }
  } | null
  const now = data?.current
  if (!now || typeof now.temperature_2m !== 'number') return []
  const unit = data?.current_units?.temperature_2m ?? '°C'
  const condition = WMO[now.weather_code ?? -1] ?? 'unknown conditions'
  const parts = [
    `Now ${Math.round(now.temperature_2m)}${unit}${
      typeof now.apparent_temperature === 'number'
        ? ` (feels like ${Math.round(now.apparent_temperature)}${unit})`
        : ''
    }, ${condition}`,
    typeof now.relative_humidity_2m === 'number'
      ? `humidity ${Math.round(now.relative_humidity_2m)}%`
      : '',
    typeof now.wind_speed_10m === 'number'
      ? `wind ${Math.round(now.wind_speed_10m)} km/h`
      : '',
  ].filter(Boolean)
  const days = data?.daily
  const todayMax = days?.temperature_2m_max?.[0]
  const todayMin = days?.temperature_2m_min?.[0]
  const rain = days?.precipitation_probability_max?.[0]
  if (typeof todayMax === 'number' && typeof todayMin === 'number')
    parts.push(`today ${Math.round(todayMax)}/${Math.round(todayMin)}${unit}`)
  if (typeof rain === 'number') parts.push(`rain chance ${Math.round(rain)}%`)
  const where = [spot.name, spot.admin1, spot.country].filter(Boolean).join(', ')
  return [
    {
      title: `Live weather · ${where}`,
      url: `https://open-meteo.com/`,
      snippet: `${parts.join(', ')}. Measured ${now.time ?? 'now'} local time${
        spot.timezone ? ` (${spot.timezone})` : ''
      }.`,
    },
  ]
}

const COINS: [RegExp, string, string][] = [
  [/\bbitcoin|\bbtc\b/i, 'bitcoin', 'Bitcoin'],
  [/\bethereum|\beth\b/i, 'ethereum', 'Ethereum'],
  [/\bsolana|\bsol\b/i, 'solana', 'Solana'],
  [/\bdogecoin|\bdoge\b/i, 'dogecoin', 'Dogecoin'],
  [/\bripple|\bxrp\b/i, 'ripple', 'XRP'],
  [/\bcardano|\bada\b/i, 'cardano', 'Cardano'],
  [/\bbnb\b|binance coin/i, 'binancecoin', 'BNB'],
  [/\btoncoin\b|\bton\b/i, 'the-open-network', 'Toncoin'],
  [/\blitecoin|\bltc\b/i, 'litecoin', 'Litecoin'],
  [/\bchainlink|\blink\b/i, 'chainlink', 'Chainlink'],
  [/\bavalanche|\bavax\b/i, 'avalanche-2', 'Avalanche'],
]

const PRICE_HINT =
  /\b(price|worth|rate|how much|cost|trading at|value)\b/i

/** Live crypto prices from CoinGecko; no key needed. */
async function priceLookup(
  text: string,
  signal: AbortSignal,
): Promise<WebSource[]> {
  if (!PRICE_HINT.test(text)) return []
  const coins = COINS.filter(([pattern]) => pattern.test(text)).slice(0, 3)
  if (!coins.length) return []
  const currency = /\b(inr|rupees?|₹)\b/i.test(text)
    ? 'inr'
    : /\b(eur|euros?|€)\b/i.test(text)
      ? 'eur'
      : /\b(gbp|pounds?|£)\b/i.test(text)
        ? 'gbp'
        : 'usd'
  const response = await fetch(
    `https://api.coingecko.com/api/v3/simple/price?ids=${coins
      .map(([, id]) => id)
      .join(',')}&vs_currencies=${currency}&include_24hr_change=true`,
    { headers: { accept: 'application/json' }, signal },
  )
  if (!response.ok) return []
  const data = (await response.json().catch(() => null)) as Record<
    string,
    Record<string, number>
  > | null
  if (!data) return []
  const symbol = currency.toUpperCase()
  const out: WebSource[] = []
  for (const [, id, label] of coins) {
    const row = data[id]
    const price = row?.[currency]
    if (typeof price !== 'number') continue
    const change = row?.[`${currency}_24h_change`]
    const amount =
      price >= 100
        ? price.toLocaleString('en-US', { maximumFractionDigits: 0 })
        : price.toLocaleString('en-US', { maximumFractionDigits: 2 })
    out.push({
      title: `Live price · ${label}`,
      url: `https://www.coingecko.com/en/coins/${id}`,
      snippet: `${label} is ${symbol} ${amount}${
        typeof change === 'number'
          ? `, ${change >= 0 ? 'up' : 'down'} ${Math.abs(change).toFixed(2)}% in 24h`
          : ''
      }. Read from CoinGecko at ${new Date().toUTCString()}.`,
    })
  }
  return out
}

const cache = new Map<string, { at: number; value: WebContext | null }>()

/** "and tomorrow?", "what about him?" — meaningless without the last turn. */
const FOLLOW_UP =
  /^(?:and|also|then|so|but|what about|how about|what'?s? (?:the|that|this|it)|who|when|where|why|how much|is it|are they|did (?:they|he|she|it)|does it|do they)\b/i

/**
 * A correction or a preference is an instruction, not a lookup: searching
 * "keep every answer to two lines" once returned pages about Max Payne.
 */
/** "what is 17 times 23" is arithmetic, not a lookup. */
const ARITHMETIC =
  /^(?:[\d\s.,]+)(?:[+\-*/×÷^%]|\b(?:times|plus|minus|divided by|multiplied by|over|percent of|squared|cubed)\b)(?:[\d\s.,]+)+$/i

const CORRECTION =
  /\b(?:from now on|keep (?:it|your answers?|every answer|answers?)|be (?:shorter|brief|concise)|stop (?:using|being|saying|with)|always (?:answer|use|say|reply)|never (?:say|use|do that)|don'?t (?:use|say|explain)|no more)\b/i

/**
 * Words that only hurt a search. Chatty noise is here too: searching "wow".
 * "did not check the web" once produced a page about OMD the band, so the
 * filler has to go before a query is built.
 */
const NOISE = new Set([
  'a', 'about', 'again', 'actually', 'also', 'an', 'and', 'any', 'are', 'as',
  'at', 'be', 'been', 'bro', 'but', 'by', 'can', 'check', 'checked', 'could',
  'did', 'do', 'does', 'doing', 'dude', 'else', 'even', 'ever', 'for', 'from',
  'give', 'go', 'gonna', 'got', 'had', 'happen', 'happened', 'happening', 'has',
  'have', 'he', 'her', 'here', 'him',
  'his', 'how', 'i', 'if', 'im', 'in', 'into', 'is', 'it', 'its', 'just', 'know',
  'let', 'like', 'lol', 'man', 'mate', 'may', 'me', 'might', 'more', 'most', 'my',
  'need', 'no', 'not', 'now', 'of', 'ok', 'okay', 'omd', 'omg', 'on', 'or', 'our',
  'out', 'please', 'pls', 'really', 'right', 'say', 'see', 'she', 'should', 'show',
  'so', 'some', 'something', 'sorry', 'still', 'such', 'tell', 'than', 'thank',
  'thanks', 'that', 'the', 'their', 'them', 'then', 'there', 'these', 'they',
  'thing', 'things', 'think', 'this', 'those', 'to', 'too', 'u', 'up', 'ur', 'us',
  'use', 'very', 'want', 'was', 'way', 'we', 'well', 'were', 'what', 'whats',
  'when', 'where', 'which', 'while', 'who', 'why', 'will', 'with', 'wont', 'would',
  'wrong', 'wtf', 'wow', 'yeah', 'yes', 'you', 'your', 'yours',
])

/** Time words describe when, not what, so a follow-up can borrow the topic. */
const TIME_ONLY = new Set([
  'today', 'tomorrow', 'tonight', 'yesterday', 'now', 'week', 'weekend',
  'morning', 'evening', 'later', 'next', 'this', 'last',
])

/**
 * "latest news on nvidia" searched as "latest news nvidia" returns the front
 * pages of every news site, because those pages carry the words "latest" and
 * "news" in their titles. The generic half of a question is dropped when the
 * question also names something, so the search is about the subject.
 */
const GENERIC = new Set([
  'news', 'latest', 'breaking', 'headline', 'headlines', 'update', 'updates',
  'date', 'dated', 'newest', 'recent', 'item', 'items', 'story', 'stories',
  'give', 'new', 'happening', 'going', 'say', 'says', 'said',
])

/** Tickers people type instead of the company name. */
const TICKERS: Record<string, string> = {
  nvda: 'nvidia',
  aapl: 'apple',
  msft: 'microsoft',
  tsla: 'tesla',
  amzn: 'amazon',
  googl: 'google',
  goog: 'google',
  meta: 'meta',
  amd: 'amd',
  intc: 'intel',
  nflx: 'netflix',
}

/**
 * A request about the assistant itself, or about how something is worded, is
 * not a lookup. "Confirm you have the JARVIS manner and the date" once searched
 * for a shipping company called ONE. This is deliberately narrow: "what do you
 * think of the new act" is a question about the world and must still search.
 */
const META =
  /\b(?:confirm|say hello|who are you|what can you do|your (?:manner|name|voice|purpose))\b/i

/** Personal facts live in notes and rules, never in a search engine. */
const PERSONAL =
  /\b(?:my|our)\s+(?:birthday|bday|name|age|address|phone|number|email|salary|home|family|kids?|job|city|notes?)\b|\bwhat do you (?:remember|know) about me\b|\bhow old am i\b|\bwhere do i live\b|\bwho am i\b|\bwhat do i do for a living\b/i

/** The words actually worth searching for, with tickers spelled out. */
export function keywordsOf(text: string): string[] {
  const words = text
    .toLowerCase()
    .replace(/['’]/g, '')
    .split(/[^a-z0-9.]+/)
    .filter((word) => word.length > 1 && word !== '.' && !NOISE.has(word))
    .map((word) => TICKERS[word] ?? word)
  const specific = words.filter((word) => !GENERIC.has(word))
  return specific.length ? specific : words
}

/**
 * "and tomorrow?" borrows the topic of the last message; "what about the
 * weather in Paris?" keeps its own words and leaves the old topic behind.
 */
function queryFor(text: string, context: string): string {
  const own = keywordsOf(text).filter((word) => !TIME_ONLY.has(word))
  if (own.length) return own.join(' ').slice(0, 240)
  const carried = context ? keywordsOf(searchQuery(context)) : []
  return carried.join(' ').slice(0, 240)
}

/**
 * Fresh results for one message, or null when nothing useful came back.
 *
 * This runs on every turn, not only on "what's the news" turns: the model can
 * then answer from the world as it is now. Recent repeats are served from a
 * short-lived cache so typing fast never queues behind the search engines.
 *
 * `context` is the previous message, folded into short follow-up questions so
 * "and tomorrow?" searches the topic instead of the word "tomorrow".
 */
export async function lookupWeb(
  text: string,
  context = '',
  /** Skip the intent guesses: the caller already decided this needs the web. */
  force = false,
  timeoutMs = LOOKUP_TIMEOUT_MS,
): Promise<WebContext | null> {
  const asked = searchQuery(text)
  if (asked.length < 3) return null
  if (!force) {
    if (SOCIAL.test(asked) && asked.length <= 24) return null
    // "when is my birthday" is a memory question, not a search.
    if (PERSONAL.test(text)) return null
    // A question about the assistant, or about wording, needs no sources.
    if (META.test(text)) return null
  }
  if (!keywordsOf(asked).length) return null
  // "WOW", "omd u did not check the web" — a reaction, not a question. A wh
  // word anywhere in the message still counts, so "bro nvda ceo what happen"
  // searches instead of being waved off as chatter.
  const asks =
    /\?/.test(asked) ||
    /\b(?:who|what|when|where|why|how|which|whose)\b/i.test(asked)
  if (!force) {
    if (ARITHMETIC.test(asked.trim())) return null
    if (CORRECTION.test(text) && !/\?/.test(asked)) return null
  }
  const query = (queryFor(asked, context) || keywordsOf(asked).join(' ')).slice(0, 240)
  if (!query) return null
  const hit = cache.get(query)
  if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.value
  const signal = AbortSignal.timeout(timeoutMs)
  const newsy = NEWS_HINTS.test(text)
  // An exact reading (weather, a price) answers the question on its own, so
  // there is no reason to make the person wait for three search engines.
  const facts = await Promise.all([
    weatherLookup(text, signal),
    priceLookup(text, signal),
  ])
    .then((groups) => groups.flat())
    .catch(() => [])
  // A news feed wants the subject alone; a general engine wants the subject
  // plus the word "news", or it answers with the vendor's own front page.
  const [news, general, wiki] = facts.length
    ? [[], [], []]
    : await Promise.all([
        newsy ? newsSearch(query, signal) : Promise.resolve<WebSource[]>([]),
        generalSearch(newsy ? `${query} news` : query, signal),
        wikipediaSearch(query, signal),
      ])

  const seen = new Set<string>()
  const sources: WebSource[] = []
  // An exact reading (weather, price) beats a page of search results, and an
  // encyclopaedia entry beats a dictionary hit or a content farm.
  const keepDefinition = WANTS_DEFINITION.test(text)
  // Only keep pages that at least mention what was asked. A page about a band
  // called OMD is not an answer about the OMD acronym.
  const terms = new Set(
    query
      .split(' ')
      .map((word) => word.toLowerCase())
      .filter((word) => word.length > 1),
  )
  const onTopic = (source: WebSource): boolean => {
    const hay = `${source.title} ${source.snippet}`.toLowerCase()
    for (const term of terms) if (hay.includes(term)) return true
    return false
  }
  // Best match first: a title that names the thing asked about beats a page
  // that merely mentions it in passing, and an encyclopaedia entry is a last
  // resort for something that may have changed this morning.
  const scoreOf = (source: WebSource): number => {
    const title = source.title.toLowerCase()
    const hay = `${title} ${source.snippet.toLowerCase()}`
    let score = 0
    for (const term of terms) {
      // A word like "news" appears on every front page; the subject is what
      // makes a page the answer.
      const weight = GENERIC.has(term) ? 0.25 : 1
      if (title.includes(term)) score += 2 * weight
      else if (hay.includes(term)) score += weight
    }
    // A site's front page is never the answer to a specific question.
    try {
      const url = new URL(source.url)
      if (url.pathname === '/' || url.pathname === '') score -= 4
    } catch {
      score -= 1
    }
    if (/wikipedia\.org/i.test(source.url)) score -= 0.5
    // Freshness counts when the question asked about now.
    if (source.published && Date.now() - source.published < 48 * 60 * 60 * 1000)
      score += 1.5
    else if (source.published) score += 0.5
    return score
  }
  const found = [...news, ...wiki, ...general]
    .filter(onTopic)
    .sort((a, b) => scoreOf(b) - scoreOf(a))
  const pool = facts.length ? [...facts, ...found] : found
  const filtered = pool.filter(
    (source) => keepDefinition || !DICTIONARY.test(source.url),
  )
  // For anything that moves, a snippet alone is where stale numbers live. The
  // top pages are read properly so the answer rests on the page, not a teaser.
  if (newsy && !facts.length) {
    const pages = filtered
      .filter((source) => !/wikipedia\.org/i.test(source.url))
      .slice(0, 2)
    await Promise.all(
      pages.map(async (source) => {
        const body = await pageText(source.url)
        if (body) source.snippet = `${source.snippet}\n    ${body}`.slice(0, 1_800)
      }),
    )
  }
  for (const source of filtered) {
    const key = `${source.url.replace(/[?#].*$/, '')}|${source.title}`
    if (seen.has(key)) continue
    seen.add(key)
    sources.push(source)
    if (sources.length === MAX_SOURCES) break
  }
  const value = sources.length ? { query, sources } : null
  if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value!)
  cache.set(query, { at: Date.now(), value })
  return value
}

/**
 * A page URL comes from a search result, which is untrusted input. Hostnames
 * that resolve to the machine itself — or to the cloud metadata service — must
 * never be fetched from inside the worker, or a poisoned result could read
 * internal endpoints.
 */
const isPrivateHost = (raw: string): boolean => {
  const host = raw.toLowerCase().replace(/^\[|\]$/g, '').replace(/\.$/, '')
  if (!host) return true
  if (
    host === 'localhost' ||
    host === 'metadata.google.internal' ||
    host.endsWith('.localhost') ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host.endsWith('.localdomain')
  )
    return true
  if (host === '::' || host === '::1' || /^f[cd][0-9a-f]{2}:/.test(host)) return true
  if (/^fe[89ab][0-9a-f]:/.test(host)) return true
  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host)
  if (!v4) return false
  const [a, b] = [Number(v4[1]), Number(v4[2])]
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127)
  )
}

/** Only a public http(s) page is ever fetched on the model's behalf. */
const publicUrl = (value: string): string | null => {
  try {
    const url = new URL(value)
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return null
    if (isPrivateHost(url.hostname)) return null
    return url.toString()
  } catch {
    return null
  }
}

/** Reads at most `limit` bytes, so one enormous page cannot exhaust memory. */
async function readLimited(
  response: Response,
  limit: number,
): Promise<string> {
  if (!response.body) return ''
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let out = ''
  let total = 0
  try {
    while (total < limit) {
      const { done, value } = await reader.read()
      if (done) break
      total += value.byteLength
      out += decoder.decode(value, { stream: true })
    }
  } finally {
    void reader.cancel().catch(() => undefined)
  }
  return out
}

/**
 * Readable text from a page, for the handful of sources that matter on a
 * time-sensitive question. Strips the markup rather than shipping a page of
 * script tags to the model.
 */
async function pageText(url: string): Promise<string> {
  const target = publicUrl(url)
  if (!target) return ''
  try {
    const response = await fetch(target, {
      headers: { 'User-Agent': USER_AGENT, Accept: 'text/html' },
      signal: AbortSignal.timeout(3_500),
      redirect: 'follow',
    })
    if (!response.ok || !/html/i.test(response.headers.get('content-type') ?? ''))
      return ''
    const raw = await readLimited(response, 220_000)
    const cleaned = raw
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<nav[\s\S]*?<\/nav>/gi, ' ')
      .replace(/<footer[\s\S]*?<\/footer>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      // Inline stylesheets and script objects survive tag stripping as
      // `body,html{...}` noise at the top of an otherwise good article.
      .replace(/[^{}\n]{0,120}\{[^{}]*\}/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
    if (cleaned.length < 200) return ''
    return `${cleaned.slice(0, 1_200)}…`
  } catch {
    return ''
  }
}

/** The context block handed to the model. */
export function webPrompt(web: WebContext): string {
  const lines = web.sources.map(
    (source, index) =>
      `[${index + 1}] ${source.title}\n    ${source.url}${
        source.snippet ? `\n    ${source.snippet}` : ''
      }`,
  )
  return `LIVE WEB RESULTS — fetched just now (${new Date().toUTCString()}) for "${web.query}". These snippets are the only fresh evidence for this turn; anything else you say comes from memory and may be out of date.\n${lines.join(
    '\n',
  )}`
}
