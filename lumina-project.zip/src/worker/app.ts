import { Hono, type Handler } from 'hono'
import { bodyLimit } from 'hono/body-limit'
import {
  defaultSettings,
  normalizeSettings,
  type AiStatus,
  type ChatMessage,
  type ChatResponse,
  type Conversation,
  type Fact,
  type FactSlot,
  type Memory,
  type MemoryKind,
  type Rule,
  type Settings,
} from '../shared/types'
import {
  AiError,
  PROMPT_VERSION,
  condenseText,
  describeBrain,
  generate,
  generateStream,
  synthesizeSpeech,
  type AiClient,
  type AiKeys,
  type AiMessage,
  type AiSuggestion,
} from './ai'
import { extractFacts, factsFromNote, recallAnswer } from './recall'
import { lookupWeb, type WebContext } from './web'
import {
  attemptLogin,
  clearedSessionCookie,
  currentUser,
  isTrustedMutation,
  issueSession,
  sessionCookie,
  type Env,
  type Viewer,
} from './auth'
import {
  clearApiKey,
  clearFact,
  consolidateMemories,
  ensureSchema,
  isFactSlot,
  mapConversation,
  mapFact,
  mapMemory,
  mapMessage,
  mapRule,
  memoryKey,
  memoryWords,
  readApiKeys,
  ruleKey,
  sameLesson,
  saveApiKey,
  searchPastMessages,
  saveFact,
  similarMemory,
  type ConversationRow,
  type FactRow,
  type MemoryRow,
  type MessageRow,
  type RuleRow,
} from './db'

type AppContext = {
  Bindings: Env
  Variables: { user: Viewer; db: D1Database }
}
type Authenticate = (request: Request, env: Env) => Promise<Viewer | null>
/** The second argument is the previous message; the third forces a lookup. */
type WebLookup = (
  text: string,
  context?: string,
  force?: boolean,
) => Promise<WebContext | null>

/** A pasted document is accepted; only its first turn is condensed. */
const MAX_MESSAGE = 60_000
/** Above this, the message is compressed for the model rather than sent whole. */
const CONDENSE_AT = 3_500
/**
 * A live check may not hold the whole answer hostage. A question about the
 * world gets a real budget — news results plus a page read take a few seconds
 * — while a throwaway remark gets a short one, so the check still happens
 * without stalling the chat.
 */
const WEB_WAIT_MS = 7_000
const QUICK_WAIT_MS = 1_500
/** Messages that plainly want a fact from outside the conversation. */
const WANTS_FACTS =
  /\?|\b(?:who|what|when|where|why|how|which|whose|news|latest|today|tonight|yesterday|price|score|weather|release|stock|election|update|tell me|give me|show me|find|search|look up|explain|compare|summar)\b/i
/** Long conversations stay in view, so a chat no longer "forgets" after 10 min. */
const CONTEXT_MESSAGES = 60
/** Memory that grows past this is de-duplicated before the turn. */
const CONSOLIDATE_AT = 150
const MAX_RULES = 200
const MAX_MEMORIES = 400
/** How many memories reach the prompt on one turn. */
const MEMORIES_IN_PROMPT = 80
const MEMORY_KINDS: MemoryKind[] = ['fact', 'preference', 'note']

/**
 * A lookup may not hold the whole answer hostage. Past this deadline the turn
 * continues without fresh results; the next question can search again.
 */
const settleWithin = <T,>(
  promise: Promise<T | null>,
  ms: number,
): Promise<T | null> =>
  new Promise((resolve) => {
    let settled = false
    const finish = (value: T | null): void => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve(value)
    }
    // The timer is cleared the moment the lookup answers, so a fast search
    // leaves nothing behind holding the worker (or a test run) open.
    const timer = setTimeout(() => finish(null), ms)
    promise.then(finish, () => finish(null))
  })

const titleFrom = (text: string): string => {
  const line = text.split('\n')[0]?.replace(/\s+/g, ' ').trim() ?? ''
  return (line.length > 60 ? `${line.slice(0, 57).trimEnd()}…` : line) || 'New chat'
}

const KEY_PATTERN = /^[A-Za-z0-9._-]{20,200}$/

/** Provider keys are plain tokens; strip a pasted quote pair. */
const cleanApiKey = (value: string): string | null => {
  const key = value
    .trim()
    .replace(/^["'`]/, '')
    .replace(/["'`]$/, '')
  return KEY_PATTERN.test(key) ? key : null
}

const cleanRule = (value: unknown): string | null => {
  if (typeof value !== 'string') return null
  const text = value.replace(/\s+/g, ' ').trim()
  if (text.length < 4 || text.length > 240) return null
  return text
}

const cleanMemory = (value: unknown): string | null => {
  if (typeof value !== 'string') return null
  const text = value.replace(/\s+/g, ' ').trim()
  if (text.length < 4 || text.length > 300) return null
  return text
}

/**
 * Spoken replies are read out loud: link syntax and bold markers are noise in
 * the ear, so they are flattened before the words are stored and spoken.
 */
const forVoice = (text: string): string =>
  text
    .replace(/\[([^\]]+)]\([^)]*\)/g, '$1')
    .replace(/https?:\/\/\S+/g, '')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/\s+\n/g, '\n')
    .trim()

/**
 * The model once stored "Born on November 21, 2026" because that was the date
 * it was told, and then answered "when is my birthday" with it. Anything that
 * is really the current date, or an instruction to itself dressed up as a
 * fact, is refused before it reaches memory.
 */
function selfInvented(text: string): boolean {
  const lower = text.toLowerCase()
  const todayText = new Date()
    .toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    })
    .toLowerCase()
  if (lower.includes(todayText)) return true
  if (/\b(?:your|my) (?:exact )?birth ?date\b/i.test(lower)) return true
  if (/^remember (?:your|that you|your own)\b/i.test(lower)) return true
  return false
}

/**
 * The notes worth handing the model: recent ones always, plus older notes that
 * share words with what was just said, so a months-old note can resurface when
 * it is actually relevant instead of being buried by newer small talk.
 */
function pickMemories(all: Memory[], text: string): Memory[] {
  if (all.length <= MEMORIES_IN_PROMPT) return all
  const recent = [...all]
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .slice(0, MEMORIES_IN_PROMPT / 2)
  const taken = new Set(recent.map((memory) => memory.id))
  const words = memoryWords(text)
  const scored = all
    .filter((memory) => !taken.has(memory.id))
    .map((memory) => {
      let score = 0
      for (const word of memoryWords(memory.text)) if (words.has(word)) score += 1
      return { memory, score }
    })
    .sort(
      (a, b) => b.score - a.score || b.memory.updatedAt - a.memory.updatedAt,
    )
    .slice(0, MEMORIES_IN_PROMPT - recent.length)
    .map((hit) => hit.memory)
  return [...recent, ...scored]
}

const readSettings = (raw: unknown): Settings => {
  if (typeof raw !== 'string') return defaultSettings
  try {
    return normalizeSettings(JSON.parse(raw))
  } catch {
    return defaultSettings
  }
}

/**
 * Which brain will answer, and where its key came from. The key itself never
 * leaves the server: only the provider name and the model are sent out.
 */
function aiStatusFor(
  env: Env,
  saved: { gemini?: string | null },
  settings: Settings,
): AiStatus {
  const accountGemini = saved.gemini?.trim() ?? ''
  const keys: AiKeys = { gemini: accountGemini || env.GEMINI_API_KEY }
  const brain = describeBrain(keys, settings.brain, { gemini: env.GEMINI_MODEL })
  const fromAccount = brain.provider === 'gemini' && Boolean(accountGemini)
  return {
    configured: brain.provider !== 'none',
    model: brain.model,
    provider: brain.provider,
    source: fromAccount
      ? 'account'
      : brain.provider !== 'none'
        ? 'server'
        : 'none',
    preference: settings.brain,
    fallback: brain.fallback,
    keys: { gemini: Boolean(keys.gemini) },
  }
}

/** Tests inject identities and a model; production uses the SDK and the providers. */
export function createApp(
  authenticate: Authenticate = currentUser,
  ai: AiClient = generate,
  web: WebLookup = lookupWeb,
) {
  const app = new Hono<AppContext>()

  app.use('*', async (c, next) => {
    // Replies are private, and the browser is told not to guess at types or
    // leak the path to other sites.
    c.header('X-Content-Type-Options', 'nosniff')
    c.header('Referrer-Policy', 'no-referrer')
    c.header('Permissions-Policy', 'microphone=(self), camera=(), geolocation=()')
    await next()
  })

  app.use('/api/*', async (c, next) => {
    c.header('Cache-Control', 'private, no-store')
    await next()
  })

  app.get('/api/health', (c) => c.json({ ok: true }))

  app.get('/api/session', async (c) =>
    c.json({
      authenticated: Boolean(await authenticate(c.req.raw, c.env)),
      database: Boolean(c.env.DB),
    }),
  )

  app.use(
    '/api/*',
    bodyLimit({
      // Long pasted documents are accepted now; the ceiling only guards the
      // worker against a request that cannot be a person's message.
      maxSize: 200 * 1024,
      onError: (c) => c.json({ error: 'Request is too large.' }, 413),
    }),
  )

  app.post('/api/login', async (c) => {
    if (!isTrustedMutation(c.req.raw))
      return c.json({ error: 'Cross-origin request refused.' }, 403)
    const body = (await c.req.json().catch(() => null)) as {
      userId?: unknown
      password?: unknown
    } | null
    const address = c.req.header('cf-connecting-ip') || 'local'
    const result = await attemptLogin(
      body?.userId,
      body?.password,
      address,
      c.env,
    )
    if (result === 'unconfigured')
      return c.json(
        {
          error:
            'This deployment has no login yet. Set the LUMINA_PASSWORD secret, then try again.',
        },
        503,
      )
    if (result === 'throttled')
      return c.json(
        { error: 'Too many attempts. Wait a minute, then try again.' },
        429,
      )
    if (result !== 'ok')
      return c.json({ error: 'That user ID and password do not match.' }, 401)
    const token = await issueSession(c.env)
    c.header('Set-Cookie', sessionCookie(c.req.raw, token))
    // The token is the cookie's value: the client keeps it and sends it back as
    // a bearer header, so the session survives a browser that drops cookies.
    return c.json({ ok: true, token })
  })

  app.post('/api/logout', (c) => {
    c.header('Set-Cookie', clearedSessionCookie(c.req.raw))
    return c.json({ ok: true })
  })

  app.use('/api/*', async (c, next) => {
    const user = await authenticate(c.req.raw, c.env)
    if (!user) return c.json({ error: 'Sign in required.' }, 401)
    if (
      !['GET', 'HEAD'].includes(c.req.method) &&
      !isTrustedMutation(c.req.raw)
    )
      return c.json({ error: 'Cross-origin request refused.' }, 403)
    if (!c.env.DB)
      return c.json(
        { error: 'This app is still being set up. Please try again later.' },
        503,
      )
    await ensureSchema(c.env.DB)
    c.set('user', user)
    c.set('db', c.env.DB)
    await next()
  })

  app.get('/api/state', async (c) => {
    const db = c.get('db')
    const owner = c.get('user').sub
    const [conversations, rules, memories, facts, settings, keys] =
      await db.batch([
        db
          .prepare(
            'SELECT id, title, created_at, updated_at FROM conversations WHERE owner_sub = ? ORDER BY updated_at DESC LIMIT 60',
          )
          .bind(owner),
        db
          .prepare(
            'SELECT id, text, source, created_at FROM rules WHERE owner_sub = ? ORDER BY created_at ASC, id ASC LIMIT ?',
          )
          .bind(owner, MAX_RULES),
        db
          .prepare(
            'SELECT id, text, kind, created_at, updated_at FROM memories WHERE owner_sub = ? ORDER BY updated_at DESC LIMIT ?',
          )
          .bind(owner, MAX_MEMORIES),
        db
          .prepare(
            'SELECT slot, value, updated_at FROM facts WHERE owner_sub = ? ORDER BY updated_at DESC',
          )
          .bind(owner),
        db.prepare('SELECT data FROM settings WHERE owner_sub = ?').bind(owner),
        db
          .prepare('SELECT gemini_key FROM api_keys WHERE owner_sub = ?')
          .bind(owner),
      ])
    const settingsRow = settings?.results?.[0] as { data?: string } | undefined
    const saved =
      (keys?.results?.[0] as { gemini_key?: string } | undefined) ?? {}
    const currentSettings = readSettings(settingsRow?.data)
    return c.json({
      conversations: ((conversations?.results ?? []) as ConversationRow[]).map(
        mapConversation,
      ),
      rules: ((rules?.results ?? []) as RuleRow[]).map(mapRule),
      memories: ((memories?.results ?? []) as MemoryRow[]).map(mapMemory),
      facts: ((facts?.results ?? []) as FactRow[]).map(mapFact),
      settings: currentSettings,
      ai: aiStatusFor(c.env, { gemini: saved.gemini_key }, currentSettings),
    })
  })

  const ownConversation = async (
    db: D1Database,
    owner: string,
    id: string,
  ): Promise<Conversation | null> => {
    const row = await db
      .prepare(
        'SELECT id, title, created_at, updated_at FROM conversations WHERE id = ? AND owner_sub = ?',
      )
      .bind(id, owner)
      .first<ConversationRow>()
    return row ? mapConversation(row) : null
  }

  app.post('/api/conversations', async (c) => {
    const db = c.get('db')
    const owner = c.get('user').sub
    const now = Date.now()
    const conversation: Conversation = {
      id: crypto.randomUUID(),
      title: 'New chat',
      createdAt: now,
      updatedAt: now,
    }
    await db
      .prepare(
        'INSERT INTO conversations (id, owner_sub, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
      )
      .bind(conversation.id, owner, conversation.title, now, now)
      .run()
    return c.json({ conversation }, 201)
  })

  app.get('/api/conversations/:id', async (c) => {
    const conversation = await ownConversation(
      c.get('db'),
      c.get('user').sub,
      c.req.param('id'),
    )
    if (!conversation) return c.json({ error: 'Chat not found.' }, 404)
    const rows = await c
      .get('db')
      .prepare(
        'SELECT id, conversation_id, role, content, created_at FROM messages WHERE conversation_id = ? AND owner_sub = ? ORDER BY created_at ASC, id ASC LIMIT 200',
      )
      .bind(conversation.id, c.get('user').sub)
      .all<MessageRow>()
    return c.json({
      conversation,
      messages: rows.results.map(mapMessage),
    })
  })

  app.patch('/api/conversations/:id', async (c) => {
    const body = (await c.req.json().catch(() => null)) as {
      title?: unknown
    } | null
    const title =
      typeof body?.title === 'string'
        ? body.title.replace(/\s+/g, ' ').trim().slice(0, 120)
        : ''
    if (!title) return c.json({ error: 'A title is required.' }, 400)
    const row = await c
      .get('db')
      .prepare(
        'UPDATE conversations SET title = ?, updated_at = ? WHERE id = ? AND owner_sub = ? RETURNING id, title, created_at, updated_at',
      )
      .bind(title, Date.now(), c.req.param('id'), c.get('user').sub)
      .first<ConversationRow>()
    return row
      ? c.json({ conversation: mapConversation(row) })
      : c.json({ error: 'Chat not found.' }, 404)
  })

  app.delete('/api/conversations/:id', async (c) => {
    const db = c.get('db')
    const owner = c.get('user').sub
    const id = c.req.param('id')
    const removed = await db
      .prepare(
        'DELETE FROM conversations WHERE id = ? AND owner_sub = ? RETURNING id',
      )
      .bind(id, owner)
      .first()
    if (!removed) return c.json({ error: 'Chat not found.' }, 404)
    await db
      .prepare('DELETE FROM messages WHERE conversation_id = ? AND owner_sub = ?')
      .bind(id, owner)
      .run()
    return c.json({ ok: true })
  })

  const chat: Handler<AppContext> = async (c) => {
    const body = (await c.req.json().catch(() => null)) as {
      conversationId?: unknown
      text?: unknown
      voice?: unknown
      stream?: unknown
    } | null
    const text = typeof body?.text === 'string' ? body.text.trim() : ''
    // A spoken turn keeps the answer short and free of markdown.
    const voice = body?.voice === true
    /** Server-sent events, so words appear while the model is still writing. */
    const stream = body?.stream === true
    if (!text) return c.json({ error: 'Type or say something first.' }, 400)
    if (text.length > MAX_MESSAGE)
      return c.json(
        { error: `That message is too long (${MAX_MESSAGE} characters max).` },
        400,
      )
    const db = c.get('db')
    const owner = c.get('user').sub
    const requestedId =
      typeof body?.conversationId === 'string' ? body.conversationId : null
    const now = Date.now()

    // The account's own key wins, so each person can bring their own quota.
    // Everything the turn needs is read in one round trip, and the web lookup
    // starts as soon as we know this is not a memory question.
    const [
      storedKeys,
      existing,
      previous,
      settingsRow,
      factRows,
      memoryRows,
      ruleRows,
      personaRow,
    ] = await Promise.all([
      readApiKeys(db, owner),
      requestedId
        ? ownConversation(db, owner, requestedId)
        : Promise.resolve(null),
      requestedId
        ? db
            .prepare(
              "SELECT content FROM messages WHERE conversation_id = ? AND owner_sub = ? AND role = 'user' ORDER BY created_at DESC, id DESC LIMIT 1",
            )
            .bind(requestedId, owner)
            .first<{ content: string }>()
        : Promise.resolve(null),
      db
        .prepare('SELECT data FROM settings WHERE owner_sub = ?')
        .bind(owner)
        .first<{ data?: string }>(),
      db
        .prepare(
          'SELECT slot, value, updated_at FROM facts WHERE owner_sub = ? ORDER BY updated_at DESC',
        )
        .bind(owner)
        .all<FactRow>(),
      db
        .prepare(
          'SELECT id, text, kind, created_at, updated_at FROM memories WHERE owner_sub = ? ORDER BY updated_at DESC LIMIT ?',
        )
        .bind(owner, MAX_MEMORIES)
        .all<MemoryRow>(),
      db
        .prepare(
          'SELECT id, text, source, created_at FROM rules WHERE owner_sub = ? ORDER BY created_at ASC, id ASC LIMIT ?',
        )
        .bind(owner, MAX_RULES)
        .all<RuleRow>(),
      requestedId
        ? db
            .prepare(
              'SELECT persona_version FROM conversations WHERE id = ? AND owner_sub = ?',
            )
            .bind(requestedId, owner)
            .first<{ persona_version?: number }>()
        : Promise.resolve(null),
    ])

    const settings = readSettings(settingsRow?.data)
    const keys: AiKeys = {
      gemini: storedKeys.gemini ?? c.env.GEMINI_API_KEY,
    }
    if (!keys.gemini)
      return c.json(
        {
          error: 'Add a Gemini API key in Settings → Brain, then try again.',
        },
        503,
      )

    // A long paste is compressed for this turn only; the stored message keeps
    // every word the person sent. Condensing is best-effort, never fatal.
    const condensed =
      text.length > CONDENSE_AT
        ? await condenseText(text, keys.gemini).catch(() =>
            text.slice(0, 5_500),
          )
        : text

    // Streaming is opt-in, set up only once every early failure has already
    // been answered as ordinary JSON, so an error never arrives mid-stream
    // unless the model itself failed after starting.
    const encoder = new TextEncoder()
    let emit: ((event: string, data: unknown) => void) | null = null
    let finishStream: (() => Promise<void>) | null = null
    let streamResponse: Response | null = null
    if (stream) {
      const { readable, writable } = new TransformStream<Uint8Array, Uint8Array>()
      const writer = writable.getWriter()
      let queue: Promise<void> = Promise.resolve()
      emit = (event, data) => {
        queue = queue
          .then(() =>
            writer.write(
              encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`),
            ),
          )
          .catch(() => undefined)
      }
      // A stream must start talking at once: the runtime cancels a request
      // that has produced nothing while a slow model queue is still working.
      // "ready" opens the stream, and the heartbeat keeps it alive.
      emit('ready', { at: Date.now() })
      const heartbeat = setInterval(() => emit?.('ping', {}), 8_000)
      finishStream = async () => {
        clearInterval(heartbeat)
        await queue
        await writer.close().catch(() => undefined)
      }
      streamResponse = new Response(readable, {
        status: 200,
        headers: {
          'Content-Type': 'text/event-stream; charset=utf-8',
          'Cache-Control': 'private, no-store',
          'X-Accel-Buffering': 'no',
        },
      })
    }

    /**
     * The turn itself: model, storage, learning. Kept as one unit so the
     * streaming route can return its response first and run this in the
     * background, while the JSON route simply awaits it.
     */
    const turn = async (): Promise<ChatResponse> => {
    const conversation: Conversation = existing ?? {
      id: crypto.randomUUID(),
      title: titleFrom(text),
      createdAt: now,
      updatedAt: now,
    }

    const facts = factRows.results.map(mapFact)
    let knownMemories = memoryRows.results.map(mapMemory)
    // Memory is append-only by nature; past a point it is consolidated so the
    // prompt keeps carrying distinct notes instead of rephrasings.
    if (knownMemories.length >= CONSOLIDATE_AT) {
      await consolidateMemories(db, owner).catch(() => 0)
      knownMemories = (await db
        .prepare(
          'SELECT id, text, kind, created_at, updated_at FROM memories WHERE owner_sub = ? ORDER BY updated_at DESC LIMIT ?',
        )
        .bind(owner, MAX_MEMORIES)
        .all<MemoryRow>())
        .results.map(mapMemory)
    }
    // Questions about their own facts are answered from the database. A model
    // is never given the chance to invent a birthday.
    const recalled = recallAnswer(text, facts, knownMemories)

    // The web is checked on every single turn, not just "what's the news"
    // ones. The previous message goes along so a follow-up like "and
    // tomorrow?" searches the right thing. Only the wait is rationed, so a
    // question gets real results without making small talk queue behind Bing.
    const lookupStarted = Date.now()
    const live = recalled
      ? Promise.resolve(null)
      : settleWithin(
          web(text, previous?.content).catch(() => null),
          WANTS_FACTS.test(text) ? WEB_WAIT_MS : QUICK_WAIT_MS,
        )
    // Earlier turns from other chats that share words with this message.
    const archive = recalled
      ? Promise.resolve([])
      : searchPastMessages(db, owner, text, conversation.id).catch(() => [])

    const [historyRows, webContext, past] = await Promise.all([
        db
          .prepare(
            'SELECT id, conversation_id, role, content, created_at FROM messages WHERE conversation_id = ? AND owner_sub = ? ORDER BY created_at DESC, id DESC LIMIT ?',
          )
          .bind(conversation.id, owner, CONTEXT_MESSAGES)
          .all<MessageRow>(),
        live,
        archive,
      ])
    // Past the context window the start of a long chat would silently vanish.
    // The opening turns are carried forward as a compact recap instead.
    const earlyRows =
      historyRows.results.length >= CONTEXT_MESSAGES
        ? (
            await db
              .prepare(
                'SELECT id, conversation_id, role, content, created_at FROM messages WHERE conversation_id = ? AND owner_sub = ? ORDER BY created_at ASC, id ASC LIMIT 8',
              )
              .bind(conversation.id, owner)
              .all<MessageRow>()
          ).results
        : []
    const archived = [
      ...earlyRows.map((row) => ({
        content: row.content,
        role: row.role,
        createdAt: row.created_at,
        title: conversation.title,
        conversationId: conversation.id,
      })),
      ...past,
    ]
    const lookupMs = webContext ? Date.now() - lookupStarted : 0
    // A lookup that found nothing is still information: the model is told the
    // check happened, so it can admit a gap instead of passing off a guess as
    // today's fact.
    const webCheckedAt = recalled || webContext ? undefined : lookupStarted
    const history: AiMessage[] = historyRows.results
      .reverse()
      .map((row) => ({
        role: row.role === 'assistant' ? 'model' : 'user',
        text: row.content,
      }))
    history.push({ role: 'user', text: condensed })

    const rules = ruleRows.results.map(mapRule)

    let answer: {
      reply: string
      spoken?: string
      rules: AiSuggestion[]
      memories?: AiSuggestion[]
    }
    const turnStarted = Date.now()
    let brain: ChatResponse['brain']
    let spokenText = ''
    if (recalled) {
      answer = { reply: recalled, rules: [], memories: [] }
      spokenText = recalled
      brain = { model: 'memory', provider: 'recall', ms: 0, lookupMs: 0 }
    } else {
      // A conversation opened under an older contract gets its manner restated,
      // so old turns cannot drag the assistant back to its former voice.
      const toneRefresh =
        Boolean(existing) &&
        (personaRow?.persona_version ?? 0) !== PROMPT_VERSION
      const turn = {
        keys,
        preference: settings.brain,
        geminiModel: c.env.GEMINI_MODEL,
        history,
        rules,
        memories: pickMemories(knownMemories, text),
        facts,
        web: webContext,
        webCheckedAt,
        voice,
        archive: archived.map((entry) => ({
          title: entry.title,
          role: entry.role,
          text: entry.content,
          at: entry.createdAt,
        })),
        toneRefresh,
      }
      try {
        const replied = emit
          ? await generateStream(turn, (chunk) => emit?.('delta', { text: chunk }))
          : await ai(turn)
        spokenText = forVoice(replied.spoken || replied.reply).slice(0, 1_600)
        answer = voice ? { ...replied, reply: spokenText || replied.reply } : replied
        brain = {
          model: replied.model,
          provider: replied.provider ?? 'gemini',
          ms: Date.now() - turnStarted,
          lookupMs,
        }
      } catch (error) {
        if (error instanceof AiError && error.kind === 'config')
          console.warn('[lumina] chat refused:', error.message)
        // The caller decides how a failure is delivered: an event on a stream,
        // or a status code on the ordinary route.
        throw error
      }
    }

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      conversationId: conversation.id,
      role: 'user',
      content: text,
      createdAt: now,
    }
    const assistantMessage: ChatMessage = {
      id: crypto.randomUUID(),
      conversationId: conversation.id,
      role: 'assistant',
      content: answer.reply,
      createdAt: now + 1,
    }
    await db.batch([
      ...(existing
        ? []
        : [
            db
              .prepare(
                'INSERT INTO conversations (id, owner_sub, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
              )
              .bind(conversation.id, owner, conversation.title, now, now),
          ]),
      db
        .prepare(
          'INSERT INTO messages (id, conversation_id, owner_sub, role, content, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        )
        .bind(
          userMessage.id,
          conversation.id,
          owner,
          userMessage.role,
          userMessage.content,
          userMessage.createdAt,
        ),
      db
        .prepare(
          'INSERT INTO messages (id, conversation_id, owner_sub, role, content, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        )
        .bind(
          assistantMessage.id,
          conversation.id,
          owner,
          assistantMessage.role,
          assistantMessage.content,
          assistantMessage.createdAt,
        ),
    ])

    const seen = new Set(rules.map((rule) => ruleKey(rule.text)))
    // "Keep all answers to two short lines" and "Keep every answer to two lines
    // maximum" are the same lesson; the second one must not be stored.
    const taughtTexts = rules.map((rule) => rule.text)
    const newRules: Rule[] = []
    for (const suggestion of answer.rules) {
      const clean = cleanRule(suggestion.text)
      if (!clean || selfInvented(clean)) continue
      const key = ruleKey(clean)
      if (!key || seen.has(key)) continue
      if (taughtTexts.some((text) => sameLesson(text, clean))) continue
      taughtTexts.push(clean)
      seen.add(key)
      newRules.push({
        id: crypto.randomUUID(),
        text: clean,
        source: 'auto',
        createdAt: Date.now(),
      })
    }
    if (newRules.length)
      await db.batch(
        newRules.map((rule) =>
          db
            .prepare(
              'INSERT INTO rules (id, owner_sub, text, source, created_at, source_message_id) VALUES (?, ?, ?, ?, ?, ?)',
            )
            .bind(
              rule.id,
              owner,
              rule.text,
              rule.source,
              rule.createdAt,
              assistantMessage.id,
            ),
        ),
      )

    // Confirmed facts, taken from the person's own words first: those are
    // authoritative, and a corrected value replaces the old slot.
    const learnedFacts = new Map<FactSlot, string>()
    for (const fact of extractFacts(text)) learnedFacts.set(fact.slot, fact.value)
    const storedFacts = new Map(facts.map((fact) => [fact.slot, fact.value] as const))
    const factValues = new Map([...storedFacts, ...learnedFacts])

    // Long-term memory: a note the person would otherwise have to repeat next
    // week. Near-duplicates are dropped here, not left for the prompt to sort.
    const knownTexts = knownMemories.map((memory) => memory.text)
    const newMemories: Memory[] = []
    const nowMemory = Date.now()
    for (const suggestion of answer.memories ?? []) {
      const clean = cleanMemory(suggestion.text)
      if (!clean || selfInvented(clean)) continue
      const key = memoryKey(clean)
      if (!key) continue
      if (knownTexts.some((text) => memoryKey(text) === key)) continue
      if (knownTexts.some((text) => similarMemory(text, clean))) continue
      // A note that only repeats a fact already stored is noise, not memory.
      const implied = factsFromNote(clean)
      if (
        implied.length &&
        implied.every(
          (fact) =>
            factValues.get(fact.slot)?.toLowerCase() === fact.value.toLowerCase(),
        )
      )
        continue
      for (const fact of implied)
        if (!learnedFacts.has(fact.slot) && !storedFacts.has(fact.slot))
          learnedFacts.set(fact.slot, fact.value)
      const kind = MEMORY_KINDS.includes(suggestion.kind as MemoryKind)
        ? (suggestion.kind as MemoryKind)
        : 'note'
      knownTexts.push(clean)
      newMemories.push({
        id: crypto.randomUUID(),
        text: clean,
        kind,
        createdAt: nowMemory,
        updatedAt: nowMemory,
      })
      if (newMemories.length === 2) break
    }

    const newFacts: Fact[] = await Promise.all(
      [...learnedFacts].map(([slot, value]) => saveFact(db, owner, slot, value)),
    )
    if (newMemories.length)
      await db.batch(
        newMemories.map((memory) =>
          db
            .prepare(
              'INSERT INTO memories (id, owner_sub, text, kind, created_at, updated_at, source_message_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
            )
            .bind(
              memory.id,
              owner,
              memory.text,
              memory.kind,
              memory.createdAt,
              memory.updatedAt,
              assistantMessage.id,
            ),
        ),
      )

    const updatedAt = Date.now()
    await db
      .prepare(
        'UPDATE conversations SET updated_at = ?, persona_version = ? WHERE id = ? AND owner_sub = ?',
      )
      .bind(updatedAt, PROMPT_VERSION, conversation.id, owner)
      .run()

    const payload: ChatResponse = {
      conversation: { ...conversation, updatedAt },
      userMessage,
      assistantMessage,
      newRules,
      newMemories,
      ...(newFacts.length ? { newFacts } : {}),
      ...(spokenText && !voice ? { spoken: spokenText } : {}),
      ...(brain ? { brain } : {}),
      ...(webCheckedAt
        ? { web: { query: '', sources: [] } }
        : webContext
          ? {
              web: {
                query: webContext.query,
                sources: webContext.sources
                  .slice(0, 4)
                  .map(({ title, url }) => ({ title, url })),
              },
            }
          : {}),
    }
      return payload
    }

    if (emit && finishStream && streamResponse) {
      const opened = streamResponse
      const write = emit
      const close = finishStream
      const job = (async () => {
        try {
          write('done', await turn())
        } catch (error) {
          write('error', {
            error:
              error instanceof AiError
                ? error.message
                : 'Something went wrong on the server. Please try again.',
          })
        } finally {
          await close()
        }
      })()
      // The response is already on its way; this keeps the worker alive until
      // the last event has been written.
      c.executionCtx?.waitUntil?.(job)
      return opened
    }

    try {
      return c.json(await turn())
    } catch (error) {
      if (error instanceof AiError)
        return c.json(
          { error: error.message },
          error.kind === 'quota' ? 429 : 502,
        )
      throw error
    }
  }
  app.post('/api/chat', chat)

  app.post('/api/rules', async (c) => {
    const body = (await c.req.json().catch(() => null)) as {
      text?: unknown
    } | null
    const text = cleanRule(body?.text)
    if (!text)
      return c.json(
        { error: 'Write a rule between 4 and 240 characters.' },
        400,
      )
    const db = c.get('db')
    const owner = c.get('user').sub
    const existing = await db
      .prepare('SELECT text FROM rules WHERE owner_sub = ?')
      .bind(owner)
      .all<{ text: string }>()
    const key = ruleKey(text)
    if (existing.results.some((row) => ruleKey(row.text) === key))
      return c.json({ error: 'You already taught me that one.' }, 409)
    const rule: Rule = {
      id: crypto.randomUUID(),
      text,
      source: 'manual',
      createdAt: Date.now(),
    }
    await db
      .prepare(
        'INSERT INTO rules (id, owner_sub, text, source, created_at) VALUES (?, ?, ?, ?, ?)',
      )
      .bind(rule.id, owner, rule.text, rule.source, rule.createdAt)
      .run()
    return c.json({ rule }, 201)
  })

  app.patch('/api/rules/:id', async (c) => {
    const body = (await c.req.json().catch(() => null)) as {
      text?: unknown
    } | null
    const text = cleanRule(body?.text)
    if (!text)
      return c.json(
        { error: 'Write a rule between 4 and 240 characters.' },
        400,
      )
    const row = await c
      .get('db')
      .prepare(
        'UPDATE rules SET text = ? WHERE id = ? AND owner_sub = ? RETURNING id, text, source, created_at',
      )
      .bind(text, c.req.param('id'), c.get('user').sub)
      .first<RuleRow>()
    return row
      ? c.json({ rule: mapRule(row) })
      : c.json({ error: 'Rule not found.' }, 404)
  })

  app.delete('/api/rules/:id', async (c) => {
    const removed = await c
      .get('db')
      .prepare('DELETE FROM rules WHERE id = ? AND owner_sub = ? RETURNING id')
      .bind(c.req.param('id'), c.get('user').sub)
      .first()
    return removed
      ? c.json({ ok: true })
      : c.json({ error: 'Rule not found.' }, 404)
  })

  app.post('/api/memories', async (c) => {
    const body = (await c.req.json().catch(() => null)) as {
      text?: unknown
      kind?: unknown
    } | null
    const text = cleanMemory(body?.text)
    if (!text)
      return c.json(
        { error: 'Write a note between 4 and 300 characters.' },
        400,
      )
    const db = c.get('db')
    const owner = c.get('user').sub
    const existing = await db
      .prepare('SELECT text FROM memories WHERE owner_sub = ?')
      .bind(owner)
      .all<{ text: string }>()
    const key = memoryKey(text)
    if (existing.results.some((row) => memoryKey(row.text) === key))
      return c.json({ error: 'Lumina already remembers that.' }, 409)
    const kind = MEMORY_KINDS.includes(body?.kind as MemoryKind)
      ? (body?.kind as MemoryKind)
      : 'note'
    const now = Date.now()
    const memory: Memory = {
      id: crypto.randomUUID(),
      text,
      kind,
      createdAt: now,
      updatedAt: now,
    }
    await db
      .prepare(
        'INSERT INTO memories (id, owner_sub, text, kind, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      )
      .bind(memory.id, owner, memory.text, memory.kind, now, now)
      .run()
    return c.json({ memory }, 201)
  })

  app.patch('/api/memories/:id', async (c) => {
    const body = (await c.req.json().catch(() => null)) as {
      text?: unknown
    } | null
    const text = cleanMemory(body?.text)
    if (!text)
      return c.json(
        { error: 'Write a note between 4 and 300 characters.' },
        400,
      )
    const row = await c
      .get('db')
      .prepare(
        'UPDATE memories SET text = ?, updated_at = ? WHERE id = ? AND owner_sub = ? RETURNING id, text, kind, created_at, updated_at',
      )
      .bind(text, Date.now(), c.req.param('id'), c.get('user').sub)
      .first<MemoryRow>()
    return row
      ? c.json({ memory: mapMemory(row) })
      : c.json({ error: 'Note not found.' }, 404)
  })

  app.delete('/api/facts/:slot', async (c) => {
    const slot = c.req.param('slot')
    if (!isFactSlot(slot))
      return c.json({ error: 'Unknown fact.' }, 400)
    const removed = await clearFact(c.get('db'), c.get('user').sub, slot)
    return removed
      ? c.json({ ok: true })
      : c.json({ error: 'Nothing stored for that.' }, 404)
  })

  app.delete('/api/memories/:id', async (c) => {
    const removed = await c
      .get('db')
      .prepare(
        'DELETE FROM memories WHERE id = ? AND owner_sub = ? RETURNING id',
      )
      .bind(c.req.param('id'), c.get('user').sub)
      .first()
    return removed
      ? c.json({ ok: true })
      : c.json({ error: 'Note not found.' }, 404)
  })

  // Neural speech for one reply. Separate from recognition on purpose: the
  // browser turns speech into text, the model turns the answer into audio.
  app.post('/api/speech', async (c) => {
    const body = (await c.req.json().catch(() => null)) as {
      text?: unknown
      voice?: unknown
    } | null
    const text = typeof body?.text === 'string' ? body.text.trim() : ''
    if (!text) return c.json({ error: 'There is nothing to speak.' }, 400)
    if (text.length > 2000)
      return c.json({ error: 'That reply is too long to speak at once.' }, 400)
    const saved = await readApiKeys(c.get('db'), c.get('user').sub)
    const key = saved.gemini ?? c.env.GEMINI_API_KEY
    if (!key)
      return c.json(
        {
          error:
            'Add a Gemini API key in Settings → Brain to use the neural voice.',
        },
        503,
      )
    try {
      return c.json(
        await synthesizeSpeech({
          key,
          text,
          voice: typeof body?.voice === 'string' ? body.voice : undefined,
          model: c.env.GEMINI_TTS_MODEL,
        }),
      )
    } catch (error) {
      if (error instanceof AiError)
        return c.json(
          { error: error.message },
          error.kind === 'quota' ? 429 : 502,
        )
      throw error
    }
  })

  // A per-account key keeps the app usable from a phone without server access.
  app.put('/api/settings/api-key', async (c) => {
    const body = (await c.req.json().catch(() => null)) as {
      apiKey?: unknown
    } | null
    const db = c.get('db')
    const owner = c.get('user').sub
    const settingsRow = await db
      .prepare('SELECT data FROM settings WHERE owner_sub = ?')
      .bind(owner)
      .first<{ data?: string }>()
    const settings = readSettings(settingsRow?.data)
    if (typeof body?.apiKey !== 'string')
      return c.json(
        {
          error: 'Paste a Gemini API key, or send an empty string to remove it.',
        },
        400,
      )
    const raw = body.apiKey.trim()
    if (!raw) {
      await clearApiKey(db, owner)
      return c.json({ ai: aiStatusFor(c.env, {}, settings) })
    }
    const key = cleanApiKey(raw)
    if (!key)
      return c.json(
        {
          error:
            'That does not look like an API key. Paste the whole value you copied.',
        },
        400,
      )
    await saveApiKey(db, owner, key)
    return c.json({ ai: aiStatusFor(c.env, { gemini: key }, settings) })
  })

  app.put('/api/settings', async (c) => {
    const body = await c.req.json().catch(() => null)
    const settings = normalizeSettings(body)
    await c
      .get('db')
      .prepare(
        'INSERT INTO settings (owner_sub, data, updated_at) VALUES (?, ?, ?) ON CONFLICT(owner_sub) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at',
      )
      .bind(c.get('user').sub, JSON.stringify(settings), Date.now())
      .run()
    return c.json({ settings })
  })

  app.notFound((c) =>
    c.req.path === '/api' || c.req.path.startsWith('/api/')
      ? c.json({ error: 'Endpoint not found.' }, 404)
      : c.env.ASSETS.fetch(c.req.raw),
  )
  app.onError((error, c) => {
    console.error('Request failed', error)
    return c.json({ error: 'Something went wrong. Please try again.' }, 500)
  })
  return app
}
