/**
 * Exact recall.
 *
 * A language model is good at phrasing and bad at being a database: it will
 * confidently invent a birthday, or forget one it was told last week. So the
 * facts a person states about themselves are also pulled out with plain
 * pattern matching, stored in one slot each, and answered directly.
 *
 * "When is my birthday?" never reaches a model. It reads the slot.
 */
import type { Fact, FactSlot, Memory } from '../shared/types'

const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
]

const MONTH_LOOKUP: Record<string, number> = {}
MONTHS.forEach((name, index) => {
  MONTH_LOOKUP[name.toLowerCase()] = index + 1
  MONTH_LOOKUP[name.slice(0, 3).toLowerCase()] = index + 1
})
MONTH_LOOKUP.sept = 9

const clean = (value: string): string => value.replace(/\s+/g, ' ').trim()

/** Drop trailing conjunctions and filler from a loosely matched value. */
const tidyValue = (value: string): string => {
  let next = clean(
    value
      .replace(/^[\s,:;-]+/, '')
      .replace(/[.,;:!?]+$/, '')
      .replace(/\b(?:and|but|so|because|which|who)\b.*$/i, ''),
  )
  next = clean(next.replace(/\b(?:now|too|aswell|as well|btw)\b/gi, ''))
  const words = next.split(' ').slice(0, 6)
  return words.join(' ').slice(0, 80)
}

const titleCase = (value: string): string =>
  value
    .split(' ')
    .map((word) =>
      word
        ? word[0]!.toUpperCase() + word.slice(1)
        : word,
    )
    .join(' ')

/**
 * "30 october", "oct 30", "30th of October 1998", "30/10", "10-30-1998".
 * Returns "30 October" (plus the year when one was given) or null.
 */
export function parseBirthday(raw: string): string | null {
  const text = raw
    .toLowerCase()
    .replace(/(\d)(?:st|nd|rd|th)\b/g, '$1')
    .replace(/[’']/g, '')

  let day: number | null = null
  let month: number | null = null
  let year: number | null = null

  const yearHit = /\b(19\d{2}|20\d{2})\b/.exec(text)
  if (yearHit) year = Number(yearHit[1])

  const named = Object.entries(MONTH_LOOKUP)
    .sort((a, b) => b[0].length - a[0].length)
    .find(([name]) => new RegExp(`\\b${name}\\b`).test(text))
  if (named) {
    month = named[1]
    const withoutMonth = text.replace(new RegExp(`\\b${named[0]}\\b`, 'g'), ' ')
    const withoutYear = year ? withoutMonth.replace(String(year), ' ') : withoutMonth
    const dayHit = /\b(\d{1,2})\b/.exec(withoutYear)
    if (dayHit) day = Number(dayHit[1])
  } else {
    const numeric = /(\d{1,2})\s*[/.-]\s*(\d{1,2})(?:\s*[/.-]\s*(\d{2,4}))?/.exec(
      text,
    )
    if (numeric) {
      const first = Number(numeric[1])
      const second = Number(numeric[2])
      if (first > 12 && second <= 12) {
        day = first
        month = second
      } else if (second > 12 && first <= 12) {
        month = first
        day = second
      } else {
        // Ambiguous; 30/10 is far more common worldwide than 10/30.
        day = first
        month = second
      }
      if (numeric[3]) {
        const raw = Number(numeric[3])
        year = raw < 100 ? 2000 + raw : raw
      }
    }
  }

  if (!day || !month || day < 1 || day > 31 || month < 1 || month > 12) return null
  return `${day} ${MONTHS[month - 1]}${year ? ` ${year}` : ''}`
}

/** Every confirmed fact stated in one message, newest statement winning. */
export function extractFacts(text: string): Fact[] {
  const found = new Map<FactSlot, string>()
  const now = Date.now()
  const source = text.replace(/[’]/g, "'")

  const name =
    /\b(?:my name(?:'s| is)|call me|name's)\s+([A-Za-z][A-Za-z'’-]{1,28})/i.exec(
      source,
    )
  if (name) {
    const value = tidyValue(name[1] ?? '')
    const stop = new Set([
      'not',
      'a',
      'an',
      'the',
      'just',
      'so',
      'too',
      'and',
      'but',
      'because',
      'actually',
      'really',
      'please',
      'lumina',
    ])
    if (value && !stop.has(value.toLowerCase())) found.set('name', titleCase(value))
  }

  const birthday =
    /\b(?:my\s+|the\s+)?(?:birthday|bday|birth ?date)\b[^\n.!?]{0,40}/i.exec(
      source,
    ) ?? /\b(?:i was born|i'm born|im born)\b[^\n.!?]{0,40}/i.exec(source)
  if (birthday) {
    const parsed = parseBirthday(birthday[0])
    if (parsed) found.set('birthday', parsed)
  }

  const city =
    /\bi(?:'m| am)?\s+(?:currently\s+)?(?:living|live|staying|stay|based|residing|reside)\s+in\s+([^\n.!?,;]{2,40})/i.exec(
      source,
    ) ?? /\bi(?:'m| am)\s+from\s+([^\n.!?,;]{2,40})/i.exec(source)
  if (city) {
    const value = tidyValue(city[1] ?? '')
    if (value && !/^(here|there|home|work|school|college|india|it)$/i.test(value))
      found.set('city', titleCase(value))
  }

  const job =
    /\bi(?:'m| am)?\s+(?:working|work)\s+as\s+(?:an?\s+|the\s+)?([^\n.!?,;]{2,50})/i.exec(
      source,
    ) ?? /\bmy (?:job|role|work) is\s+(?:an?\s+|the\s+)?([^\n.!?,;]{2,50})/i.exec(
      source,
    )
  if (job) {
    // "a designer at Figma" is two facts, not one.
    const raw = tidyValue(job[1] ?? '')
    const split = /^(.+?)\s+(?:at|for)\s+(.+)$/i.exec(raw)
    if (split) {
      if (split[1]) found.set('job', tidyValue(split[1] ?? ''))
      if (split[2]) found.set('company', tidyValue(split[2] ?? ''))
    } else if (raw) found.set('job', raw)
  }

  const company =
    /\bi(?:'m| am)?\s+(?:working|work)\s+(?:at|for)\s+([^\n.!?,;]{2,50})/i.exec(
      source,
    )
  if (company) {
    const value = tidyValue(company[1] ?? '')
    if (value) found.set('company', value)
  }

  const age =
    /\bi(?:'m| am)\s+(\d{1,2})\s*(?:years? old|y\/o|yo)\b/i.exec(source) ??
    /\bmy age is\s+(\d{1,2})\b/i.exec(source)
  if (age) {
    const value = Number(age[1])
    if (value >= 5 && value <= 120) found.set('age', String(value))
  }

  return [...found].map(([slot, value]) => ({
    slot,
    value,
    updatedAt: now,
  }))
}

/** Facts stated in a note the model wrote, e.g. "Birthday is 30 October." */
export const factsFromNote = (text: string): Fact[] =>
  extractFacts(text.startsWith('my ') || /^i\b/i.test(text) ? text : `my ${text}`)

export const factLabel = (slot: FactSlot): string =>
  ({
    name: 'Name',
    birthday: 'Birthday',
    age: 'Age',
    city: 'City',
    job: 'Job',
    company: 'Work',
  })[slot]

/** The block of certainties handed to the model on every turn. */
export function factsPrompt(facts: Fact[]): string {
  if (!facts.length) return '(nothing confirmed yet)'
  return facts
    .map((fact) => `- ${factLabel(fact.slot)}: ${fact.value}`)
    .join('\n')
}

/** Days until the next occurrence of a stored birthday, or null. */
function daysUntilBirthday(value: string): number | null {
  const match = /^(\d{1,2})\s+([A-Za-z]+)/.exec(value)
  if (!match) return null
  const day = Number(match[1])
  const month = MONTH_LOOKUP[(match[2] ?? '').toLowerCase()]
  if (!day || !month) return null
  const now = new Date()
  const today = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate())
  let next = Date.UTC(now.getUTCFullYear(), month - 1, day)
  if (next < today) next = Date.UTC(now.getUTCFullYear() + 1, month - 1, day)
  return Math.round((next - today) / 86_400_000)
}

const findNote = (notes: Memory[], pattern: RegExp): string | null => {
  for (const note of notes) if (pattern.test(note.text)) return note.text
  return null
}

const slotFact = (facts: Fact[], slot: FactSlot): Fact | undefined =>
  facts.find((fact) => fact.slot === slot)

/** A short list of what is actually on file, for "what do you remember?". */
function summary(facts: Fact[], notes: Memory[]): string {
  const lines = facts.map((fact) => `- ${factLabel(fact.slot)}: ${fact.value}`)
  const top = notes
    .filter((note) => note.kind !== 'preference')
    .slice(0, 8)
    .map((note) => `- ${note.text}`)
  const preferences = notes.filter((note) => note.kind === 'preference').slice(0, 4)
  const all = [
    ...lines,
    ...top,
    ...preferences.map((note) => `- Prefers: ${note.text}`),
  ]
  if (!all.length)
    return 'Nothing on file yet, sir. Tell me your name or your birthday and I will keep it.'
  return `Here is what I have on you, sir:\n\n${all.slice(0, 12).join('\n')}`
}

/**
 * Answer a question about the person's own facts, or return null and let the
 * model handle it. Only questions this knows how to answer exactly match.
 */
export function recallAnswer(
  question: string,
  facts: Fact[],
  notes: Memory[] = [],
): string | null {
  const text = question
    .toLowerCase()
    .replace(/[’']/g, "'")
    .replace(/\s+/g, ' ')
    .trim()
  if (!text) return null

  // Statements are not questions: "my birthday is 30 October" must be stored,
  // not answered with a countdown. A question asks, wonders or asks to be
  // reminded, and does not hand over a date.
  const birthdayAsk =
    /\bbirth ?day\b|\bbday\b/.test(text) &&
    /\b(?:when|what|which|remind|tell me|do you know|remember|again)\b/.test(
      text,
    ) &&
    !/\b(?:birth ?day|bday)\s*(?:is|was|'s|=)?\s*(?:on\s*)?(?:\d|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/.test(
      text,
    )
  if (birthdayAsk) {
    const fact = slotFact(facts, 'birthday')
    const value =
      fact?.value ??
      findNote(notes, /\b(?:birthday|bday|born)\b[^.]{0,30}/i)?.slice(0, 80)
    if (!value)
      return 'I do not have your birthday on file, sir. Give me the date and I will keep it.'
    const clean = value.replace(/^.*?(?:birthday|bday|born)\s*(?:is|on|:)?\s*/i, '')
    const stored = parseBirthday(clean) ?? clean
    const days = daysUntilBirthday(stored)
    const when =
      days === 0
        ? " — that's today, happy birthday"
        : days === 1
          ? ' — tomorrow'
          : typeof days === 'number'
            ? ` — ${days} days away`
            : ''
    return `Your birthday is ${stored}${when}, sir.`
  }

  if (/\b(?:what(?:'s| is)|do you know) my name\b|\bwho am i\b/.test(text)) {
    const fact = slotFact(facts, 'name')
    const value =
      fact?.value ??
      findNote(notes, /\bname is\b/i)?.replace(/^.*?\bname is\s*/i, '')
    return value
      ? `You are ${value.replace(/[.]+$/, '')}, sir.`
      : 'I do not have your name on file, sir.'
  }

  if (
    /\bwhere (?:do i|i) (?:live|stay)\b|\bwhat city do i live in\b|\bwhere am i from\b|\bwhere do i live\b/.test(
      text,
    )
  ) {
    const fact = slotFact(facts, 'city')
    const value =
      fact?.value ??
      findNote(notes, /\b(?:lives|based|living) in\b/i)?.replace(
        /^.*?\bin\s*/i,
        '',
      )
    return value
      ? `You are in ${value.replace(/[.]+$/, '')}, sir.`
      : 'I do not have your city on file, sir.'
  }

  if (/\bhow old am i\b|\bwhat(?:'s| is) my age\b/.test(text)) {
    const fact = slotFact(facts, 'age')
    if (fact) return `You are ${fact.value}, sir.`
    const birthday = slotFact(facts, 'birthday')
    const year = birthday ? /\b(19\d{2}|20\d{2})\b/.exec(birthday.value)?.[1] : null
    if (year) {
      const age = new Date().getUTCFullYear() - Number(year)
      return `You are ${age}, sir — going by ${year}.`
    }
    return 'I do not have your age on file, sir.'
  }

  if (
    /\bwhat do i do(?: for a living)?\b|\bwhat(?:'s| is) my job\b|\bwhere do i work\b|\bwhat do i work as\b/.test(
      text,
    )
  ) {
    const job = slotFact(facts, 'job')
    const company = slotFact(facts, 'company')
    if (job && company)
      return `You work as ${job.value} at ${company.value}, sir.`
    if (job) return `You work as ${job.value}, sir.`
    if (company) return `You work at ${company.value}, sir.`
    const note = findNote(notes, /\b(?:works?|job)\b/i)
    return note
      ? `${note.replace(/[.]+$/, '')}, sir.`
      : 'I do not have your work on file, sir.'
  }

  if (
    /\bwhat do you (?:remember|know|have) (?:about me|on me)\b|\bwhat have you (?:learned|noted|saved) about me\b|\bwhat do you remember\b/.test(
      text,
    )
  )
    return summary(facts, notes)

  return null
}
