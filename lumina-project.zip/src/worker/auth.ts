export type Env = {
  ASSETS: Fetcher
  DB?: D1Database
  /** Gemini API key, set as a project secret. */
  GEMINI_API_KEY?: string
  /** Optional Gemini model override. */
  GEMINI_MODEL?: string
  /** Optional override for the spoken-audio model. */
  GEMINI_TTS_MODEL?: string
  /** Single-owner login, supplied as project secrets. Never in the source. */
  LUMINA_USER_ID?: string
  LUMINA_PASSWORD?: string
  /** Signs session tokens. Set this to a random value so it survives a password change. */
  LUMINA_SESSION_SECRET?: string
}

export type Viewer = { sub: string; name?: string; email?: string }

/**
 * This app has exactly one owner. The credentials come from project secrets
 * (`LUMINA_USER_ID`, `LUMINA_PASSWORD`), so a repository copy never contains a
 * working login and rotating the password does not need a code change.
 */
const COOKIE = 'lumina_session'
const MAX_AGE_SECONDS = 60 * 60 * 24 * 30

type Owner = { id: string; password: string; secret: string }

/** The configured owner, or null when the deployment has no login set up. */
export const ownerOf = (env: Env): Owner | null => {
  const password = env.LUMINA_PASSWORD?.trim()
  if (!password) return null
  return {
    id: (env.LUMINA_USER_ID?.trim() || 'lumina').toLowerCase(),
    password,
    secret:
      env.LUMINA_SESSION_SECRET?.trim() || `lumina-session-v1:${password}`,
  }
}

const encoder = new TextEncoder()

const toBase64Url = (bytes: Uint8Array): string => {
  let binary = ''
  for (const byte of bytes) binary += String.fromCharCode(byte)
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

const signingKeys = new Map<string, Promise<CryptoKey>>()
const signingKey = (secret: string): Promise<CryptoKey> => {
  let key = signingKeys.get(secret)
  if (!key) {
    key = crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign'],
    )
    signingKeys.set(secret, key)
  }
  return key
}

const sign = async (secret: string, payload: string): Promise<string> =>
  toBase64Url(
    new Uint8Array(
      await crypto.subtle.sign(
        'HMAC',
        await signingKey(secret),
        encoder.encode(payload),
      ),
    ),
  )

/** Length-independent compare, so a wrong value cannot be probed by timing. */
const equal = (a: string, b: string): boolean => {
  if (a.length !== b.length) return false
  let diff = 0
  for (let index = 0; index < a.length; index += 1)
    diff |= a.charCodeAt(index) ^ b.charCodeAt(index)
  return diff === 0
}

export async function issueSession(env: Env): Promise<string> {
  const owner = ownerOf(env)
  if (!owner) throw new Error('Login is not configured.')
  const expires = Math.floor(Date.now() / 1000) + MAX_AGE_SECONDS
  return `${expires}.${await sign(owner.secret, `${owner.id}.${expires}`)}`
}

async function validSession(token: string, env: Env): Promise<boolean> {
  const owner = ownerOf(env)
  if (!owner) return false
  const [rawExpires, signature] = token.split('.')
  if (!rawExpires || !signature) return false
  const expires = Number(rawExpires)
  if (!Number.isFinite(expires) || expires * 1000 < Date.now()) return false
  return equal(await sign(owner.secret, `${owner.id}.${rawExpires}`), signature)
}

const readCookie = (request: Request, name: string): string | null => {
  const header = request.headers.get('cookie')
  if (!header) return null
  for (const part of header.split(';')) {
    const at = part.indexOf('=')
    if (at < 0) continue
    if (part.slice(0, at).trim() !== name) continue
    const value = part.slice(at + 1).trim()
    try {
      return decodeURIComponent(value)
    } catch {
      return value
    }
  }
  return null
}

const isSecure = (request: Request): boolean => {
  const url = new URL(request.url)
  return (
    url.protocol === 'https:' ||
    request.headers.get('x-forwarded-proto') === 'https' ||
    url.hostname.endsWith('.style.dev')
  )
}

export function sessionCookie(request: Request, token: string): string {
  const secure = isSecure(request) ? '; Secure' : ''
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${MAX_AGE_SECONDS}${secure}`
}

export function clearedSessionCookie(request: Request): string {
  const secure = isSecure(request) ? '; Secure' : ''
  return `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`
}

export type LoginResult = 'ok' | 'bad' | 'throttled' | 'unconfigured'

const MAX_FAILURES = 8
const LOCK_MS = 60_000
const attempts = new Map<string, { failures: number; until: number }>()

/** A few wrong guesses in a row pause logins for this address, not forever. */
export async function attemptLogin(
  userId: unknown,
  password: unknown,
  address: string,
  env: Env,
): Promise<LoginResult> {
  const owner = ownerOf(env)
  if (!owner) return 'unconfigured'
  const now = Date.now()
  const record = attempts.get(address)
  if (record && record.until > now && record.failures >= MAX_FAILURES)
    return 'throttled'

  const id = typeof userId === 'string' ? userId.trim().toLowerCase() : ''
  const pass = typeof password === 'string' ? password : ''
  const digests = await Promise.all([
    crypto.subtle.digest('SHA-256', encoder.encode(id)),
    crypto.subtle.digest('SHA-256', encoder.encode(pass)),
    crypto.subtle.digest('SHA-256', encoder.encode(owner.id)),
    crypto.subtle.digest('SHA-256', encoder.encode(owner.password)),
  ])
  const [idHash, passHash, expectedId, expectedPass] = digests.map((digest) =>
    toBase64Url(new Uint8Array(digest)),
  ) as [string, string, string, string]
  if (!equal(idHash, expectedId) || !equal(passHash, expectedPass)) {
    if (attempts.size > 500) attempts.clear()
    const failures = record && record.until > now ? record.failures + 1 : 1
    attempts.set(address, { failures, until: now + LOCK_MS })
    return 'bad'
  }
  attempts.delete(address)
  return 'ok'
}

/**
 * The session travels in the cookie, and also as a bearer token: an app shown
 * inside someone else's page (the preview panel) can have its cookie dropped by
 * third-party cookie blocking, and then a correct password would look like a
 * failed sign-in.
 */
export function tokenFromRequest(request: Request): string | null {
  const header = request.headers.get('authorization')
  if (header) {
    const match = /^Bearer\s+(.+)$/i.exec(header.trim())
    if (match?.[1]) return match[1].trim()
  }
  return readCookie(request, COOKIE)
}

export async function currentUser(
  request: Request,
  env: Env,
): Promise<Viewer | null> {
  const token = tokenFromRequest(request)
  if (!token) return null
  if (!(await validSession(token, env))) return null
  const owner = ownerOf(env)
  return owner ? { sub: owner.id, name: 'Lumina' } : null
}

/**
 * CSRF guard for state-changing requests: the Origin must be the host the
 * browser actually addressed. Behind a preview proxy the worker's own URL is
 * an internal host, so the forwarded Host header is compared too — it is the
 * value the browser used, and page JavaScript cannot set it.
 */
export function isTrustedMutation(request: Request): boolean {
  const origin = request.headers.get('origin')
  if (!origin || origin === 'null') return false
  let host: string
  try {
    host = new URL(origin).host.toLowerCase()
  } catch {
    return false
  }
  const own = [
    new URL(request.url).host,
    request.headers.get('host') ?? '',
    request.headers.get('x-forwarded-host') ?? '',
  ]
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean)
  return own.includes(host)
}
