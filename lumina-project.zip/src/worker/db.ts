import type {
  ChatMessage,
  Conversation,
  Fact,
  FactSlot,
  Memory,
  MemoryKind,
  Rule,
} from '../shared/types'
import { FACT_SLOTS } from '../shared/types'

const schema = [
  `CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    owner_sub TEXT NOT NULL,
    title TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS conversations_owner ON conversations(owner_sub, updated_at DESC)`,
  `CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    owner_sub TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS messages_conversation ON messages(conversation_id, created_at ASC, id ASC)`,
  `CREATE INDEX IF NOT EXISTS messages_owner ON messages(owner_sub)`,
  `CREATE TABLE IF NOT EXISTS rules (
    id TEXT PRIMARY KEY,
    owner_sub TEXT NOT NULL,
    text TEXT NOT NULL,
    source TEXT NOT NULL,
    created_at INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS rules_owner ON rules(owner_sub, created_at ASC)`,
  `CREATE TABLE IF NOT EXISTS settings (
    owner_sub TEXT PRIMARY KEY,
    data TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  // The legacy openrouter_key column is kept so older databases still open;
  // the app only reads and writes the Gemini key. Keys never leave the server.
  `CREATE TABLE IF NOT EXISTS api_keys (
    owner_sub TEXT PRIMARY KEY,
    gemini_key TEXT NOT NULL DEFAULT '',
    openrouter_key TEXT,
    updated_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    owner_sub TEXT NOT NULL,
    text TEXT NOT NULL,
    kind TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS memories_owner ON memories(owner_sub, updated_at DESC)`,
  // Confirmed personal facts, one row per slot. A slot holds one current value,
  // so a corrected birthday replaces the old one instead of sitting beside it.
  `CREATE TABLE IF NOT EXISTS facts (
    owner_sub TEXT NOT NULL,
    slot TEXT NOT NULL,
    value TEXT NOT NULL,
    updated_at INTEGER NOT NULL,
    PRIMARY KEY (owner_sub, slot)
  )`,
  // Full-text index over every message, so "what did we decide about the
  // invoice" can reach past conversations instead of only stored notes.
  `CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
    content,
    conversation_id UNINDEXED,
    owner_sub UNINDEXED,
    message_id UNINDEXED,
    tokenize = 'porter unicode61'
  )`,
  `CREATE TRIGGER IF NOT EXISTS messages_fts_add AFTER INSERT ON messages BEGIN
    INSERT INTO messages_fts (content, conversation_id, owner_sub, message_id)
    VALUES (new.content, new.conversation_id, new.owner_sub, new.id);
  END`,
  `CREATE TRIGGER IF NOT EXISTS messages_fts_remove AFTER DELETE ON messages BEGIN
    DELETE FROM messages_fts WHERE message_id = old.id;
  END`,
]

const ready = new WeakMap<D1Database, Promise<void>>()
export function ensureSchema(db: D1Database): Promise<void> {
  let pending = ready.get(db)
  if (!pending) {
    pending = db
      .batch(schema.map((sql) => db.prepare(sql)))
      // Databases created before the second key column existed need it.
      // SQLite refuses to add a column twice, so a failure here is expected.
      .then(() =>
        db
          .prepare('ALTER TABLE api_keys ADD COLUMN openrouter_key TEXT')
          .run()
          .catch(() => undefined),
      )
      // Provenance and persona version arrived later; older databases need the
      // columns added, and SQLite refuses to add one twice.
      .then(() =>
        Promise.all(
          [
            'ALTER TABLE conversations ADD COLUMN persona_version INTEGER NOT NULL DEFAULT 0',
            'ALTER TABLE rules ADD COLUMN source_message_id TEXT',
            'ALTER TABLE memories ADD COLUMN source_message_id TEXT',
          ].map((sql) => db.prepare(sql).run().catch(() => undefined)),
        ),
      )
      // Messages written before the index existed are indexed once.
      .then(() =>
        db
          .prepare(
            'INSERT INTO messages_fts (content, conversation_id, owner_sub, message_id) SELECT content, conversation_id, owner_sub, id FROM messages WHERE id NOT IN (SELECT message_id FROM messages_fts)',
          )
          .run()
          .catch(() => undefined),
      )
      .then(() => undefined)
      .catch((error) => {
        ready.delete(db)
        throw error
      })
    ready.set(db, pending)
  }
  return pending
}

export type ConversationRow = {
  id: string
  title: string
  created_at: number
  updated_at: number
}
export const mapConversation = (row: ConversationRow): Conversation => ({
  id: row.id,
  title: row.title,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
})

export type MessageRow = {
  id: string
  conversation_id: string
  role: string
  content: string
  created_at: number
}
export const mapMessage = (row: MessageRow): ChatMessage => ({
  id: row.id,
  conversationId: row.conversation_id,
  role: row.role === 'assistant' ? 'assistant' : 'user',
  content: row.content,
  createdAt: row.created_at,
})

export type RuleRow = {
  id: string
  text: string
  source: string
  created_at: number
}
export const mapRule = (row: RuleRow): Rule => ({
  id: row.id,
  text: row.text,
  source: row.source === 'manual' ? 'manual' : 'auto',
  createdAt: row.created_at,
})

export type MemoryRow = {
  id: string
  text: string
  kind: string
  created_at: number
  updated_at: number
}
const KINDS: MemoryKind[] = ['fact', 'preference', 'note']
export const mapMemory = (row: MemoryRow): Memory => ({
  id: row.id,
  text: row.text,
  kind: KINDS.includes(row.kind as MemoryKind)
    ? (row.kind as MemoryKind)
    : 'fact',
  createdAt: row.created_at,
  updatedAt: row.updated_at,
})

export type FactRow = {
  slot: string
  value: string
  updated_at: number
}
export const mapFact = (row: FactRow): Fact => ({
  slot: row.slot as FactSlot,
  value: row.value,
  updatedAt: row.updated_at,
})
export const isFactSlot = (value: unknown): value is FactSlot =>
  FACT_SLOTS.includes(value as FactSlot)

/** Two notes that differ only in case or punctuation are the same note. */
export const memoryKey = (text: string): string =>
  text
    .toLowerCase()
    .replace(/[^a-z0-9 ]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()

/** The words in a note, used to rank which memories matter for a message. */
export const memoryWords = (text: string): Set<string> =>
  new Set(
    memoryKey(text)
      .split(' ')
      .filter((word) => word.length > 2),
  )

/**
 * Near-duplicates matter as much as exact ones: a model will happily rephrase
 * "Lives in Pune" as "Is based in Pune" and memory fills up with the same fact.
 * Anything sharing most of its words with an existing note is skipped.
 */
export const similarMemory = (a: string, b: string): boolean => {
  const left = memoryWords(a)
  const right = memoryWords(b)
  if (!left.size || !right.size) return memoryKey(a) === memoryKey(b)
  let shared = 0
  for (const word of left) if (right.has(word)) shared += 1
  return shared / Math.min(left.size, right.size) >= 0.7
}

/**
 * Earlier turns from other conversations that share words with this message.
 * The assistant reads them as context, not as instructions.
 */
export type PastMessage = {
  content: string
  role: string
  createdAt: number
  title: string
  conversationId: string
}

export async function searchPastMessages(
  db: D1Database,
  owner: string,
  text: string,
  excludeConversation: string,
): Promise<PastMessage[]> {
  const words = [...memoryWords(text)].filter((word) => word.length > 3).slice(0, 8)
  if (!words.length) return []
  // FTS5 treats punctuation and operators as syntax, so each term is quoted.
  const query = words.map((word) => `"${word.replace(/"/g, '')}"`).join(' OR ')
  try {
    const rows = await db
      .prepare(
        `SELECT m.content, m.role, m.created_at, c.title, m.conversation_id
         FROM messages_fts f
         JOIN messages m ON m.id = f.message_id
         JOIN conversations c ON c.id = m.conversation_id
         WHERE f MATCH ? AND f.owner_sub = ? AND m.conversation_id <> ?
         ORDER BY rank LIMIT 6`,
      )
      .bind(query, owner, excludeConversation)
      .all<{
        content: string
        role: string
        created_at: number
        title: string
        conversation_id: string
      }>()
    return rows.results.map((row) => ({
      content: row.content.replace(/\s+/g, ' ').trim().slice(0, 400),
      role: row.role,
      createdAt: row.created_at,
      title: row.title,
      conversationId: row.conversation_id,
    }))
  } catch {
    // A database without FTS5 still answers; it just cannot search history.
    return []
  }
}

/**
 * Merge notes that say the same thing. Memory is append-only by nature, and
 * without this the prompt slowly fills with rephrasings of the same few facts.
 */
export async function consolidateMemories(
  db: D1Database,
  owner: string,
): Promise<number> {
  const rows = await db
    .prepare(
      'SELECT id, text, kind, created_at, updated_at FROM memories WHERE owner_sub = ? ORDER BY updated_at DESC',
    )
    .bind(owner)
    .all<MemoryRow>()
  const kept: Memory[] = []
  const removed: string[] = []
  for (const row of rows.results.map(mapMemory)) {
    if (kept.some((note) => similarMemory(note.text, row.text))) removed.push(row.id)
    else kept.push(row)
  }
  if (!removed.length) return 0
  for (let index = 0; index < removed.length; index += 40)
    await db.batch(
      removed
        .slice(index, index + 40)
        .map((id) =>
          db
            .prepare('DELETE FROM memories WHERE id = ? AND owner_sub = ?')
            .bind(id, owner),
        ),
    )
  return removed.length
}

/** The account's own Gemini key. Read server-side only; never sent out. */
export type StoredKeys = { gemini: string | null }

export async function readApiKeys(
  db: D1Database,
  owner: string,
): Promise<StoredKeys> {
  const row = await db
    .prepare('SELECT gemini_key FROM api_keys WHERE owner_sub = ?')
    .bind(owner)
    .first<{ gemini_key?: string }>()
  return { gemini: row?.gemini_key?.trim() || null }
}

/** One key per account: Gemini is the only brain. */
export async function saveApiKey(
  db: D1Database,
  owner: string,
  key: string,
): Promise<void> {
  await db
    .prepare(
      `INSERT INTO api_keys (owner_sub, gemini_key, updated_at)
       VALUES (?, ?, ?)
       ON CONFLICT(owner_sub) DO UPDATE SET
         gemini_key = excluded.gemini_key,
         updated_at = excluded.updated_at`,
    )
    .bind(owner, key, Date.now())
    .run()
}

export async function clearApiKey(
  db: D1Database,
  owner: string,
): Promise<void> {
  await db
    .prepare('DELETE FROM api_keys WHERE owner_sub = ?')
    .bind(owner)
    .run()
}

/** What a rule is about, so two rules only clash on the same subject. */
const RULE_TOPICS: [string, RegExp][] = [
  ['length', /\b(?:short|shorter|brief|concise|words?|lines?|sentences?|long|longer|paragraphs?)\b/i],
  ['language', /\b(?:english|spanish|french|german|hindi|language|translate)\b/i],
  ['format', /\b(?:bullets?|list|numbered|markdown|table|code)\b/i],
  ['tone', /\b(?:tone|casual|formal|corporate|robotic|friendly|funny)\b/i],
  ['emoji', /\bemoji\b/i],
  ['units', /\b(?:metric|imperial|units|inches|celsius|fahrenheit)\b/i],
  ['address', /\b(?:call me|first name)\b/i],
  ['web', /\b(?:web|internet|sources?|links?|citations?)\b/i],
]

const ruleTopics = (text: string): Set<string> =>
  new Set(
    RULE_TOPICS.filter(([, pattern]) => pattern.test(text)).map(([topic]) => topic),
  )

/**
 * Two rules teach the same lesson when they are worded almost the same, or
 * when they are about the same subject and share most of their words. "Keep
 * all answers to two short lines" and "Keep every answer to two lines
 * maximum" are one rule, not two.
 */
export const sameLesson = (a: string, b: string): boolean => {
  if (similarMemory(a, b)) return true
  const left = ruleTopics(a)
  const right = ruleTopics(b)
  if (![...left].some((topic) => right.has(topic))) return false
  const wordsA = memoryWords(a)
  const wordsB = memoryWords(b)
  let shared = 0
  for (const word of wordsA) if (wordsB.has(word)) shared += 1
  return shared / Math.max(1, Math.min(wordsA.size, wordsB.size)) >= 0.4
}

/** Comparison key so the same lesson is never stored twice. */
export const ruleKey = (text: string): string =>
  text
    .toLowerCase()
    .replace(/[^a-z0-9\u00c0-\uffff\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()

export async function readFacts(
  db: D1Database,
  owner: string,
): Promise<Fact[]> {
  const rows = await db
    .prepare(
      'SELECT slot, value, updated_at FROM facts WHERE owner_sub = ? ORDER BY updated_at DESC',
    )
    .bind(owner)
    .all<FactRow>()
  return rows.results.map(mapFact)
}

/**
 * Store or correct one fact. A new value for the same slot wins, which is what
 * makes "actually my birthday is 31 October" repair the old answer.
 */
export async function saveFact(
  db: D1Database,
  owner: string,
  slot: FactSlot,
  value: string,
): Promise<Fact> {
  const updatedAt = Date.now()
  await db
    .prepare(
      'INSERT INTO facts (owner_sub, slot, value, updated_at) VALUES (?, ?, ?, ?) ON CONFLICT(owner_sub, slot) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at',
    )
    .bind(owner, slot, value, updatedAt)
    .run()
  return { slot, value, updatedAt }
}

export async function clearFact(
  db: D1Database,
  owner: string,
  slot: FactSlot,
): Promise<boolean> {
  const removed = await db
    .prepare(
      'DELETE FROM facts WHERE owner_sub = ? AND slot = ? RETURNING slot',
    )
    .bind(owner, slot)
    .first()
  return Boolean(removed)
}
