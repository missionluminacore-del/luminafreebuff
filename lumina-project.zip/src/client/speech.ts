/**
 * Thin wrappers around the browser Speech APIs. Both are free and local to the
 * device: speech recognition never touches our server.
 */

type Alternative = { transcript: string }
type ResultItem = { isFinal: boolean; length: number; [index: number]: Alternative }
export type SpeechResults = {
  resultIndex: number
  length: number
  [index: number]: ResultItem
}
export type SpeechErrorEvent = { error: string; message?: string }

export type RecognitionLike = {
  lang: string
  continuous: boolean
  interimResults: boolean
  maxAlternatives: number
  start(): void
  stop(): void
  abort(): void
  onresult: ((event: SpeechResults) => void) | null
  onerror: ((event: SpeechErrorEvent) => void) | null
  onend: (() => void) | null
  onstart: (() => void) | null
}

type RecognitionCtor = new () => RecognitionLike

function recognitionCtor(): RecognitionCtor | undefined {
  if (typeof window === 'undefined') return undefined
  const scope = window as unknown as {
    SpeechRecognition?: RecognitionCtor
    webkitSpeechRecognition?: RecognitionCtor
  }
  return scope.SpeechRecognition ?? scope.webkitSpeechRecognition
}

export function speechSupported(): boolean {
  return Boolean(recognitionCtor())
}

/**
 * Continuous mode is what makes a hands-free conversation possible: the
 * recogniser keeps listening after the first sentence instead of stopping at
 * every pause.
 */
export function createRecognition(
  lang: string,
  continuous = false,
): RecognitionLike | null {
  const Ctor = recognitionCtor()
  if (!Ctor) return null
  const recognition = new Ctor()
  recognition.lang = lang || 'en-US'
  recognition.continuous = continuous
  recognition.interimResults = true
  recognition.maxAlternatives = 1
  return recognition
}

export function speechError(error: string): string {
  switch (error) {
    case 'not-allowed':
    case 'service-not-allowed':
      return 'Microphone access is blocked. Allow the mic for this site — if this is the preview panel, open the app in its own tab and try again.'
    case 'no-speech':
      return 'I did not catch that. Try again, a little closer to the mic.'
    case 'audio-capture':
      return 'No microphone found on this device.'
    case 'network':
      return 'Voice input needs a connection to your browser’s speech service.'
    default:
      return 'Voice input stopped working. Try again.'
  }
}

export function ttsSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window
}

export function listVoices(): SpeechSynthesisVoice[] {
  if (!ttsSupported()) return []
  return window.speechSynthesis.getVoices()
}

/**
 * Rank the device voices instead of taking the first one. The system default is
 * often the flattest voice on the machine; the natural and network voices read
 * noticeably better, so they are preferred for the same language.
 */
function preferredVoice(
  voices: SpeechSynthesisVoice[],
  lang = 'en',
): SpeechSynthesisVoice | undefined {
  const base = (lang || 'en').slice(0, 2).toLowerCase()
  const matching = voices.filter((voice) =>
    voice.lang.toLowerCase().startsWith(base),
  )
  const pool = matching.length ? matching : voices
  const score = (voice: SpeechSynthesisVoice): number => {
    let value = 0
    if (/natural|neural|enhanced|premium|siri/i.test(voice.name)) value += 6
    if (/google/i.test(voice.name)) value += 4
    if (/microsoft/i.test(voice.name)) value += 2
    if (/aria|jenny|libby|sonia|samantha|serena|daniel|guy|ava|zoe/i.test(voice.name))
      value += 3
    if (!voice.localService) value += 1
    return value
  }
  return [...pool].sort((a, b) => score(b) - score(a))[0]
}

/** Markdown noise removed so replies read cleanly out loud. */
export function forSpeech(text: string, limit = 1200): string {
  const plain = text
    .replace(/```[\s\S]*?```/g, ' Code block omitted. ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/!\[[^\]]*]\([^)]*\)/g, '')
    .replace(/\[([^\]]+)]\([^)]*\)/g, '$1')
    .replace(/https?:\/\/\S+/g, '')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/\|/g, ', ')
    .replace(/[*_~>#]/g, '')
    .replace(/^\s*[-+•]\s+/gm, '')
    .replace(/\s+/g, ' ')
    .trim()
  if (plain.length <= limit) return plain
  const cut = plain.slice(0, limit)
  const stop = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('? '), cut.lastIndexOf('! '))
  return stop > 120 ? cut.slice(0, stop + 1) : `${cut.trimEnd()}…`
}

/**
 * One utterance per sentence or two. Chrome silently stops long utterances
 * after about fifteen seconds, and a queue lets a spoken answer be interrupted
 * cleanly instead of playing to the end.
 */
function chunksOf(text: string): string[] {
  const plain = forSpeech(text)
  const sentences = plain.match(/[^.!?…]+[.!?…]*\s*/g) ?? [plain]
  const chunks: string[] = []
  let current = ''
  for (const sentence of sentences) {
    const piece = sentence.trim()
    if (!piece) continue
    if (current && (current + ' ' + piece).length > 240) {
      chunks.push(current)
      current = piece
    } else {
      current = current ? `${current} ${piece}` : piece
    }
  }
  if (current) chunks.push(current)
  return chunks.slice(0, 14)
}

let pending: string[] = []
let generation = 0
let activeVoice = ''
let activeEnd: (() => void) | undefined
let activeVolume = 0.9
let activeLang = 'en-US'
let pauseTimer: number | undefined
let watchdog: number | undefined
/** When the synthesizer last started a word, in ms. Drives the visual pace. */
let boundaryAt = 0

function finish() {
  const done = activeEnd
  activeEnd = undefined
  done?.()
}

function speakNext() {
  if (!pending.length) {
    finish()
    return
  }
  const chunk = pending.shift()!
  const utterance = new SpeechSynthesisUtterance(chunk)
  const voices = listVoices()
  const chosen =
    (activeVoice ? voices.find((voice) => voice.name === activeVoice) : undefined) ??
    preferredVoice(voices, activeLang)
  if (chosen) {
    utterance.voice = chosen
    utterance.lang = chosen.lang
  }
  utterance.rate = 0.98
  utterance.pitch = 1
  utterance.volume = activeVolume
  // Chrome and Safari fire this per word, so the core can follow real speech
  // cadence rather than a fixed animation.
  utterance.onboundary = () => {
    boundaryAt = performance.now()
  }
  const token = generation
  // A short breath between sentences: the synthesizer queues them back to back
  // otherwise, which is the main reason device voices sound rushed.
  const advance = () => {
    window.clearTimeout(watchdog)
    watchdog = undefined
    if (token !== generation) return
    window.clearTimeout(pauseTimer)
    pauseTimer = window.setTimeout(() => {
      pauseTimer = undefined
      if (token === generation) speakNext()
    }, 120)
  }
  utterance.onend = advance
  utterance.onerror = advance
  window.speechSynthesis.speak(utterance)
  // Some browsers accept an utterance and then never report anything: no
  // audio, no end event. Without this the interface would sit in "speaking"
  // forever, so the turn is closed on a generous timer instead.
  window.clearTimeout(watchdog)
  watchdog = window.setTimeout(
    () => {
      if (token !== generation) return
      try {
        window.speechSynthesis.cancel()
      } catch {
        // Nothing to cancel.
      }
      advance()
    },
    1_400 + chunk.length * 120,
  )
}

export function speak(
  text: string,
  voiceName: string,
  onEnd: () => void,
  options: { volume?: number; lang?: string } = {},
): boolean {
  if (!ttsSupported()) return false
  const chunks = chunksOf(text)
  if (!chunks.length) return false
  stopSpeaking()
  generation += 1
  pending = chunks
  activeVoice = voiceName
  activeEnd = onEnd
  activeVolume =
    typeof options.volume === 'number'
      ? Math.min(1, Math.max(0, options.volume))
      : activeVolume
  activeLang = options.lang || activeLang
  speakNext()
  return true
}

export function stopSpeaking(): void {
  if (!ttsSupported()) return
  generation += 1
  pending = []
  activeEnd = undefined
  boundaryAt = 0
  window.clearTimeout(pauseTimer)
  pauseTimer = undefined
  window.clearTimeout(watchdog)
  watchdog = undefined
  window.speechSynthesis.cancel()
}

/**
 * 0..1 activity of the spoken reply, from the synthesizer's own word-boundary
 * events. Browsers do not expose synthesized audio for analysis, so cadence is
 * the closest real signal available; when no boundary arrives the carrier keeps
 * the core moving instead of freezing.
 */
export function speechEnergy(): number {
  if (!ttsSupported() || !window.speechSynthesis.speaking) return 0
  const now = performance.now()
  const since = boundaryAt ? now - boundaryAt : 2000
  const word = Math.exp(-since / 190)
  const carrier = 0.5 + 0.5 * Math.sin(now / 74) * Math.cos(now / 173)
  return Math.min(1, 0.16 + word * 0.72 + Math.abs(carrier) * 0.14)
}

export function speakingNow(): boolean {
  if (!ttsSupported()) return false
  return window.speechSynthesis.speaking
}
