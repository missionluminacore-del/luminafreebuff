/**
 * Real microphone amplitude, used to drive the core while it listens.
 *
 * The stream is opened only for the moment the assistant is listening, and
 * closed again as soon as it stops, so the microphone is never live in the
 * background. Speech recognition uses the same device through its own channel;
 * browsers allow both at once.
 */

let context: AudioContext | null = null
let analyser: AnalyserNode | null = null
let stream: MediaStream | null = null
let data: Uint8Array<ArrayBuffer> | null = null
let smoothed = 0
let enabling: Promise<boolean> | null = null

export async function enableMic(): Promise<boolean> {
  if (stream) return true
  if (enabling) return enabling
  enabling = (async () => {
    try {
      const media = navigator.mediaDevices
      if (!media?.getUserMedia) return false
      stream = await media.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      })
      const Ctor =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext
      if (!Ctor) return false
      context = new Ctor()
      if (context.state === 'suspended') await context.resume()
      const source = context.createMediaStreamSource(stream)
      analyser = context.createAnalyser()
      analyser.fftSize = 1024
      analyser.smoothingTimeConstant = 0.72
      source.connect(analyser)
      data = new Uint8Array(analyser.fftSize)
      return true
    } catch {
      // A blocked or missing microphone is reported by speech recognition.
      disableMic()
      return false
    } finally {
      enabling = null
    }
  })()
  return enabling
}

/**
 * 0..1 loudness. Speech sits around 0.15–0.4, so the curve lifts quiet speech
 * without making room noise visible.
 */
export function micLevel(): number {
  if (!analyser || !data) return 0
  analyser.getByteTimeDomainData(data)
  let sum = 0
  for (let index = 0; index < data.length; index += 1) {
    const value = (data[index]! - 128) / 128
    sum += value * value
  }
  const rms = Math.sqrt(sum / data.length)
  const shaped = Math.min(1, Math.pow(rms * 4.6, 0.85))
  smoothed = smoothed * 0.6 + shaped * 0.4
  return smoothed
}

export function disableMic(): void {
  for (const track of stream?.getTracks() ?? []) track.stop()
  stream = null
  analyser = null
  data = null
  smoothed = 0
  void context?.close().catch(() => undefined)
  context = null
}

export function micActive(): boolean {
  return Boolean(stream)
}
