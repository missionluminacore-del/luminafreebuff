import * as THREE from 'three'

/**
 * The core: one continuous silk ribbon, folded into a slowly breathing loop.
 *
 * The band is a real swept surface — its spine is a closed curve that drifts on
 * several sine harmonics, its width breathes, and its face twists as it travels
 * the loop. Shading is a two-light sheen with fine hairline filaments, so it
 * reads as lit fabric rather than a glowing orb.
 *
 * Nothing repeats frame to frame; the noise-free drift is enough to keep it
 * alive without ever looking like a loop.
 */

export type CoreState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'error'

export type Core = {
  setState(state: CoreState): void
  flashError(): void
  /** A short white swell, so every touch visibly lands on the core. */
  pulse(): void
  resize(): void
  dispose(): void
}

type Preset = {
  energy: number
  interference: number
  red: number
  /** Speed multiplier for the drift. */
  speed: number
  react: number
}

/**
 * Speeds are deliberately slow: the loop should read as a thing turning over in
 * its own time, not a spinner. Every state changes pace and grain, never colour.
 */
const PRESETS: Record<CoreState, Preset> = {
  idle: { energy: 0.2, interference: 0.05, red: 0.02, speed: 0.3, react: 0.3 },
  listening: {
    energy: 0.5,
    interference: 0.07,
    red: 0.03,
    speed: 0.4,
    react: 1.25,
  },
  thinking: {
    energy: 0.78,
    interference: 0.32,
    red: 0.4,
    speed: 0.9,
    react: 0.35,
  },
  speaking: {
    energy: 0.62,
    interference: 0.06,
    red: 0.05,
    speed: 0.48,
    react: 1.3,
  },
  error: {
    energy: 0.42,
    interference: 0.5,
    red: 0.8,
    speed: 0.45,
    react: 0.2,
  },
}

const TAU = Math.PI * 2

const VERTEX = /* glsl */ `
  varying vec3 vWorld;
  varying vec3 vNormal;
  varying vec2 vUv;
  void main() {
    vec4 world = modelMatrix * vec4(position, 1.0);
    vWorld = world.xyz;
    vNormal = normalize(mat3(modelMatrix) * normal);
    vUv = uv;
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`

const FRAGMENT = /* glsl */ `
  uniform float uTime, uEnergy, uRed, uBright, uInterference, uHover, uPulse;
  varying vec3 vWorld;
  varying vec3 vNormal;
  varying vec2 vUv;

  void main() {
    vec3 N = normalize(vNormal);
    vec3 V = normalize(cameraPosition - vWorld);
    if (dot(N, V) < 0.0) N = -N;

    vec3 L1 = normalize(vec3(-0.5, 0.72, 0.8));
    vec3 L2 = normalize(vec3(0.7, -0.45, 0.3));
    vec3 H1 = normalize(L1 + V);
    vec3 H2 = normalize(L2 + V);

    float face = clamp(abs(dot(N, V)), 0.0, 1.0);
    float rim = pow(1.0 - face, 2.2);
    float glint = pow(max(dot(N, H1), 0.0), 12.0);

    // Fine filaments running the length of the band: the silk grain.
    float thread =
      0.74 + 0.26 * sin(vUv.y * 30.0 + sin(vUv.x * 5.0 + uTime * 0.3) * 1.3);

    // One edge of the fold catches the light, the other turns into the dark.
    float tone =
      mix(0.62, 1.2, smoothstep(0.12, 0.5, vUv.y)) *
      mix(1.0, 0.56, smoothstep(0.58, 0.96, vUv.y));

    // A slow light travelling round the loop, so it never sits static.
    float sweep = 0.7 + 0.3 * sin(vUv.x * 8.0 - uTime * 0.18 + 0.8);

    float lum = (0.42 + rim * 1.05 + glint * 0.9) * tone * sweep * thread;
    vec3 col = vec3(lum) * 1.55;
    col += vec3(0.75, 0.05, 0.06) * uRed * (rim * 0.55 + glint * 0.3);
    // The whole surface lifts when the pointer is close, and flashes on touch.
    col *= 1.0 + uHover * 0.28 + uPulse * 0.85;

    float across = abs(vUv.y * 2.0 - 1.0);
    float alpha =
      smoothstep(1.0, 0.84, across) *
      (0.6 + rim * 0.42 + glint * 0.22) *
      uBright;
    alpha *= 0.9 + uEnergy * 0.25;
    alpha = min(1.0, alpha + uPulse * 0.18);

    gl_FragColor = vec4(col, clamp(alpha, 0.0, 1.0));
  }
`

type RibbonOptions = {
  radius: number
  width: number
  twist: number
  segments: number
  across: number
  phase: number
  brightness: number
  cup: number
}

function createRibbon(
  uniforms: Record<string, THREE.IUniform>,
  options: RibbonOptions,
) {
  const { segments, across } = options
  const vertices = (segments + 1) * across
  const positions = new Float32Array(vertices * 3)
  const normals = new Float32Array(vertices * 3)
  const uvs = new Float32Array(vertices * 2)
  const indices: number[] = []

  for (let row = 0; row < segments; row += 1) {
    for (let column = 0; column < across - 1; column += 1) {
      const a = row * across + column
      const b = a + 1
      const c = a + across
      const d = c + 1
      indices.push(a, c, b, b, c, d)
    }
  }

  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
  geometry.setAttribute('normal', new THREE.BufferAttribute(normals, 3))
  geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2))
  geometry.setIndex(indices)

  for (let row = 0; row <= segments; row += 1) {
    for (let column = 0; column < across; column += 1) {
      const index = row * across + column
      uvs[index * 2] = row / segments
      uvs[index * 2 + 1] = column / (across - 1)
    }
  }

  const material = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: VERTEX,
    fragmentShader: FRAGMENT,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
  })

  const mesh = new THREE.Mesh(geometry, material)
  mesh.frustumCulled = false

  // Scratch vectors, reused every frame; no allocation in the loop.
  const point = new THREE.Vector3()
  const ahead = new THREE.Vector3()
  const tangent = new THREE.Vector3()
  const side = new THREE.Vector3()
  const lift = new THREE.Vector3()
  const acrossDir = new THREE.Vector3()
  const normal = new THREE.Vector3()
  const widthTangent = new THREE.Vector3()

  const spine = (u: number, time: number, out: THREE.Vector3) => {
    const drift = time * 0.055
    const radius =
      options.radius *
      (1 +
        0.1 * Math.sin(2 * u + drift * 1.4 + options.phase) +
        0.06 * Math.sin(3 * u - drift * 1.1 + options.phase * 1.7) +
        0.025 * Math.sin(5 * u + 1.3))
    const height =
      options.radius *
      (0.26 * Math.sin(2 * u + drift * 1.2 + options.phase) +
        0.12 * Math.sin(3 * u - drift * 0.9) +
        0.06 * Math.sin(5 * u + drift * 1.7))
    // The loop faces the viewer; height is its drift towards and away from us.
    out.set(Math.cos(u) * radius, Math.sin(u) * radius * 0.94, height)
    return out
  }

  function update(time: number, energy: number, react: number) {
    const boost = 1 + energy * 0.45 + react * 0.3
    for (let row = 0; row <= segments; row += 1) {
      const u = (row / segments) * TAU
      spine(u, time, point)
      spine(u + 0.004, time, ahead)
      tangent.copy(ahead).sub(point).normalize()

      // A stable frame around the spine.
      side.set(0, 1, 0).cross(tangent)
      if (side.lengthSq() < 1e-4) side.set(1, 0, 0).cross(tangent)
      side.normalize()
      lift.copy(tangent).cross(side).normalize()

      const twist =
        options.twist * u +
        0.45 * Math.sin(2 * u + time * 0.16) +
        time * 0.08 +
        options.phase
      acrossDir.copy(side).multiplyScalar(Math.cos(twist))
      acrossDir.addScaledVector(lift, Math.sin(twist))

      const width =
        options.width *
        (0.74 + 0.26 * Math.sin(3 * u + time * 0.22 + options.phase)) *
        boost
      normal.copy(acrossDir).cross(tangent).normalize()

      for (let column = 0; column < across; column += 1) {
        const a = (column / (across - 1)) * 2 - 1
        const index = row * across + column
        const cup = options.cup * (1 - a * a)
        positions[index * 3] = point.x + acrossDir.x * a * width + normal.x * cup
        positions[index * 3 + 1] =
          point.y + acrossDir.y * a * width + normal.y * cup
        positions[index * 3 + 2] =
          point.z + acrossDir.z * a * width + normal.z * cup

        // The band is cupped across its width, so its surface turns away from
        // the viewer towards the edges. Per-vertex normals give the silk its
        // gradient instead of one flat tone.
        widthTangent
          .copy(acrossDir)
          .multiplyScalar(width)
          .addScaledVector(normal, -2 * options.cup * a)
        widthTangent.cross(tangent).normalize()
        if (widthTangent.dot(normal) < 0) widthTangent.negate()
        normals[index * 3] = widthTangent.x
        normals[index * 3 + 1] = widthTangent.y
        normals[index * 3 + 2] = widthTangent.z
      }
    }
    geometry.attributes.position!.needsUpdate = true
    geometry.attributes.normal!.needsUpdate = true
  }

  return { mesh, update }
}

export function createCore(
  canvas: HTMLCanvasElement,
  options: { level?: () => number; reducedMotion?: boolean } = {},
): Core {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: 'high-performance',
  })
  renderer.setClearColor(0x000000, 1)
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75))

  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 60)
  camera.position.set(0, 0, 5.4)

  const U: Record<string, THREE.IUniform> = {
    uTime: { value: 0 },
    uEnergy: { value: PRESETS.idle.energy },
    uReact: { value: 0 },
    uRed: { value: 0 },
    uInterference: { value: PRESETS.idle.interference },
    uBright: { value: 1.2 },
    uHover: { value: 0 },
    uPulse: { value: 0 },
  }

  const group = new THREE.Group()
  scene.add(group)

  const main = createRibbon(U, {
    radius: 1.18,
    width: 0.24,
    twist: 1.72,
    segments: 360,
    across: 26,
    phase: 0,
    brightness: 1,
    cup: 0.1,
  })
  group.add(main.mesh)

  const veil = createRibbon(
    { ...U, uBright: { value: 0.38 } },
    {
      radius: 1.16,
      width: 0.4,
      twist: 1.35,
      segments: 260,
      across: 14,
      phase: 1.9,
      brightness: 0.3,
      cup: 0.1,
    },
  )
  veil.mesh.scale.setScalar(1.01)
  group.add(veil.mesh)

  // A single fine filament threading the loop, like a stray thread of silk.
  const filament = createRibbon(
    { ...U, uBright: { value: 0.78 } },
    {
      radius: 1.2,
      width: 0.008,
      twist: 2.1,
      segments: 300,
      across: 3,
      phase: 3.4,
      brightness: 0.8,
      cup: 0,
    },
  )
  group.add(filament.mesh)

  // A second, thinner thread running the other way: two hairs catching the
  // light read as more intricate than one.
  const thread = createRibbon(
    { ...U, uBright: { value: 0.55 } },
    {
      radius: 1.24,
      width: 0.005,
      twist: -2.4,
      segments: 280,
      across: 3,
      phase: 5.1,
      brightness: 0.6,
      cup: 0,
    },
  )
  group.add(thread.mesh)

  /* ------------------------------------------------- incomplete orbit dust */

  /**
   * Fine matter on broken orbital tracks: each arc covers part of a circle and
   * then simply stops, so the structure never closes into a ring. Sizes are in
   * world units and the shader keeps them visible without becoming stars.
   */
  const orbit = (() => {
    const ARCS = [
      { radius: 1.34, tilt: [0.55, 0.2, 0.05], span: 4.1, start: 0.4, share: 0.22 },
      { radius: 1.52, tilt: [-0.35, 0.85, 0.28], span: 3.2, start: 2.3, share: 0.18 },
      { radius: 1.72, tilt: [0.95, -0.3, -0.18], span: 2.4, start: 4.1, share: 0.14 },
      { radius: 1.4, tilt: [1.35, 0.55, 0.45], span: 4.8, start: 1.2, share: 0.16 },
    ]
    const DUST = 520
    const ARC_POINTS = 900
    const total = DUST + ARC_POINTS
    const positions = new Float32Array(total * 3)
    const seeds = new Float32Array(total)
    const sizes = new Float32Array(total)
    const vector = new THREE.Vector3()
    let cursor = 0

    const write = (point: THREE.Vector3, seed: number, size: number) => {
      positions[cursor * 3] = point.x
      positions[cursor * 3 + 1] = point.y
      positions[cursor * 3 + 2] = point.z
      seeds[cursor] = seed
      sizes[cursor] = size
      cursor += 1
    }

    for (const arc of ARCS) {
      const count = Math.round(ARC_POINTS * arc.share * 4)
      const rotation = new THREE.Euler(arc.tilt[0]!, arc.tilt[1]!, arc.tilt[2]!)
      for (let index = 0; index < count; index += 1) {
        const along = index / Math.max(1, count - 1)
        const angle = arc.start + along * arc.span
        const radius = arc.radius + (Math.random() - 0.5) * 0.05
        const thickness = (Math.random() - 0.5) * 0.035
        vector
          .set(Math.cos(angle) * radius, Math.sin(angle) * radius, thickness)
          .applyEuler(rotation)
        write(vector, Math.random(), 0.9 + Math.random() * 1.5)
      }
    }

    for (let index = 0; index < DUST; index += 1) {
      const radius = 1.2 + Math.random() * 0.85
      const theta = Math.random() * TAU
      const phi = Math.acos(2 * Math.random() - 1)
      vector.set(
        Math.sin(phi) * Math.cos(theta) * radius,
        Math.sin(phi) * Math.sin(theta) * radius * 0.9,
        Math.cos(phi) * radius * 0.55,
      )
      write(vector, Math.random(), 0.5 + Math.random() * 0.9)
    }

    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geometry.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 1))
    geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1))
    const material = new THREE.ShaderMaterial({
      uniforms: U,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: /* glsl */ `
        attribute float aSeed;
        attribute float aSize;
        uniform float uTime, uEnergy, uInterference, uBright;
        varying float vAlpha;
        void main() {
          vec3 p = position * (1.0 + 0.012 * sin(uTime * 0.35 + aSeed * 6.283));
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          float twinkle = 0.5 + 0.5 * sin(uTime * (0.5 + aSeed * 0.8) + aSeed * 31.0);
          gl_PointSize = aSize * (1.0 + uEnergy * 1.4) * (14.0 / max(0.001, -mv.z));
          vAlpha = (0.2 + 0.5 * twinkle) * (1.0 + uInterference * 0.6) * uBright;
        }
      `,
      fragmentShader: /* glsl */ `
        varying float vAlpha;
        void main() {
          vec2 c = gl_PointCoord - 0.5;
          float d = length(c);
          if (d > 0.5) discard;
          float edge = smoothstep(0.5, 0.04, d);
          gl_FragColor = vec4(vec3(0.88), edge * clamp(vAlpha, 0.0, 1.0));
        }
      `,
    })
    const points = new THREE.Points(geometry, material)
    points.frustumCulled = false
    return { points, material, geometry }
  })()
  group.add(orbit.points)

  /* --------------------------------------------------------- interference */

  const overlayScene = new THREE.Scene()
  const overlayCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1)
  const overlayMaterial = new THREE.ShaderMaterial({
    uniforms: {
      ...U,
      uResolution: { value: new THREE.Vector2(1, 1) },
    },
    vertexShader: /* glsl */ `
      void main() { gl_Position = vec4(position.xy, 0.0, 1.0); }
    `,
    fragmentShader: /* glsl */ `
      uniform float uTime, uInterference, uRed;
      uniform vec2 uResolution;
      float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      void main() {
        vec2 uv = gl_FragCoord.xy / uResolution;
        float grain = (hash(gl_FragCoord.xy + floor(uTime * 20.0)) - 0.5) * 0.1;
        float band = smoothstep(0.016, 0.0, abs(uv.y - fract(uTime * 0.06)));
        vec3 col = vec3(max(grain, 0.0)) * (1.0 + uInterference);
        col += vec3(0.6, 0.04, 0.05) * band * uRed * 0.55;
        float alpha = max(grain, 0.0) * 0.7 + band * uRed * 0.3;
        gl_FragColor = vec4(col, alpha);
      }
    `,
    transparent: true,
    depthTest: false,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  })
  overlayScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), overlayMaterial))

  /* -------------------------------------------------------------- controls */

  let state: CoreState = 'idle'
  let errorFlash = 0
  let pointerX = 0
  let pointerY = 0
  let hoverTarget = 0
  let hover = 0
  let pulseFlash = 0
  const motionScale = options.reducedMotion ? 0.4 : 1
  const drift = { time: 0 }
  const values = { energy: PRESETS.idle.energy, interference: 0.04, red: 0.02 }

  const onPointer = (event: PointerEvent) => {
    pointerX = (event.clientX / window.innerWidth) * 2 - 1
    pointerY = (event.clientY / window.innerHeight) * 2 - 1
    // How close the pointer is to the middle of the loop, 0..1. The core reacts
    // before it is clicked, so it reads as something you can touch.
    const cx = window.innerWidth * 0.5
    const cy = window.innerHeight * 0.46
    const reach = Math.min(window.innerWidth, window.innerHeight) * 0.42
    const distance = Math.hypot(event.clientX - cx, event.clientY - cy)
    hoverTarget = Math.max(0, 1 - distance / reach)
  }
  const onLeave = () => {
    hoverTarget = 0
  }
  window.addEventListener('pointermove', onPointer, { passive: true })
  window.addEventListener('pointerleave', onLeave, { passive: true })

  function fitCamera(width: number, height: number) {
    camera.aspect = width / height
    camera.updateProjectionMatrix()
    // Pulled back from 2.0, which makes the loop about a third smaller than it
    // used to be while keeping it crisp.
    const fitRadius = 2.75
    const vFov = (camera.fov * Math.PI) / 180
    const distance = Math.max(
      fitRadius / Math.tan(vFov / 2),
      fitRadius / (Math.tan(vFov / 2) * Math.max(0.3, camera.aspect)),
    )
    camera.position.z = distance
  }

  const resize = () => {
    const width = window.innerWidth
    const height = window.innerHeight
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75))
    renderer.setSize(width, height, false)
    overlayMaterial.uniforms.uResolution!.value.set(width, height)
    fitCamera(width, height)
  }
  resize()
  window.addEventListener('resize', resize)

  let frame = 0
  let last = performance.now()

  function animate() {
    frame = requestAnimationFrame(animate)
    const now = performance.now()
    const dt = Math.min(0.05, (now - last) / 1000)
    last = now

    const preset = PRESETS[state]
    const level =
      state === 'listening' || state === 'speaking'
        ? Math.max(0, Math.min(1, options.level?.() ?? 0))
        : 0

    errorFlash = Math.max(0, errorFlash - dt * 0.8)
    pulseFlash = Math.max(0, pulseFlash - dt * 1.6)
    hover += (hoverTarget - hover) * (1 - Math.exp(-dt * 4))

    const targetEnergy = preset.energy + level * 0.4 + errorFlash * 0.15
    const targetInterference = preset.interference + errorFlash * 0.7
    const targetRed = preset.red + errorFlash * 0.85
    const ease = (current: number, target: number, speed: number) =>
      current + (target - current) * (1 - Math.exp(-dt * speed))

    values.energy = ease(values.energy, targetEnergy, 2.2)
    values.interference = ease(values.interference, Math.min(1, targetInterference), 3)
    values.red = ease(values.red, Math.min(1, targetRed), 2.4)

    drift.time += dt * preset.speed * (1 + level * 0.35) * motionScale

    const time = drift.time
    U.uTime!.value = now / 1000
    U.uEnergy!.value = values.energy
    U.uReact!.value = level
    U.uRed!.value = values.red
    U.uInterference!.value = values.interference
    U.uHover!.value = hover
    U.uPulse!.value = pulseFlash

    const react = level * preset.react
    main.update(time, values.energy, react)
    veil.update(time, values.energy, react * 0.6)
    filament.update(time, values.energy, react)
    thread.update(time, values.energy, react * 0.8)

    // The dust tracks turn on their own axis, slower than the loop, so the
    // structure keeps opening and closing instead of orbiting as one solid.
    orbit.points.rotation.y = time * 0.045
    orbit.points.rotation.x = Math.sin(time * 0.05) * 0.12
    orbit.points.rotation.z = time * -0.02

    group.rotation.y = Math.sin(time * 0.09) * 0.22 + pointerX * 0.3
    group.rotation.x = Math.sin(time * 0.07) * 0.16 - pointerY * 0.18
    group.rotation.z = Math.sin(time * 0.05) * 0.08 + pulseFlash * 0.12
    const scale = 1 + hover * 0.03 + pulseFlash * 0.05
    group.scale.setScalar(scale)

    camera.position.x += (pointerX * 0.24 - camera.position.x) * (1 - Math.exp(-dt * 1.6))
    camera.position.y += (-pointerY * 0.18 - camera.position.y) * (1 - Math.exp(-dt * 1.6))
    camera.position.x += (Math.random() - 0.5) * errorFlash * 0.05
    camera.lookAt(0, 0, 0)

    renderer.render(scene, camera)
    renderer.autoClear = false
    renderer.render(overlayScene, overlayCamera)
    renderer.autoClear = true
  }

  frame = requestAnimationFrame(animate)

  return {
    setState(next) {
      state = next
      if (next === 'error') errorFlash = Math.min(1, errorFlash + 0.9)
    },
    flashError() {
      errorFlash = 1
    },
    pulse() {
      pulseFlash = 1
    },
    resize,
    dispose() {
      cancelAnimationFrame(frame)
      window.removeEventListener('resize', resize)
      window.removeEventListener('pointermove', onPointer)
      window.removeEventListener('pointerleave', onLeave)
      scene.traverse((object) => {
        const mesh = object as THREE.Mesh
        mesh.geometry?.dispose?.()
        const material = mesh.material
        if (Array.isArray(material)) material.forEach((item) => item.dispose())
        else material?.dispose?.()
      })
      overlayMaterial.dispose()
      orbit.geometry.dispose()
      orbit.material.dispose()
      renderer.dispose()
    },
  }
}
