import type { ReactNode } from 'react'

/**
 * A deliberately small Markdown renderer for assistant replies. It builds React
 * elements, never HTML strings, so model output cannot inject markup.
 */

const INLINE =
  /(`[^`\n]+`|\*\*[^*\n]+\*\*|__[^_\n]+__|\*[^*\n]+\*|\[[^\]\n]+]\([^)\s]+\))/g

function safeHref(href: string): string | null {
  return /^https?:\/\//i.test(href) ? href : null
}

function inline(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = []
  let last = 0
  let index = 0
  INLINE.lastIndex = 0
  let match: RegExpExecArray | null
  while ((match = INLINE.exec(text)) !== null) {
    if (match.index > last) nodes.push(text.slice(last, match.index))
    const token = match[0]
    const key = `${keyPrefix}-${index++}`
    if (token.startsWith('`')) {
      nodes.push(
        <code key={key} className="inline-code">
          {token.slice(1, -1)}
        </code>,
      )
    } else if (token.startsWith('**') || token.startsWith('__')) {
      nodes.push(<strong key={key}>{token.slice(2, -2)}</strong>)
    } else if (token.startsWith('[')) {
      const link = /^\[([^\]]+)]\(([^)\s]+)\)$/.exec(token)
      const href = link ? safeHref(link[2]!) : null
      nodes.push(
        href ? (
          <a key={key} href={href} target="_blank" rel="noreferrer noopener">
            {link![1]}
          </a>
        ) : (
          <span key={key}>{link?.[1] ?? token}</span>
        ),
      )
    } else {
      nodes.push(<em key={key}>{token.slice(1, -1)}</em>)
    }
    last = match.index + token.length
  }
  if (last < text.length) nodes.push(text.slice(last))
  return nodes
}

const BULLET = /^\s*[-*+]\s+(.*)$/
const ORDERED = /^\s*\d+[.)]\s+(.*)$/
const HEADING = /^\s*(#{1,4})\s+(.*)$/
const QUOTE = /^\s*>\s?(.*)$/
const FENCE = /^\s*```(.*)$/

export function Markdown({ text }: { text: string }) {
  const lines = text.replace(/\r\n/g, '\n').split('\n')
  const blocks: ReactNode[] = []
  let cursor = 0
  let key = 0

  while (cursor < lines.length) {
    const line = lines[cursor]!

    if (!line.trim()) {
      cursor += 1
      continue
    }

    const fence = FENCE.exec(line)
    if (fence) {
      const language = fence[1]?.trim() ?? ''
      const code: string[] = []
      cursor += 1
      while (cursor < lines.length && !/^\s*```/.test(lines[cursor]!)) {
        code.push(lines[cursor]!)
        cursor += 1
      }
      cursor += 1
      blocks.push(
        <pre key={`block-${key++}`} className="code-block">
          <code>{code.join('\n')}</code>
          {language ? <span className="code-lang">{language}</span> : null}
        </pre>,
      )
      continue
    }

    const heading = HEADING.exec(line)
    if (heading) {
      const level = heading[1]!.length
      const content = inline(heading[2]!, `h-${key}`)
      blocks.push(
        level <= 2 ? (
          <h3 key={`block-${key++}`}>{content}</h3>
        ) : (
          <h4 key={`block-${key++}`}>{content}</h4>
        ),
      )
      cursor += 1
      continue
    }

    if (BULLET.test(line)) {
      const items: string[] = []
      while (cursor < lines.length && BULLET.test(lines[cursor]!)) {
        items.push(BULLET.exec(lines[cursor]!)![1]!)
        cursor += 1
      }
      blocks.push(
        <ul key={`block-${key++}`}>
          {items.map((item, index) => (
            <li key={index}>{inline(item, `ul-${key}-${index}`)}</li>
          ))}
        </ul>,
      )
      continue
    }

    if (ORDERED.test(line)) {
      const items: string[] = []
      while (cursor < lines.length && ORDERED.test(lines[cursor]!)) {
        items.push(ORDERED.exec(lines[cursor]!)![1]!)
        cursor += 1
      }
      blocks.push(
        <ol key={`block-${key++}`}>
          {items.map((item, index) => (
            <li key={index}>{inline(item, `ol-${key}-${index}`)}</li>
          ))}
        </ol>,
      )
      continue
    }

    if (QUOTE.test(line)) {
      const quoted: string[] = []
      while (cursor < lines.length && QUOTE.test(lines[cursor]!)) {
        quoted.push(QUOTE.exec(lines[cursor]!)![1]!)
        cursor += 1
      }
      blocks.push(
        <blockquote key={`block-${key++}`}>
          {inline(quoted.join(' '), `q-${key}`)}
        </blockquote>,
      )
      continue
    }

    const paragraph: string[] = []
    while (
      cursor < lines.length &&
      lines[cursor]!.trim() &&
      !FENCE.test(lines[cursor]!) &&
      !HEADING.test(lines[cursor]!) &&
      !BULLET.test(lines[cursor]!) &&
      !ORDERED.test(lines[cursor]!) &&
      !QUOTE.test(lines[cursor]!)
    ) {
      paragraph.push(lines[cursor]!)
      cursor += 1
    }
    blocks.push(
      <p key={`block-${key++}`}>{inline(paragraph.join(' '), `p-${key}`)}</p>,
    )
  }

  return <div className="markdown">{blocks}</div>
}
