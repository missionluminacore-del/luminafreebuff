/**
 * Playback for neural speech.
 *
 * The server sends raw 16-bit PCM from Gemini's audio model; here it becomes an
 * AudioBuffer, which gives three things the browser's system voices cannot:
 * real amplitude for the visualiser, exact volume control, and a clean stop
 * halfway through a sentence.
 */

let context: AudioContext | null = null
let source: AudioBufferSourceNode | null = null
let gain: GainNode | null = null
let analyser: AnalyserNode | null = null
let data: Uint8Array<ArrayBuffer> | null = null
let done: (() => void) | null = null
let smoothed = 0
let volume = 0.9

function audioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null
  if (context) return context
  const Ctor =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext })
      .webkitAudioContext
  if (!Ctor) return null
  context = new Ctor()
  analyser = context.createAnalyser()
  analyser.fftSize = 1024
  analyser.smoothingTimeConstant = 0.7
  gain = context.createGain()
  gain.gain.value = volume
  gain.connect(analyser)
  analyser.connect(context.destination)
  data = new Uint8Array(analyser.fftSize)
  return context
}

/**
 * Browsers only allow audio after a gesture, so the first tap or key press
 * opens the context. Everything after that plays without asking again.
 */
export function unlockAudio(): void {
  const ctx = audioContext()
  if (ctx && ctx.state === 'suspended') void ctx.resume().catch(() => undefined)
}

export function setAudioVolume(next: number): void {
  volume = Number.isFinite(next) ? Math.min(1, Math.max(0, next)) : volume
  if (gain) gain.gain.value = volume
}

function decodePcm(base64: string, sampleRate: number): AudioBuffer | null {
  const ctx = audioContext()
  if (!ctx) return null
  let binary = ''
  try {
    binary = atob(base64)
  } catch {
    return null
  }
  const bytes = new Uint8Array(binary.length)
  for (let index = 0; index < binary.length; index += 1)
    bytes[index] = binary.charCodeAt(index)
  const frames = Math.floor(bytes.length / 2)
  if (!frames) return null
  const buffer = ctx.createBuffer(1, frames, sampleRate || 24000)
  const channel = buffer.getChannelData(0)
  const view = new DataView(bytes.buffer)
  for (let index = 0; index < frames; index += 1)
    channel[index] = view.getInt16(index * 2, true) / 32768
  return buffer
}

/** Plays one clip. Returns false when this browser cannot play audio at all. */
export function playSpeech(
  base64: string,
  sampleRate: number,
  onEnd: () => void,
): boolean {
  const ctx = audioContext()
  const buffer = decodePcm(base64, sampleRate)
  if (!ctx || !buffer || !gain) return false
  stopAudio()
  if (ctx.state === 'suspended') void ctx.resume().catch(() => undefined)
  const node = ctx.createBufferSource()
  node.buffer = buffer
  node.connect(gain)
  source = node
  smoothed = 0
  done = onEnd
  node.onended = () => {
    if (source !== node) return
    source = null
    node.disconnect()
    const callback = done
    done = null
    smoothed = 0
    callback?.()
  }
  node.start()
  return true
}

/** Silence is intentional here: interrupting must not resume the conversation. */
export function stopAudio(): void {
  const node = source
  source = null
  done = null
  smoothed = 0
  if (!node) return
  node.onended = null
  try {
    node.stop()
  } catch {
    // Already finished.
  }
  node.disconnect()
}

export function audioActive(): boolean {
  return Boolean(source)
}

/** 0..1 loudness of the spoken audio, for the core. */
export function audioLevel(): number {
  if (!analyser || !data || !source) return 0
  analyser.getByteTimeDomainData(data)
  let sum = 0
  for (let index = 0; index < data.length; index += 1) {
    const value = (data[index]! - 128) / 128
    sum += value * value
  }
  const rms = Math.sqrt(sum / data.length)
  const shaped = Math.min(1, Math.pow(rms * 5.4, 0.8))
  smoothed = smoothed * 0.55 + shaped * 0.45
  return smoothed
}
