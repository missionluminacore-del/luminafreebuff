import {
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from 'react'
import { createRoot } from 'react-dom/client'
import {
  LANGUAGES,
  NEURAL_VOICES,
  defaultSettings,
  type AppState,
  type ChatMessage,
  type ChatResponse,
  type Conversation,
  type Fact,
  type Memory,
  type MemoryKind,
  type Rule,
  type Session,
  type Settings,
  type SpeechAudio,
  type WebCheck,
} from '../shared/types'
import { Markdown } from './markdown'
import { createCore, type Core, type CoreState } from './core'
import { disableMic, enableMic, micLevel } from './mic'
import {
  audioActive,
  audioLevel,
  playSpeech,
  setAudioVolume,
  stopAudio,
  unlockAudio,
} from './audio'
import {
  createRecognition,
  forSpeech,
  listVoices,
  speak,
  speechEnergy,
  speechError,
  speechSupported,
  speakingNow,
  stopSpeaking,
  type RecognitionLike,
} from './speech'
import './style.css'

const TOKEN_KEY = 'lumina.session'
let memoryToken = ''

/**
 * The session cookie is the primary carrier, but an app embedded in another
 * page (the preview panel) can have its cookie dropped as a third-party one.
 * The signed token is kept next to it and sent as a bearer header so sign-in
 * still sticks.
 */
const storedToken = (): string => {
  try {
    return window.localStorage.getItem(TOKEN_KEY) || memoryToken
  } catch {
    return memoryToken
  }
}

const rememberToken = (token: string): void => {
  memoryToken = token
  try {
    if (token) window.localStorage.setItem(TOKEN_KEY, token)
    else window.localStorage.removeItem(TOKEN_KEY)
  } catch {
    // Some private modes refuse storage; the in-memory copy still works.
  }
}

async function request<T>(
  url: string,
  init?: RequestInit,
  timeoutMs = 20_000,
): Promise<T> {
  const controller = new AbortController()
  const timer = window.setTimeout(() => controller.abort(), timeoutMs)
  const token = storedToken()
  const headers = new Headers(init?.headers)
  if (token) headers.set('Authorization', `Bearer ${token}`)
  try {
    const response = await fetch(url, {
      ...init,
      headers,
      signal: init?.signal ?? controller.signal,
    })
    // An expired session must not leave a dead token behind forever.
    if (response.status === 401 && token) rememberToken('')
    const body = (await response.json().catch(() => {
      throw new Error('Could not reach the server. Please try again.')
    })) as T & { error?: string }
    if (!response.ok)
      throw new Error(body.error || 'The request failed. Please try again.')
    return body
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      if (init?.signal?.aborted) throw new Error('Stopped.')
      throw new Error('That took too long, so it was stopped. Please try again.')
    }
    throw error
  } finally {
    window.clearTimeout(timer)
  }
}

const json = (body: unknown): RequestInit => ({
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body),
})

/**
 * The streaming form of a chat turn. Words arrive as server-sent events; the
 * final event carries the stored conversation exactly as the JSON route would.
 * Anything other than an event stream falls back to an ordinary JSON reply.
 */
async function streamChat(
  body: Record<string, unknown>,
  onDelta: (text: string) => void,
  signal: AbortSignal,
): Promise<ChatResponse> {
  const token = storedToken()
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ ...body, stream: true }),
    signal,
  })
  if (response.status === 401 && token) rememberToken('')
  if (
    !response.ok ||
    !response.body ||
    !(response.headers.get('content-type') ?? '').includes('text/event-stream')
  ) {
    const failure = (await response.json().catch(() => null)) as
      | { error?: string }
      | null
    throw new Error(failure?.error || 'Could not send that message.')
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  let completed: ChatResponse | null = null
  let failure = ''

  const consume = (frame: string): void => {
    let event = 'message'
    const data: string[] = []
    for (const line of frame.split('\n')) {
      if (line.startsWith('event:')) event = line.slice(6).trim()
      else if (line.startsWith('data:')) data.push(line.slice(5).trimStart())
    }
    const raw = data.join('')
    if (!raw) return
    let payload: Record<string, unknown>
    try {
      payload = JSON.parse(raw) as Record<string, unknown>
    } catch {
      return
    }
    if (event === 'delta') {
      if (typeof payload.text === 'string') onDelta(payload.text)
    } else if (event === 'done') {
      completed = payload as unknown as ChatResponse
    } else if (event === 'error') {
      failure =
        typeof payload.error === 'string' ? payload.error : 'The reply failed.'
    }
  }

  while (true) {
    const step = await reader.read()
    if (step.done) break
    buffer += decoder.decode(step.value, { stream: true })
    let split = buffer.indexOf('\n\n')
    while (split >= 0) {
      consume(buffer.slice(0, split))
      buffer = buffer.slice(split + 2)
      split = buffer.indexOf('\n\n')
    }
  }
  if (buffer.trim()) consume(buffer)

  if (failure) throw new Error(failure)
  if (!completed)
    throw new Error('The answer stopped before it finished. Please try again.')
  return completed
}

/** Sentences, grouped just short of the speech limit, so audio starts sooner. */
function speechChunks(text: string, max = 700): string[] {
  const sentences = text.match(/[^.!?]+[.!?]*/g) ?? [text]
  const chunks: string[] = []
  let current = ''
  for (const sentence of sentences) {
    if (current && (current + sentence).length > max) {
      chunks.push(current.trim())
      current = sentence
    } else current += sentence
  }
  if (current.trim()) chunks.push(current.trim())
  return chunks.filter(Boolean).slice(0, 8)
}

/** Resolves when one clip finishes, or when it never starts. */
function playChunk(
  audio: SpeechAudio,
  onEnd: () => void,
): Promise<boolean> {
  return new Promise((resolve) => {
    let settled = false
    const settle = (value: boolean): void => {
      if (settled) return
      settled = true
      window.clearTimeout(timer)
      resolve(value)
    }
    const timer = window.setTimeout(() => settle(false), 90_000)
    if (!playSpeech(audio.audio, audio.sampleRate, () => {
      onEnd()
      settle(true)
    }))
      settle(false)
  })
}

const upsertConversation = (
  list: Conversation[],
  next: Conversation,
): Conversation[] =>
  [next, ...list.filter((item) => item.id !== next.id)].sort(
    (a, b) => b.updatedAt - a.updatedAt,
  )

const when = (value: number): string => {
  const date = new Date(value)
  const today = new Date()
  if (date.toDateString() === today.toDateString())
    return date.toLocaleTimeString(undefined, {
      hour: 'numeric',
      minute: '2-digit',
    })
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
}

const MODE_LABEL: Record<CoreState, string> = {
  idle: 'standby',
  listening: 'listening',
  thinking: 'processing',
  speaking: 'speaking',
  error: 'interference',
}

const FACT_LABELS: Record<Fact['slot'], string> = {
  name: 'Name',
  birthday: 'Birthday',
  age: 'Age',
  city: 'City',
  job: 'Job',
  company: 'Work',
}

function Icon({
  name,
  size = 16,
}: {
  name: 'mic' | 'send' | 'stop' | 'speaker' | 'trash' | 'x' | 'plus'
  size?: number
}) {
  const paths: Record<string, ReactNode> = {
    mic: (
      <>
        <rect x="9" y="3" width="6" height="11" rx="3" />
        <path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
      </>
    ),
    send: <path d="M4 12 20 4l-4 16-4-6-8-2Z" />,
    stop: <rect x="6" y="6" width="12" height="12" rx="1" />,
    speaker: (
      <>
        <path d="M4 10v4h3l4 3V7L7 10H4Z" />
        <path d="M15 9a4 4 0 0 1 0 6M17.5 6.5a7 7 0 0 1 0 11" />
      </>
    ),
    trash: <path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13" />,
    x: <path d="M6 6l12 12M18 6L6 18" />,
    plus: <path d="M12 5v14M5 12h14" />,
  }
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

function App() {
  const [stage, setStage] = useState<'loading' | 'login' | 'ready'>('loading')
  const [state, setState] = useState<AppState | null>(null)
  const [authError, setAuthError] = useState('')
  const [userId, setUserId] = useState('')
  const [password, setPassword] = useState('')
  const [signingIn, setSigningIn] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  /** Words as they arrive, before the finished message is stored. */
  const [streamText, setStreamText] = useState('')
  /** Just-learned items, so a mistaken lesson can be taken back at once. */
  const [learned, setLearned] = useState<{
    rules: string[]
    memories: string[]
  } | null>(null)
  const [drawer, setDrawer] = useState<null | 'history' | 'memory' | 'settings'>(
    null,
  )
  const [threadOpen, setThreadOpen] = useState(false)
  const [online, setOnline] = useState(true)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [webChecks, setWebChecks] = useState<Record<string, WebCheck>>({})
  const [brains, setBrains] = useState<
    Record<string, NonNullable<ChatResponse['brain']>>
  >({})
  const [draft, setDraft] = useState('')
  const [sending, setSending] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const [listening, setListening] = useState(false)
  const [live, setLive] = useState(false)
  const [heard, setHeard] = useState('')
  const [speakingId, setSpeakingId] = useState<string | null>(null)
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([])
  const [newRule, setNewRule] = useState('')
  const [newNote, setNewNote] = useState('')
  const [noteKind, setNoteKind] = useState<MemoryKind>('fact')
  const [keyDraft, setKeyDraft] = useState('')
  const [savingKey, setSavingKey] = useState(false)

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const coreRef = useRef<Core | null>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const threadRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<RecognitionLike | null>(null)
  const sendingRef = useRef(false)
  const activeIdRef = useRef<string | null>(null)
  const liveRef = useRef(false)
  const heardRef = useRef('')
  const speechDoneRef = useRef<(() => void) | null>(null)
  const silenceTimer = useRef<number | undefined>(undefined)
  const restartTimer = useRef<number | undefined>(undefined)
  const blockedRef = useRef(false)
  const abortRef = useRef<AbortController | null>(null)
  const stoppedRef = useRef(false)
  const volumeTimer = useRef<number | undefined>(undefined)
  /** Bumped on every stop, so a voice render that lands late stays silent. */
  const voiceRunRef = useRef(0)

  const settings: Settings = state?.settings ?? defaultSettings
  const aiReady = Boolean(state?.ai.configured)
  const canChat = stage === 'ready' && aiReady
  const mode: CoreState = sending
    ? 'thinking'
    : speakingId
      ? 'speaking'
      : listening
        ? 'listening'
        : 'idle'
  const modeRef = useRef<CoreState>('idle')

  useEffect(() => {
    activeIdRef.current = activeId
  }, [activeId])

  useEffect(() => {
    liveRef.current = live
  }, [live])

  /* The visualization outlives every screen state: it is the interface. */
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const core = createCore(canvas, {
      // Listening follows the real microphone; speaking follows the real audio
      // being played. Only the device-voice fallback has to use cadence, since
      // browsers never expose synthesised audio for analysis.
      level: () => {
        if (modeRef.current === 'listening') return micLevel()
        if (modeRef.current !== 'speaking') return 0
        return audioActive() ? audioLevel() : speechEnergy()
      },
      reducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)')
        .matches,
    })
    coreRef.current = core
    return () => {
      core.dispose()
      coreRef.current = null
    }
  }, [])

  // Audio is only allowed after a gesture, so the first one arms it for good.
  useEffect(() => {
    const arm = () => {
      unlockAudio()
      window.removeEventListener('pointerdown', arm)
      window.removeEventListener('keydown', arm)
    }
    window.addEventListener('pointerdown', arm)
    window.addEventListener('keydown', arm)
    return () => {
      window.removeEventListener('pointerdown', arm)
      window.removeEventListener('keydown', arm)
    }
  }, [])

  useEffect(() => {
    setAudioVolume(settings.voiceVolume)
  }, [settings.voiceVolume])

  // A visible connection state, instead of failing silently mid-turn.
  useEffect(() => {
    const update = () => setOnline(navigator.onLine)
    update()
    window.addEventListener('online', update)
    window.addEventListener('offline', update)
    return () => {
      window.removeEventListener('online', update)
      window.removeEventListener('offline', update)
    }
  }, [])

  useEffect(() => {
    modeRef.current = mode
    coreRef.current?.setState(mode)
  }, [mode])

  // An error is shown on the core itself for a moment, then the core returns to
  // whatever it was doing. It is never left flashing red forever.
  useEffect(() => {
    if (!error) return
    coreRef.current?.flashError()
    coreRef.current?.setState('error')
    const timer = window.setTimeout(
      () => coreRef.current?.setState(modeRef.current),
      2400,
    )
    return () => window.clearTimeout(timer)
  }, [error])

  // Leaving the page must not leave a microphone open.
  useEffect(
    () => () => {
      window.clearTimeout(silenceTimer.current)
      window.clearTimeout(restartTimer.current)
      recognitionRef.current?.abort()
      stopSpeaking()
      stopAudio()
      disableMic()
      window.clearTimeout(volumeTimer.current)
    },
    [],
  )

  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return
    const update = () => setVoices(listVoices())
    update()
    window.speechSynthesis.addEventListener('voiceschanged', update)
    return () =>
      window.speechSynthesis.removeEventListener('voiceschanged', update)
  }, [])

  useEffect(() => {
    const element = textareaRef.current
    if (!element) return
    element.style.height = 'auto'
    element.style.height = `${Math.min(element.scrollHeight, 140)}px`
  }, [draft])

  useEffect(() => {
    if (!sending) return
    setElapsed(0)
    const timer = window.setInterval(() => setElapsed((value) => value + 1), 1000)
    return () => window.clearInterval(timer)
  }, [sending])

  useEffect(() => {
    if (!notice) {
      setLearned(null)
      return
    }
    const timer = window.setTimeout(() => setNotice(''), 6000)
    return () => window.clearTimeout(timer)
  }, [notice])

  /** Takes back the rules and notes this turn just saved. */
  async function undoLearned() {
    const current = learned
    if (!current) return
    setLearned(null)
    setState((previous) =>
      previous
        ? {
            ...previous,
            rules: previous.rules.filter(
              (rule) => !current.rules.includes(rule.id),
            ),
            memories: previous.memories.filter(
              (memory) => !current.memories.includes(memory.id),
            ),
          }
        : previous,
    )
    setNotice('Reverted, sir.')
    try {
      await Promise.all([
        ...current.rules.map((id) =>
          request(`/api/rules/${id}`, { method: 'DELETE' }),
        ),
        ...current.memories.map((id) =>
          request(`/api/memories/${id}`, { method: 'DELETE' }),
        ),
      ])
    } catch {
      setNotice('Could not undo that. Reload to resync.')
    }
  }

  // The text field is always there; focusing it on arrival means a message can
  // be typed the moment the interface is ready.
  useEffect(() => {
    if (stage !== 'ready') return
    const timer = window.setTimeout(() => textareaRef.current?.focus(), 220)
    return () => window.clearTimeout(timer)
  }, [stage])

  // Opening a conversation lands on the latest turn, not the oldest.
  useEffect(() => {
    if (!threadOpen) return
    const timer = window.setTimeout(() => {
      const element = threadRef.current
      if (element) element.scrollTop = element.scrollHeight
    }, 30)
    return () => window.clearTimeout(timer)
  }, [threadOpen, messages.length])

  // Keyboard: "/" opens the text channel, Escape closes whatever is open.
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setDrawer(null)
        setThreadOpen(false)
        return
      }
      const target = event.target as HTMLElement | null
      if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) return
      if (event.key === '/') {
        event.preventDefault()
        textareaRef.current?.focus()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const loadState = async () => {
    const next = await request<AppState>('/api/state')
    setState(next)
    // The core opens empty on purpose: an old conversation must never sit on
    // the home screen. Past sessions stay one click away in history.
    setActiveId(null)
    setMessages([])
  }

  useEffect(() => {
    let alive = true
    void (async () => {
      try {
        const current = await request<Session>('/api/session')
        if (!alive) return
        if (!current.authenticated) {
          setStage('login')
          return
        }
        await loadState()
        if (alive) setStage('ready')
      } catch (e) {
        if (!alive) return
        setStage('login')
        setAuthError(
          e instanceof Error ? e.message : 'Could not reach the server.',
        )
      }
    })()
    return () => {
      alive = false
    }
  }, [])

  // Keeping devices in step: refresh whenever the app regains focus.
  useEffect(() => {
    if (stage !== 'ready') return
    const refresh = () => {
      if (document.visibilityState === 'hidden' || sendingRef.current) return
      void (async () => {
        try {
          const next = await request<AppState>('/api/state')
          setState(next)
          const id = activeIdRef.current
          if (!id) return
          if (!next.conversations.some((item) => item.id === id)) {
            setActiveId(null)
            setMessages([])
            return
          }
          if (sendingRef.current) return
          const thread = await request<{ messages: ChatMessage[] }>(
            `/api/conversations/${id}`,
          )
          setMessages(thread.messages)
        } catch {
          // A quiet background sync never interrupts the conversation.
        }
      })()
    }
    window.addEventListener('focus', refresh)
    document.addEventListener('visibilitychange', refresh)
    return () => {
      window.removeEventListener('focus', refresh)
      document.removeEventListener('visibilitychange', refresh)
    }
  }, [stage])

  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (signingIn) return
    const data = new FormData(event.currentTarget)
    const id = String(data.get('userId') ?? userId).trim()
    const secret = String(data.get('password') ?? password)
    setUserId(id)
    setPassword(secret)
    if (!id || !secret) {
      setAuthError('Enter your user ID and password.')
      return
    }
    setSigningIn(true)
    setAuthError('')
    try {
      const entered = await request<{ ok: boolean; token?: string }>(
        '/api/login',
        json({ userId: id, password: secret }),
      )
      if (entered.token) rememberToken(entered.token)
      await loadState()
      setPassword('')
      setStage('ready')
    } catch (e) {
      setAuthError(e instanceof Error ? e.message : 'Could not sign in.')
    } finally {
      setSigningIn(false)
    }
  }

  async function signOut() {
    stopSpeaking()
    disableMic()
    setSpeakingId(null)
    try {
      await request('/api/logout', { method: 'POST' })
    } catch {
      // Leaving the screen is enough if the server is unreachable.
    }
    rememberToken('')
    setStage('login')
    setState(null)
    setMessages([])
    setActiveId(null)
    setDrawer(null)
    setThreadOpen(false)
    setDraft('')
    setPassword('')
    setError('')
  }

  async function openConversation(id: string) {
    setDrawer(null)
    setActiveId(id)
    setDraft('')
    try {
      const thread = await request<{
        conversation: Conversation
        messages: ChatMessage[]
      }>(`/api/conversations/${id}`)
      setActiveId(thread.conversation.id)
      setMessages(thread.messages)
      setThreadOpen(true)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not open that chat.')
    }
  }

  function startNewChat() {
    stopAnswer()
    setDrawer(null)
    setThreadOpen(false)
    setActiveId(null)
    setMessages([])
    setDraft('')
    setError('')
    window.setTimeout(() => textareaRef.current?.focus(), 40)
  }

  function readAloud(message: ChatMessage) {
    if (speakingId === message.id) {
      stopAnswer()
      return
    }
    speechDoneRef.current = null
    void pronounce(message.content, message.id)
  }

  async function send(
    raw: string,
    options: { voice?: boolean; then?: () => void } = {},
  ) {
    const text = raw.trim()
    if (!text || sendingRef.current) return
    let resumed = false
    const resume = () => {
      if (resumed) return
      resumed = true
      if (options.then) options.then()
      else if (liveRef.current) restartLater(300)
    }
    if (!canChat) {
      setError(
        aiReady
          ? 'Sign in to keep your chats in sync.'
          : 'Add your API key in Settings to start chatting.',
      )
      liveRef.current = false
      setLive(false)
      return
    }
    if (liveRef.current) stopListening()
    setError('')
    stoppedRef.current = false
    const controller = new AbortController()
    abortRef.current = controller
    // The line appears the moment Enter is pressed, before the network answers.
    const localId = `local-${Date.now()}`
    const optimistic: ChatMessage = {
      id: localId,
      conversationId: activeId ?? 'pending',
      role: 'user',
      content: text,
      createdAt: Date.now(),
    }
    setMessages((previous) => [...previous, optimistic])
    sendingRef.current = true
    setSending(true)
    setDraft('')
    setStreamText('')
    try {
      const result = await streamChat(
        { conversationId: activeId, text, voice: options.voice === true },
        (chunk) => setStreamText((current) => current + chunk),
        controller.signal,
      )
      setActiveId(result.conversation.id)
      setMessages((previous) => [
        ...previous.filter(
          (message) =>
            message.id !== localId &&
            message.id !== result.userMessage.id &&
            message.id !== result.assistantMessage.id,
        ),
        result.userMessage,
        result.assistantMessage,
      ])
      if (result.web)
        setWebChecks((previous) => ({
          ...previous,
          [result.assistantMessage.id]: result.web as WebCheck,
        }))
      if (result.brain)
        setBrains((previous) => ({
          ...previous,
          [result.assistantMessage.id]: result.brain!,
        }))
      setState((previous) =>
        previous
          ? {
              ...previous,
              conversations: upsertConversation(
                previous.conversations,
                result.conversation,
              ),
              rules: [...previous.rules, ...result.newRules],
              memories: [...result.newMemories, ...previous.memories],
              facts: [
                ...(result.newFacts ?? []),
                ...(previous.facts ?? []).filter(
                  (fact) =>
                    !(result.newFacts ?? []).some(
                      (next) => next.slot === fact.slot,
                    ),
                ),
              ],
            }
          : previous,
      )
      if (result.newRules.length) {
        setNotice(
          `Learned and saved: ${result.newRules
            .map((rule) => rule.text)
            .join(' · ')}`,
        )
        setLearned({
          rules: result.newRules.map((rule) => rule.id),
          memories: result.newMemories.map((memory) => memory.id),
        })
      } else if (result.newMemories.length) {
        setNotice('Noted. I will remember that next time.')
        setLearned({
          rules: [],
          memories: result.newMemories.map((memory) => memory.id),
        })
      }
      if (options.voice === true || settings.voiceReplies) {
        speechDoneRef.current = resume
        void pronounce(
          result.spoken ?? result.assistantMessage.content,
          result.assistantMessage.id,
        )
      } else resume()
    } catch (e) {
      // A failed turn never leaves a half exchange on screen, and the words go
      // back in the field so nothing has to be typed again.
      setMessages((previous) =>
        previous.filter((message) => message.id !== localId),
      )
      setDraft((current) => current || text)
      if (e instanceof Error && e.message === 'Stopped.') setNotice('stopped.')
      else
        setError(e instanceof Error ? e.message : 'Could not send that message.')
      resume()
    } finally {
      abortRef.current = null
      sendingRef.current = false
      setSending(false)
      setStreamText('')
    }
  }

  /**
   * Speech, newest engine first: the server's neural audio, then the device's
   * own voice. `finish` runs exactly once, so the conversation never hangs on a
   * voice that failed to start.
   */
  async function pronounce(text: string, messageId: string) {
    const plain = forSpeech(text, 4_000)
    const run = voiceRunRef.current + 1
    voiceRunRef.current = run
    const finish = () => {
      setSpeakingId(null)
      const next = speechDoneRef.current
      speechDoneRef.current = null
      next?.()
    }
    if (!plain) {
      finish()
      return
    }
    if (settings.voiceEngine === 'neural' && online) {
      setSpeakingId(messageId)
      try {
        // Long answers are spoken in sentence groups: the first words are
        // heard while the rest is still being rendered, instead of waiting for
        // one enormous clip to arrive.
        for (const chunk of speechChunks(plain)) {
          if (run !== voiceRunRef.current) return
          const audio = await request<SpeechAudio>(
            '/api/speech',
            json({ text: chunk, voice: settings.neuralVoice }),
            45_000,
          )
          if (run !== voiceRunRef.current) return
          if (!(await playChunk(audio, () => undefined))) break
          if (run !== voiceRunRef.current) return
        }
        if (run !== voiceRunRef.current) return
        finish()
        return
      } catch (e) {
        setNotice(
          e instanceof Error
            ? `${e.message} Using the device voice.`
            : 'Neural voice failed; using the device voice.',
        )
      }
    }
    const started = speak(plain, settings.voiceName, finish, {
      volume: settings.voiceVolume,
      lang: settings.speechLang,
    })
    if (started) setSpeakingId(messageId)
    else {
      setNotice('This device has no speech voice available.')
      finish()
    }
  }

  /** Stops whatever is happening: the request, the audio, or both. */
  function stopAnswer() {
    stoppedRef.current = true
    voiceRunRef.current += 1
    stopAudio()
    stopSpeaking()
    speechDoneRef.current = null
    setSpeakingId(null)
    const controller = abortRef.current
    abortRef.current = null
    controller?.abort()
  }

  function clearSilenceTimer() {
    if (silenceTimer.current) window.clearTimeout(silenceTimer.current)
    silenceTimer.current = undefined
  }

  function stopListening() {
    clearSilenceTimer()
    const recognition = recognitionRef.current
    recognitionRef.current = null
    heardRef.current = ''
    setListening(false)
    setHeard('')
    disableMic()
    try {
      recognition?.abort()
    } catch {
      // A recogniser that already stopped throws; there is nothing to do.
    }
  }

  function restartLater(delay = 350) {
    if (restartTimer.current) window.clearTimeout(restartTimer.current)
    restartTimer.current = window.setTimeout(() => {
      restartTimer.current = undefined
      if (
        liveRef.current &&
        !sendingRef.current &&
        !speakingNow() &&
        !audioActive()
      )
        void startListening()
    }, delay)
  }

  function submitHeard() {
    if (sendingRef.current) return
    const said = heardRef.current.trim()
    heardRef.current = ''
    setHeard('')
    if (!said) return
    if (!liveRef.current) {
      if (settings.autoSend) void send(said)
      else setDraft(said)
      return
    }
    stopListening()
    void send(said, {
      voice: true,
      then: () => {
        if (liveRef.current) restartLater(250)
      },
    })
  }

  async function startListening() {
    if (!speechSupported()) {
      setNotice(
        'Voice input needs Chrome, Edge or Safari. Typing works everywhere.',
      )
      return
    }
    if (blockedRef.current || recognitionRef.current) return
    // The device's microphone is opened first: a blocked or missing microphone
    // is a permission problem, and must be reported as one instead of leaving
    // a recogniser running against nothing.
    const ready = await enableMic()
    if (!ready) {
      blockedRef.current = true
      liveRef.current = false
      setLive(false)
      setListening(false)
      setError(
        'Microphone access is blocked. Allow the microphone for this site, then press speak again. In a preview panel, open the app in its own tab if the browser keeps refusing.',
      )
      return
    }
    if (blockedRef.current || recognitionRef.current) return
    const recognition = createRecognition(settings.speechLang, liveRef.current)
    if (!recognition) return
    recognitionRef.current = recognition
    heardRef.current = ''
    setHeard('')
    setError('')

    recognition.onresult = (event) => {
      let interim = ''
      for (let index = event.resultIndex; index < event.length; index += 1) {
        const result = event[index]
        if (!result) continue
        const piece = result[0]?.transcript ?? ''
        if (result.isFinal) heardRef.current += `${piece.trim()} `
        else interim += piece
      }
      const said = `${heardRef.current}${interim}`.trim()
      setHeard(said)
      if (!liveRef.current) {
        setDraft(said)
        return
      }
      // Slightly over a second of quiet means the thought is finished.
      clearSilenceTimer()
      silenceTimer.current = window.setTimeout(submitHeard, 1_150)
    }

    recognition.onerror = (event) => {
      if (event.error === 'aborted') return
      if (
        event.error === 'not-allowed' ||
        event.error === 'service-not-allowed'
      ) {
        blockedRef.current = true
        liveRef.current = false
        setLive(false)
        setListening(false)
        disableMic()
        setNotice(speechError(event.error))
        return
      }
      if (event.error === 'no-speech') {
        if (liveRef.current) restartLater(250)
        else setNotice(speechError(event.error))
        return
      }
      setNotice(speechError(event.error))
    }

    recognition.onend = () => {
      if (recognitionRef.current === recognition) recognitionRef.current = null
      setListening(false)
      if (liveRef.current) {
        if (!sendingRef.current && !speakingNow()) restartLater(300)
        return
      }
      disableMic()
      clearSilenceTimer()
      const said = heardRef.current.trim()
      heardRef.current = ''
      setHeard('')
      if (!said) return
      if (settings.autoSend) void send(said)
      else setDraft(said)
    }

    try {
      recognition.start()
      setListening(true)
    } catch {
      recognitionRef.current = null
      setListening(false)
      if (liveRef.current) restartLater(600)
      else setNotice('Voice input is already running.')
    }
  }

  function toggleLive() {
    if (live) {
      liveRef.current = false
      setLive(false)
      stopListening()
      stopAnswer()
      setHeard('')
      return
    }
    if (!speechSupported()) {
      setNotice(
        'Live conversation needs Chrome, Edge or Safari. Typing works everywhere.',
      )
      return
    }
    blockedRef.current = false
    liveRef.current = true
    setLive(true)
    setError('')
    setDrawer(null)
    setThreadOpen(false)
    stopAnswer()
    if (!settings.voiceReplies) void updateSettings({ voiceReplies: true })
    void startListening()
  }

  /** The core is the button: speak, stop, or interrupt, depending on state. */
  function pressCore() {
    if (canChat) coreRef.current?.pulse()
    if (!canChat) {
      setError(
        aiReady
          ? 'Sign in to start talking.'
          : 'Add your API key in Settings to bring the core online.',
      )
      setDrawer('settings')
      return
    }
    if (sending) {
      stopAnswer()
      return
    }
    if (speakingId) {
      stopAnswer()
      if (liveRef.current) restartLater(150)
      return
    }
    if (live) {
      toggleLive()
      return
    }
    if (listening) {
      stopListening()
      return
    }
    toggleLive()
  }

  /** Dragging the volume slider updates the ear at once and saves once. */
  function setVoiceVolume(value: number) {
    const next = Math.min(1, Math.max(0, value))
    setState((previous) =>
      previous
        ? { ...previous, settings: { ...previous.settings, voiceVolume: next } }
        : previous,
    )
    window.clearTimeout(volumeTimer.current)
    volumeTimer.current = window.setTimeout(
      () => void updateSettings({ voiceVolume: next }),
      450,
    )
  }

  async function updateSettings(patch: Partial<Settings>) {
    const next = { ...settings, ...patch }
    setState((previous) => (previous ? { ...previous, settings: next } : previous))
    try {
      const result = await request<{ settings: Settings }>('/api/settings', {
        ...json(next),
        method: 'PUT',
      })
      setState((previous) =>
        previous ? { ...previous, settings: result.settings } : previous,
      )
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save that setting.')
    }
  }

  async function saveApiKey(key: string) {
    if (savingKey) return
    setSavingKey(true)
    setError('')
    try {
      const result = await request<{ ai: AppState['ai'] }>(
        '/api/settings/api-key',
        { ...json({ apiKey: key }), method: 'PUT' },
      )
      setState((previous) =>
        previous ? { ...previous, ai: result.ai } : previous,
      )
      setKeyDraft('')
      setNotice(
        result.ai.source === 'account'
          ? 'Key saved. Lumina can chat on every device now.'
          : 'Key removed.',
      )
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save that key.')
    } finally {
      setSavingKey(false)
    }
  }

  async function addRule(event: FormEvent) {
    event.preventDefault()
    const text = newRule.trim()
    if (!text) return
    setError('')
    try {
      const result = await request<{ rule: Rule }>('/api/rules', json({ text }))
      setState((previous) =>
        previous
          ? { ...previous, rules: [...previous.rules, result.rule] }
          : previous,
      )
      setNewRule('')
      setNotice('Saved. I will follow that from now on.')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save that rule.')
    }
  }

  async function removeRule(id: string) {
    try {
      await request(`/api/rules/${id}`, { method: 'DELETE' })
      setState((previous) =>
        previous
          ? {
              ...previous,
              rules: previous.rules.filter((rule) => rule.id !== id),
            }
          : previous,
      )
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not delete that rule.')
    }
  }

  async function addMemory(event: FormEvent) {
    event.preventDefault()
    const text = newNote.trim()
    if (!text) return
    setError('')
    try {
      const result = await request<{ memory: Memory }>(
        '/api/memories',
        json({ text, kind: noteKind }),
      )
      setState((previous) =>
        previous
          ? { ...previous, memories: [result.memory, ...previous.memories] }
          : previous,
      )
      setNewNote('')
      setNotice('Saved to memory.')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save that note.')
    }
  }

  async function removeFact(slot: Fact['slot']) {
    try {
      await request(`/api/facts/${slot}`, { method: 'DELETE' })
      setState((previous) =>
        previous
          ? {
              ...previous,
              facts: previous.facts.filter((item) => item.slot !== slot),
            }
          : previous,
      )
      setNotice('Forgotten. Tell me the right value any time.')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not forget that.')
    }
  }

  async function removeMemory(id: string) {
    try {
      await request(`/api/memories/${id}`, { method: 'DELETE' })
      setState((previous) =>
        previous
          ? {
              ...previous,
              memories: previous.memories.filter((item) => item.id !== id),
            }
          : previous,
      )
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not forget that note.')
    }
  }

  function exportMemory() {
    const notes = state?.memories ?? []
    const rules = state?.rules ?? []
    const body = [
      '# Lumina memory',
      '',
      `Exported ${new Date().toLocaleString()}`,
      '',
      '## Facts',
      '',
      ...(state?.facts?.length
        ? state.facts.map((fact) => `- ${FACT_LABELS[fact.slot]}: ${fact.value}`)
        : ['_Nothing confirmed yet._']),
      '',
      '## Notes',
      '',
      ...(notes.length
        ? notes.map((note) => `- ${note.text} <!-- ${note.kind} -->`)
        : ['_Nothing saved yet._']),
      '',
      '## Rules',
      '',
      ...(rules.length
        ? rules.map((rule) => `- ${rule.text}`)
        : ['_Nothing taught yet._']),
      '',
    ].join('\n')
    const url = URL.createObjectURL(
      new Blob([body], { type: 'text/markdown;charset=utf-8' }),
    )
    const link = document.createElement('a')
    link.href = url
    link.download = 'lumina-memory.md'
    link.click()
    URL.revokeObjectURL(url)
    setNotice('Exported lumina-memory.md')
  }

  async function deleteConversation(id: string) {
    try {
      await request(`/api/conversations/${id}`, { method: 'DELETE' })
      setState((previous) =>
        previous
          ? {
              ...previous,
              conversations: previous.conversations.filter(
                (item) => item.id !== id,
              ),
            }
          : previous,
      )
      if (activeId === id) {
        setActiveId(null)
        setMessages([])
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not delete that chat.')
    }
  }

  const lastAssistant = [...messages]
    .reverse()
    .find((message) => message.role === 'assistant')
  const lastUser = [...messages]
    .reverse()
    .find((message) => message.role === 'user')
  const brain = lastAssistant ? brains[lastAssistant.id] : undefined
  const web = lastAssistant ? webChecks[lastAssistant.id] : undefined
  const conversationTitle =
    state?.conversations.find((item) => item.id === activeId)?.title ??
    'new session'
  const brainLabel =
    state?.ai.provider === 'gemini' ? 'gemini' : 'offline'

  const coreHint = !canChat
    ? 'add a key in settings'
    : speakingId
      ? 'click to interrupt'
      : listening
        ? heard
          ? ''
          : 'listening'
        : live
          ? 'ready'
          : 'click to speak'

  return (
    <div className="shell">
      <canvas ref={canvasRef} className="core-canvas" aria-hidden="true" />
      <div className="veil" aria-hidden="true" />
      <div className="scanlines" aria-hidden="true" />

      {stage === 'loading' ? (
        <div className="boot">
          <span className="boot-line" />
          initialising
        </div>
      ) : null}

      {stage === 'login' ? (
        <main className="login">
          <div className="login-brand">
            <span className="wordmark">LUMINA</span>
            <span className="wordmark-sub">private intelligence</span>
          </div>
          <form className="login-form" onSubmit={signIn}>
            <label className="field">
              <span>user</span>
              <input
                name="userId"
                value={userId}
                onChange={(event) => setUserId(event.target.value)}
                autoComplete="username"
                autoCapitalize="none"
                spellCheck={false}
                enterKeyHint="next"
                required
              />
            </label>
            <label className="field">
              <span>key</span>
              <input
                name="password"
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete="current-password"
                enterKeyHint="go"
                required
              />
            </label>
            {authError ? (
              <p role="alert" className="login-error">
                {authError}
              </p>
            ) : null}
            <button className="login-submit" type="submit" disabled={signingIn}>
              {signingIn ? 'entering…' : 'enter'}
            </button>
          </form>
          <p className="login-note">
            Everything stays inside this account. Nothing is shared.
          </p>
        </main>
      ) : null}

      {stage === 'ready' ? (
        <>
          <header className="hud hud-top">
            <span className="wordmark">LUMINA</span>
            <span className="hud-sep" aria-hidden="true" />
            <span className={`mode mode-${mode}`}>
              <span className="mode-dot" aria-hidden="true" />
              {MODE_LABEL[mode]}
            </span>
            <span className="hud-grow" />
            <span className="stat">
              mem <b>{state?.memories.length ?? 0}</b>
            </span>
            <span className="stat">
              facts <b>{state?.facts?.length ?? 0}</b>
            </span>
            <span className="stat">
              rules <b>{state?.rules.length ?? 0}</b>
            </span>
            <span className="stat wide">
              brain <b>{brainLabel}</b>
            </span>
            <span className="stat wide">
              web <b>live</b>
            </span>
          </header>

          <button
            type="button"
            className={`core-hit ${mode}`}
            onClick={pressCore}
            aria-label={
              speakingId
                ? 'Interrupt the answer'
                : live
                  ? 'Stop listening'
                  : 'Speak to Lumina'
            }
          >
            <span className="core-ring" aria-hidden="true" />
            {coreHint ? (
              <span className="core-hint" aria-hidden="true">
                {coreHint}
              </span>
            ) : null}
          </button>

          <section className="stream" aria-live="polite">
            {heard ? (
              <p className="said live">{heard}</p>
            ) : lastUser ? (
              <p className="said">{lastUser.content}</p>
            ) : null}

            {sending && !streamText ? (
              <p className="working">
                processing
                {elapsed > 0 ? ` · ${elapsed}s` : ''}
                <span className="dots" aria-hidden="true" />
              </p>
            ) : stage === 'ready' && (streamText || lastAssistant) ? (
              <div className="reply">
                <Markdown text={streamText || lastAssistant!.content} />
                {lastAssistant ? (<div className="reply-meta">
                  {brain ? (
                    <span className="stamp">
                      {brain.provider === 'recall'
                        ? 'recalled'
                        : `${brain.model.split('/').pop() ?? ''} · ${(
                            brain.ms / 1000
                          ).toFixed(1)}s`}
                    </span>
                  ) : null}
                  {web ? (
                    <span className="stamp">
                      {web.sources.length
                        ? `web · ${web.sources.length} source${web.sources.length > 1 ? 's' : ''}`
                        : 'web · nothing found'}
                    </span>
                  ) : null}
                  {speakingId === lastAssistant.id ? (
                    <button className="meta-button" onClick={stopAnswer}>
                      interrupt
                    </button>
                  ) : (
                    <button
                      className="meta-button"
                      onClick={() => readAloud(lastAssistant)}
                    >
                      speak
                    </button>
                  )}
                  <button
                    className="meta-button"
                    onClick={() => setThreadOpen(true)}
                  >
                    all {messages.length}
                  </button>
                </div>) : null}
              </div>
            ) : null}
          </section>

          <form
            className={live ? 'composer live' : 'composer'}
            onSubmit={(event) => {
              event.preventDefault()
              void send(draft)
            }}
          >
            <span className="composer-mark" aria-hidden="true">
              &gt;
            </span>
            <textarea
              ref={textareaRef}
              rows={1}
              value={draft}
              placeholder={
                canChat ? 'message lumina…' : 'add a key in settings to begin'
              }
              aria-label="Message"
              maxLength={60000}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={(event) => {
                if (
                  event.key === 'Enter' &&
                  !event.shiftKey &&
                  !event.nativeEvent.isComposing
                ) {
                  event.preventDefault()
                  void send(draft)
                }
              }}
            />
            {sending || speakingId ? (
              <button
                type="button"
                className="icon-button stop"
                onClick={stopAnswer}
                aria-label={speakingId ? 'Interrupt' : 'Stop'}
              >
                <Icon name="stop" size={14} />
              </button>
            ) : null}
            <button
              type="submit"
              className="icon-button send"
              disabled={!draft.trim() || sending || !canChat}
              aria-label="Send"
            >
              <Icon name="send" size={16} />
            </button>
            <button
              type="button"
              className={live ? 'icon-button mic on' : 'icon-button mic'}
              onClick={pressCore}
              aria-label={live ? 'Stop voice' : 'Speak to Lumina'}
            >
              <Icon name="mic" size={16} />
            </button>
          </form>

          {error ? (
            <p role="alert" className="alert">
              {error}
            </p>
          ) : !aiReady ? (
            <p className="alert">
              no key set —{' '}
              <button className="link" onClick={() => setDrawer('settings')}>
                open settings
              </button>
            </p>
          ) : null}

          <footer className="hud hud-bottom">
            <div className="telemetry">
              <span>
                session · {conversationTitle.toLowerCase().slice(0, 34)}
              </span>
              <span>memory · {state?.facts?.length ?? 0} exact</span>
              <span>
                net · {online ? 'online' : 'offline'}
                {sending ? ' · waiting' : speakingId ? ' · speaking' : ''}
              </span>
              <span>voice · {settings.voiceEngine}</span>
              <span>mic · {listening ? 'open' : 'closed'}</span>
            </div>

            <div className="controls">
              {live || listening || speakingId ? (
                <button className="control" onClick={pressCore}>
                  {speakingId ? 'interrupt' : 'stop'}
                </button>
              ) : (
                <button className="control" onClick={pressCore}>
                  <Icon name="mic" size={13} />
                  speak
                </button>
              )}
            </div>

            <nav className="nav" aria-label="Panels">
              <button className="nav-link" onClick={startNewChat}>
                new
              </button>
              <button
                className="nav-link"
                onClick={() => setThreadOpen(true)}
                disabled={!messages.length}
              >
                chat
              </button>
              <button
                className="nav-link history-link"
                onClick={() => setDrawer('history')}
              >
                history
              </button>
              <button className="nav-link" onClick={() => setDrawer('memory')}>
                memory
              </button>
              <button className="nav-link" onClick={() => setDrawer('settings')}>
                settings
              </button>
            </nav>
          </footer>

        </>
      ) : null}

      {notice ? (
        <div className="toast" role="status">
          {notice}
          {learned ? (
            <button type="button" className="toast-action" onClick={undoLearned}>
              undo
            </button>
          ) : null}
        </div>
      ) : null}

      {drawer ? (
        <>
          <button
            className="scrim"
            aria-label="Close panel"
            onClick={() => setDrawer(null)}
          />
          <aside className="drawer" aria-label={drawer}>
            <div className="drawer-head">
              <span className="drawer-title">{drawer}</span>
              <button
                className="icon-button"
                onClick={() => setDrawer(null)}
                aria-label="Close"
              >
                <Icon name="x" />
              </button>
            </div>

            <div className="drawer-body">
              {drawer === 'history' ? (
                <>
                  <button className="text-button" onClick={startNewChat}>
                    <Icon name="plus" size={13} /> new session
                  </button>
                  {state?.conversations.length ? (
                    <ul className="history-list">
                      {state.conversations.map((conversation) => (
                        <li
                          key={conversation.id}
                          className={
                            conversation.id === activeId ? 'current' : ''
                          }
                        >
                          <button
                            className="history-open"
                            onClick={() => void openConversation(conversation.id)}
                          >
                            <span>{conversation.title}</span>
                            <em>{when(conversation.updatedAt)}</em>
                          </button>
                          <button
                            className="icon-button"
                            aria-label={`Delete ${conversation.title}`}
                            onClick={() => void deleteConversation(conversation.id)}
                          >
                            <Icon name="trash" size={13} />
                          </button>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="empty">No sessions yet.</p>
                  )}
                </>
              ) : null}

              {drawer === 'memory' ? (
                <>
                  <p className="drawer-note">
                    What Lumina keeps between sessions. Facts are answered
                    exactly; notes and rules shape every reply.
                  </p>

                  {state?.facts?.length ? (
                    <section className="block">
                      <h3>confirmed facts</h3>
                      <ul className="fact-list">
                        {state.facts.map((fact) => (
                          <li key={fact.slot}>
                            <span className="fact-slot">
                              {FACT_LABELS[fact.slot]}
                            </span>
                            <p>{fact.value}</p>
                            <button
                              className="icon-button"
                              aria-label={`Forget ${FACT_LABELS[fact.slot]}`}
                              onClick={() => void removeFact(fact.slot)}
                            >
                              <Icon name="trash" size={13} />
                            </button>
                          </li>
                        ))}
                      </ul>
                    </section>
                  ) : null}

                  <section className="block">
                    <h3>notes</h3>
                    <form className="inline-form" onSubmit={addMemory}>
                      <select
                        value={noteKind}
                        onChange={(event) =>
                          setNoteKind(event.target.value as MemoryKind)
                        }
                        aria-label="Kind of note"
                      >
                        <option value="fact">fact</option>
                        <option value="preference">preference</option>
                        <option value="note">note</option>
                      </select>
                      <input
                        value={newNote}
                        onChange={(event) => setNewNote(event.target.value)}
                        placeholder="something to remember"
                        aria-label="New note"
                        maxLength={300}
                      />
                      <button disabled={!newNote.trim()}>save</button>
                    </form>
                    {state?.memories.length ? (
                      <ul className="entry-list">
                        {state.memories.map((memory) => (
                          <li key={memory.id}>
                            <div>
                              <p>{memory.text}</p>
                              <span className="stamp">
                                {memory.kind} · {when(memory.updatedAt)}
                              </span>
                            </div>
                            <button
                              className="icon-button"
                              aria-label="Forget this note"
                              onClick={() => void removeMemory(memory.id)}
                            >
                              <Icon name="trash" size={13} />
                            </button>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="empty">Nothing noted yet.</p>
                    )}
                  </section>

                  <section className="block">
                    <h3>rules</h3>
                    <form className="inline-form" onSubmit={addRule}>
                      <input
                        value={newRule}
                        onChange={(event) => setNewRule(event.target.value)}
                        placeholder="how to answer from now on"
                        aria-label="New rule"
                        maxLength={240}
                      />
                      <button disabled={!newRule.trim()}>teach</button>
                    </form>
                    {state?.rules.length ? (
                      <ol className="entry-list">
                        {state.rules.map((rule) => (
                          <li key={rule.id}>
                            <div>
                              <p>{rule.text}</p>
                              <span className="stamp">
                                {rule.source === 'manual' ? 'added' : 'learned'}{' '}
                                · {when(rule.createdAt)}
                              </span>
                            </div>
                            <button
                              className="icon-button"
                              aria-label="Forget this rule"
                              onClick={() => void removeRule(rule.id)}
                            >
                              <Icon name="trash" size={13} />
                            </button>
                          </li>
                        ))}
                      </ol>
                    ) : (
                      <p className="empty">Nothing taught yet.</p>
                    )}
                  </section>

                  <div className="drawer-actions">
                    <button className="text-button" onClick={exportMemory}>
                      export .md
                    </button>
                    <button
                      className="text-button"
                      onClick={() => void signOut()}
                    >
                      sign out
                    </button>
                  </div>
                </>
              ) : null}

              {drawer === 'settings' ? (
                <>
                  <section className="block">
                    <h3>voice</h3>
                    <label className="row">
                      <span>
                        <strong>Speak replies aloud</strong>
                        <small>Read every answer out loud. Engine and volume below.</small>
                      </span>
                      <input
                        type="checkbox"
                        checked={settings.voiceReplies}
                        onChange={(event) => {
                          if (!event.target.checked) {
                            stopSpeaking()
                            setSpeakingId(null)
                          }
                          void updateSettings({
                            voiceReplies: event.target.checked,
                          })
                        }}
                      />
                    </label>
                    <label className="row">
                      <span>
                        <strong>Send when I stop talking</strong>
                        <small>Off fills the text field to edit first.</small>
                      </span>
                      <input
                        type="checkbox"
                        checked={settings.autoSend}
                        onChange={(event) =>
                          void updateSettings({ autoSend: event.target.checked })
                        }
                      />
                    </label>
                    <label className="row">
                      <span>
                        <strong>Voice engine</strong>
                        <small>
                          Neural is the model's own speech; device uses the voices
                          installed here.
                        </small>
                      </span>
                      <select
                        value={settings.voiceEngine}
                        onChange={(event) => {
                          stopAnswer()
                          void updateSettings({
                            voiceEngine: event.target.value as Settings['voiceEngine'],
                          })
                        }}
                      >
                        <option value="neural">neural</option>
                        <option value="device">device</option>
                      </select>
                    </label>
                    {settings.voiceEngine === 'neural' ? (
                      <label className="row">
                        <span>
                          <strong>Neural voice</strong>
                          <small>Kore is calm; Puck is brighter.</small>
                        </span>
                        <select
                          value={settings.neuralVoice}
                          onChange={(event) => {
                            stopAnswer()
                            void updateSettings({ neuralVoice: event.target.value })
                          }}
                        >
                          {NEURAL_VOICES.map((voice) => (
                            <option key={voice} value={voice}>
                              {voice}
                            </option>
                          ))}
                        </select>
                      </label>
                    ) : (
                      <label className="row">
                        <span>
                          <strong>Device voice</strong>
                          <small>Automatic picks the best one installed.</small>
                        </span>
                        <select
                          value={settings.voiceName}
                          onChange={(event) => {
                            stopAnswer()
                            void updateSettings({ voiceName: event.target.value })
                          }}
                        >
                          <option value="">automatic</option>
                          {voices.map((voice) => (
                            <option key={voice.name} value={voice.name}>
                              {voice.name}
                            </option>
                          ))}
                        </select>
                      </label>
                    )}
                    <label className="row">
                      <span>
                        <strong>Volume</strong>
                        <small>{Math.round(settings.voiceVolume * 100)}%</small>
                      </span>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        step={5}
                        value={Math.round(settings.voiceVolume * 100)}
                        onChange={(event) =>
                          setVoiceVolume(Number(event.target.value) / 100)
                        }
                        aria-label="Voice volume"
                      />
                    </label>
                    <label className="row">
                      <span>
                        <strong>Language</strong>
                        <small>What the microphone listens for.</small>
                      </span>
                      <select
                        value={settings.speechLang}
                        onChange={(event) =>
                          void updateSettings({ speechLang: event.target.value })
                        }
                      >
                        {LANGUAGES.map((language) => (
                          <option key={language.tag} value={language.tag}>
                            {language.label}
                          </option>
                        ))}
                      </select>
                    </label>
                    <p className="fine">
                      {speechSupported()
                        ? 'microphone · ready'
                        : 'microphone · needs Chrome, Edge or Safari'}
                    </p>
                  </section>

                  <section className="block">
                    <h3>brain</h3>
                    <div className="row static">
                      <span>
                        <strong>
                          {state?.ai.provider === 'gemini'
                            ? 'Gemini'
                            : 'No model yet'}
                        </strong>
                        <small>
                          Requests leave from the server, never the browser.
                        </small>
                      </span>
                      <code className="pill">{state?.ai.model ?? 'none'}</code>
                    </div>
                    <div className="key-box">
                      <div className="key-head">
                        <strong>api key</strong>
                        <span className={aiReady ? 'status on' : 'status'}>
                          {state?.ai.source === 'account'
                            ? 'on your account'
                            : state?.ai.source === 'server'
                              ? 'on the server'
                              : 'not set'}
                        </span>
                      </div>
                      <p className="fine">
                        Gemini {state?.ai.keys.gemini ? 'saved' : '—'} · stored
                        server-side, never sent to the browser.
                      </p>
                      <form
                        className="inline-form"
                        onSubmit={(event) => {
                          event.preventDefault()
                          void saveApiKey(keyDraft)
                        }}
                      >
                        <input
                          type="password"
                          value={keyDraft}
                          onChange={(event) => setKeyDraft(event.target.value)}
                          placeholder="AIza… or AQ.… Gemini key"
                          aria-label="API key"
                          autoComplete="off"
                          spellCheck={false}
                          maxLength={200}
                        />
                        <button
                          type="submit"
                          disabled={!keyDraft.trim() || savingKey}
                        >
                          {savingKey ? 'saving…' : 'save'}
                        </button>
                      </form>
                      {state?.ai.source === 'account' ? (
                        <button
                          className="text-button"
                          onClick={() => void saveApiKey('')}
                          disabled={savingKey}
                        >
                          remove key
                        </button>
                      ) : null}
                    </div>
                    <div className="row static">
                      <span>
                        <strong>Live web</strong>
                        <small>Checked on every message, not only on request.</small>
                      </span>
                      <code className="pill on">always</code>
                    </div>
                    <div className="row static">
                      <span>
                        <strong>Sync</strong>
                        <small>Chats, notes, rules and settings follow you.</small>
                      </span>
                      <code className="pill">
                        {state?.memories.length ?? 0}n · {state?.rules.length ?? 0}r
                      </code>
                    </div>
                  </section>

                  <div className="drawer-actions">
                    <button className="text-button" onClick={() => void signOut()}>
                      sign out
                    </button>
                  </div>
                </>
              ) : null}
            </div>
          </aside>
        </>
      ) : null}

      {threadOpen ? (
        <div className="thread" role="dialog" aria-label="Transcript">
          <div className="thread-head">
            <span className="drawer-title">{conversationTitle}</span>
            <button
              className="icon-button"
              onClick={() => setThreadOpen(false)}
              aria-label="Close transcript"
            >
              <Icon name="x" />
            </button>
          </div>
          <div className="thread-body" ref={threadRef}>
            {messages.length ? (
              messages.map((message) =>
                message.role === 'assistant' ? (
                  <article key={message.id} className="thread-turn assistant">
                    <Markdown text={message.content} />
                    <span className="stamp">{when(message.createdAt)}</span>
                  </article>
                ) : (
                  <article key={message.id} className="thread-turn user">
                    <p>{message.content}</p>
                  </article>
                ),
              )
            ) : (
              <p className="empty">Nothing said yet.</p>
            )}
          </div>
        </div>
      ) : null}
    </div>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
