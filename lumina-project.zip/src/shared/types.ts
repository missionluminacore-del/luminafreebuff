export type Role = 'user' | 'assistant'

export type Conversation = {
  id: string
  title: string
  createdAt: number
  updatedAt: number
}

export type ChatMessage = {
  id: string
  conversationId: string
  role: Role
  content: string
  createdAt: number
}

/** A permanent instruction the assistant follows in every future reply. */
export type Rule = {
  id: string
  text: string
  source: 'auto' | 'manual'
  createdAt: number
}

/** What a lasting note about the person is for. */
export type MemoryKind = 'fact' | 'preference' | 'note'

/**
 * Long-term memory: a durable note about the person, their people, projects
 * and plans. Unlike a rule it is context, not an instruction, and unlike a
 * message it survives every chat and every device.
 */
export type Memory = {
  id: string
  text: string
  kind: MemoryKind
  createdAt: number
  updatedAt: number
}

/**
 * A confirmed personal fact, stored in its own slot so it can be answered
 * exactly ("your birthday is 30 October") without asking a model to remember.
 */
export const FACT_SLOTS = [
  'name',
  'birthday',
  'age',
  'city',
  'job',
  'company',
] as const

export type FactSlot = (typeof FACT_SLOTS)[number]

export type Fact = {
  slot: FactSlot
  value: string
  updatedAt: number
}

export const THEMES = [
  { id: 'light', label: 'Daylight' },
  { id: 'dark', label: 'Midnight' },
  { id: 'nebula', label: 'Nebula' },
  { id: 'ember', label: 'Ember' },
] as const

export type ThemeName = (typeof THEMES)[number]['id']

/** Kept for stored settings; Gemini is the only brain now. */
export type BrainPreference = 'auto' | 'gemini'

/** Spoken replies come from the device's voices or the neural audio model. */
export type VoiceEngine = 'neural' | 'device'

/** Gemini's prebuilt conversational voices, used by the neural engine. */
export const NEURAL_VOICES = [
  'Kore',
  'Puck',
  'Charon',
  'Fenrir',
  'Aoede',
  'Leda',
  'Orus',
  'Zephyr',
] as const

export type NeuralVoice = (typeof NEURAL_VOICES)[number]

/** Audio sent back by the speech route: 16-bit PCM at `sampleRate`. */
export type SpeechAudio = {
  /** Base64 of little-endian 16-bit PCM. */
  audio: string
  mimeType: string
  sampleRate: number
  voice: string
}

export type Settings = {
  /** Read replies out loud. */
  voiceReplies: boolean
  /** Send the message as soon as dictation finishes. */
  autoSend: boolean
  /** Preferred speech-synthesis voice name, empty for the device default. */
  voiceName: string
  /** Which voice reads replies aloud. */
  voiceEngine: VoiceEngine
  /** Gemini voice for the neural engine. */
  neuralVoice: string
  /** Playback volume for spoken replies, 0..1. */
  voiceVolume: number
  /** BCP-47 language used for speech recognition. */
  speechLang: string
  /** Colour theme, synced with the account. */
  theme: ThemeName
  /** Which provider to prefer when both keys are present. */
  brain: BrainPreference
}

export const LANGUAGES = [
  { tag: 'en-US', label: 'English (US)' },
  { tag: 'en-GB', label: 'English (UK)' },
  { tag: 'es-ES', label: 'Español' },
  { tag: 'fr-FR', label: 'Français' },
  { tag: 'de-DE', label: 'Deutsch' },
  { tag: 'pt-BR', label: 'Português (BR)' },
  { tag: 'it-IT', label: 'Italiano' },
  { tag: 'nl-NL', label: 'Nederlands' },
  { tag: 'hi-IN', label: 'हिन्दी' },
  { tag: 'ar-SA', label: 'العربية' },
  { tag: 'ja-JP', label: '日本語' },
  { tag: 'ko-KR', label: '한국어' },
  { tag: 'zh-CN', label: '中文（简体）' },
] as const

export const defaultSettings: Settings = {
  voiceReplies: true,
  autoSend: true,
  voiceName: '',
  voiceEngine: 'neural',
  // Charon is the calm, low voice that suits the assistant's manner.
  neuralVoice: 'Charon',
  voiceVolume: 0.9,
  speechLang: 'en-US',
  theme: 'light',
  brain: 'auto',
}

const isTheme = (value: unknown): value is ThemeName =>
  THEMES.some((theme) => theme.id === value)

const isBrain = (value: unknown): value is BrainPreference =>
  value === 'auto' || value === 'gemini'

export function normalizeSettings(input: unknown): Settings {
  const source =
    input && typeof input === 'object' && !Array.isArray(input)
      ? (input as Record<string, unknown>)
      : {}
  const lang =
    typeof source.speechLang === 'string' &&
    /^[a-z]{2,3}(-[A-Za-z0-9]{2,8})?$/.test(source.speechLang)
      ? source.speechLang
      : defaultSettings.speechLang
  return {
    voiceReplies:
      typeof source.voiceReplies === 'boolean'
        ? source.voiceReplies
        : defaultSettings.voiceReplies,
    autoSend:
      typeof source.autoSend === 'boolean'
        ? source.autoSend
        : defaultSettings.autoSend,
    voiceName:
      typeof source.voiceName === 'string'
        ? source.voiceName.slice(0, 120)
        : defaultSettings.voiceName,
    voiceEngine:
      source.voiceEngine === 'device' || source.voiceEngine === 'neural'
        ? source.voiceEngine
        : defaultSettings.voiceEngine,
    neuralVoice:
      typeof source.neuralVoice === 'string' &&
      (NEURAL_VOICES as readonly string[]).includes(source.neuralVoice)
        ? source.neuralVoice
        : defaultSettings.neuralVoice,
    voiceVolume:
      typeof source.voiceVolume === 'number' &&
      Number.isFinite(source.voiceVolume)
        ? Math.min(1, Math.max(0, source.voiceVolume))
        : defaultSettings.voiceVolume,
    speechLang: lang,
    theme: isTheme(source.theme) ? source.theme : defaultSettings.theme,
    brain: isBrain(source.brain) ? source.brain : defaultSettings.brain,
  }
}

export type Session = {
  /** The signed-in owner. The app has a single private login. */
  authenticated: boolean
  database: boolean
}

export type AiStatus = {
  /** A key is available, so chat turns can run. */
  configured: boolean
  /** The model that answers first. */
  model: string
  /** Which service that model belongs to. */
  provider: 'gemini' | 'none'
  /** The account's own key, the server secret, or nowhere. */
  source: 'account' | 'server' | 'none'
  /** Kept for stored settings. */
  preference: BrainPreference
  /** A second model is available when the first is busy. */
  fallback: boolean
  /** Whether a Gemini key is available at all. */
  keys: { gemini: boolean }
}

export type AppState = {
  conversations: Conversation[]
  rules: Rule[]
  memories: Memory[]
  facts: Fact[]
  settings: Settings
  ai: AiStatus
  /** Voice replies still to be sent before the free daily limit runs out. */
  quota?: { used: number; limit: number } | null
}

/** One live page Lumina read for a reply, so the check is visible. */
export type WebSourceRef = {
  title: string
  url: string
}

/** What was looked up for this reply, and what came back. */
export type WebCheck = {
  query: string
  sources: WebSourceRef[]
}

export type ChatResponse = {
  conversation: Conversation
  userMessage: ChatMessage
  assistantMessage: ChatMessage
  newRules: Rule[]
  newMemories: Memory[]
  /** Confirmed personal facts learned or corrected on this turn. */
  newFacts?: Fact[]
  /** The answer written for the ear, when it differs from the written one. */
  spoken?: string
  /** Which brain answered and how long it took, so nothing is pretending. */
  brain?: {
    model: string
    provider: 'gemini' | 'recall'
    ms: number
    lookupMs: number
  }
  /** Present when the web was checked, even if nothing useful came back. */
  web?: WebCheck
}
