import { afterAll, beforeAll, expect, test } from 'bun:test'
import { Miniflare } from 'miniflare'
import { createApp } from '../src/worker/app'
import { AiError, type AiClient } from '../src/worker/ai'
import { attemptLogin, currentUser, type Env } from '../src/worker/auth'
import { lookupWeb } from '../src/worker/web'

const ORIGIN = 'https://app.example.test'
/** Test-only credentials; the real ones live in project secrets. */
const OWNER = 'lumina'
const PASSWORD = 'test-owner-password'

const runtime = new Miniflare({
  workers: [
    {
      config: {
        name: 'test-db',
        compatibilityDate: '2026-11-11',
        manifest: {
          mainModule: 'index.js',
          modules: {
            'index.js': {
              type: 'esm',
              contents:
                'export default { fetch() { return new Response("test") } }',
            },
          },
        },
        env: { DB: { type: 'd1', name: 'sage-test' } },
      },
    },
  ],
  port: 0,
})
let env: Env
beforeAll(async () => {
  const db = await runtime.getD1Database('DB')
  env = {
    DB: db as unknown as D1Database,
    GEMINI_API_KEY: 'test-key',
    LUMINA_USER_ID: OWNER,
    LUMINA_PASSWORD: PASSWORD,
    ASSETS: {
      fetch: async () => new Response('public page'),
    } as unknown as Fetcher,
  }
}, 20_000)
afterAll(() => runtime.dispose())

/** A stand-in for Gemini so the suite never calls the network. */
const fakeAi: AiClient = async (request) => {
  const last = request.history[request.history.length - 1]
  const isCorrection = /instead|always|from now on/i.test(last?.text ?? '')
  return {
    reply: `Answer to: ${last?.text ?? ''}${
      request.rules.length ? ` (following ${request.rules.length} rules)` : ''
    }`,
    rules: isCorrection
      ? [{ text: 'Answer in short bullet points.' }]
      : [{ text: 'Answer in short bullet points.' }],
    model: 'fake-model',
  }
}

// The identity seam exists only in the app factory. The Worker entrypoint never
// reads these test headers and always calls the real auth SDK.
const app = createApp(async (request) => {
  const sub = request.headers.get('test-user')
  return sub ? { sub } : null
}, fakeAi)

const call = (
  path: string,
  user?: string,
  method = 'GET',
  body?: unknown,
  origin = ORIGIN,
  target = app,
  bindings: Env = env,
) =>
  target.request(
    `https://app.example.test${path}`,
    {
      method,
      headers: {
        ...(user ? { 'test-user': user } : {}),
        Origin: origin,
        'Content-Type': 'application/json',
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    },
    bindings,
  )

type StateBody = {
  conversations: { id: string; title: string }[]
  rules: { id: string; text: string; source: string }[]
  settings: {
    voiceReplies: boolean
    autoSend: boolean
    speechLang: string
    voiceEngine: 'neural' | 'device'
    neuralVoice: string
    voiceVolume: number
  }
  ai: {
    configured: boolean
    model: string
    source: string
    provider: string
    preference: string
    fallback: boolean
    keys: { gemini: boolean }
  }
  facts?: { slot: string; value: string }[]
  memories?: { id: string; text: string; kind: string }[]
}

test('unauthenticated data routes refuse access and public assets remain public', async () => {
  for (const [path, method] of [
    ['/api/state', 'GET'],
    ['/api/conversations', 'POST'],
    ['/api/chat', 'POST'],
    ['/api/rules', 'POST'],
    ['/api/settings', 'PUT'],
  ]) {
    const response = await call(path!, undefined, method)
    expect(response.status).toBe(401)
    expect(response.headers.get('Cache-Control')).toBe('private, no-store')
  }
  expect(await (await call('/')).text()).toBe('public page')
  expect((await call('/api/health')).status).toBe(200)
})

test('a chat turn is stored, titled and answered with the taught rules', async () => {
  const first = await call('/api/chat', 'alice', 'POST', {
    text: 'Plan my morning around one deep-work block',
  })
  expect(first.status).toBe(200)
  const body = (await first.json()) as {
    conversation: { id: string; title: string }
    userMessage: { role: string; content: string }
    assistantMessage: { role: string; content: string }
    newRules: { text: string }[]
  }
  expect(body.conversation.title).toBe('Plan my morning around one deep-work block')
  expect(body.userMessage).toMatchObject({ role: 'user' })
  expect(body.assistantMessage.content).toContain('Answer to:')
  expect(body.newRules).toHaveLength(1)
  expect(body.newRules[0]!.text).toBe('Answer in short bullet points.')

  // The next turn reuses the conversation, and the learned rule is applied once.
  const second = await call('/api/chat', 'alice', 'POST', {
    conversationId: body.conversation.id,
    text: 'Now shorten it',
  })
  const reply = (await second.json()) as {
    assistantMessage: { content: string }
    newRules: unknown[]
    conversation: { id: string }
  }
  expect(reply.conversation.id).toBe(body.conversation.id)
  expect(reply.assistantMessage.content).toContain('following 1 rules')
  expect(reply.newRules).toHaveLength(0)

  const thread = (await (
    await call(`/api/conversations/${body.conversation.id}`, 'alice')
  ).json()) as { messages: { role: string }[] }
  expect(thread.messages.map((message) => message.role)).toEqual([
    'user',
    'assistant',
    'user',
    'assistant',
  ])

  const state = (await (await call('/api/state', 'alice')).json()) as StateBody
  expect(state.conversations).toHaveLength(1)
  expect(state.rules).toHaveLength(1)
  expect(state.ai).toEqual({
    configured: true,
    model: 'gemini-flash-lite-latest',
    provider: 'gemini',
    source: 'server',
    preference: 'auto',
    fallback: false,
    keys: { gemini: true },
  })
})

test('every record is scoped to the signed-in account', async () => {
  const created = (await (
    await call('/api/chat', 'carol', 'POST', { text: 'Notes for carol only' })
  ).json()) as { conversation: { id: string } }
  const id = created.conversation.id

  const dave = (await (await call('/api/state', 'dave')).json()) as StateBody
  expect(dave.conversations).toHaveLength(0)
  expect(dave.rules).toHaveLength(0)

  expect((await call(`/api/conversations/${id}`, 'dave')).status).toBe(404)
  expect(
    (await call(`/api/conversations/${id}`, 'dave', 'PATCH', { title: 'Mine' }))
      .status,
  ).toBe(404)
  expect(
    (await call(`/api/conversations/${id}`, 'dave', 'DELETE')).status,
  ).toBe(404)

  const daveRule = (await (
    await call('/api/rules', 'dave', 'POST', { text: 'Dave likes metric units.' })
  ).json()) as { rule: { id: string } }
  expect(
    (
      await call(`/api/rules/${daveRule.rule.id}`, 'carol', 'PATCH', {
        text: 'Hijacked rule',
      })
    ).status,
  ).toBe(404)
  expect(
    (await call(`/api/rules/${daveRule.rule.id}`, 'carol', 'DELETE')).status,
  ).toBe(404)

  expect(
    (await call(`/api/conversations/${id}`, 'carol', 'DELETE')).status,
  ).toBe(200)
  const carol = (await (await call('/api/state', 'carol')).json()) as StateBody
  expect(carol.conversations).toHaveLength(0)
})

test('rules can be taught and forgotten by hand, without duplicates', async () => {
  const created = await call('/api/rules', 'erin', 'POST', {
    text: '  Use   metric units.  ',
  })
  expect(created.status).toBe(201)
  const { rule } = (await created.json()) as {
    rule: { id: string; text: string; source: string }
  }
  expect(rule.text).toBe('Use metric units.')
  expect(rule.source).toBe('manual')

  expect(
    (await call('/api/rules', 'erin', 'POST', { text: 'use metric units' }))
      .status,
  ).toBe(409)
  for (const text of ['', '   ', 'abc', 'x'.repeat(241), 42]) {
    expect(
      (await call('/api/rules', 'erin', 'POST', { text })).status,
    ).toBe(400)
  }

  const renamed = await call(`/api/rules/${rule.id}`, 'erin', 'PATCH', {
    text: 'Use metric units and 24-hour time.',
  })
  expect(await renamed.json()).toMatchObject({
    rule: { text: 'Use metric units and 24-hour time.' },
  })

  expect((await call(`/api/rules/${rule.id}`, 'erin', 'DELETE')).status).toBe(
    200,
  )
  expect(
    ((await (await call('/api/state', 'erin')).json()) as StateBody).rules,
  ).toHaveLength(0)
})

test('settings persist per account and reject nonsense', async () => {
  const saved = await call('/api/settings', 'frank', 'PUT', {
    voiceReplies: false,
    autoSend: false,
    voiceName: 'Test Voice',
    speechLang: 'fr-FR',
  })
  expect(await saved.json()).toMatchObject({
    settings: {
      voiceReplies: false,
      autoSend: false,
      voiceName: 'Test Voice',
      speechLang: 'fr-FR',
    },
  })
  const reread = (await (
    await call('/api/state', 'frank')
  ).json()) as StateBody
  expect(reread.settings).toMatchObject({ voiceReplies: false, speechLang: 'fr-FR' })

  const sanitized = await call('/api/settings', 'frank', 'PUT', {
    voiceReplies: 'yes',
    speechLang: '<script>',
    voiceName: 12,
  })
  expect(await sanitized.json()).toMatchObject({
    settings: { voiceReplies: true, speechLang: 'en-US', voiceName: '' },
  })
  const other = (await (await call('/api/state', 'gina')).json()) as StateBody
  expect(other.settings.voiceReplies).toBe(true)
})

test('guard rails: origins, body limits, validation and missing setup', async () => {
  expect(
    (
      await call(
        '/api/chat',
        'alice',
        'POST',
        { text: 'hello' },
        'https://foreign.example',
      )
    ).status,
  ).toBe(403)
  expect(
    (
      await app.request(
        'https://app.example.test/api/chat',
        {
          method: 'POST',
          headers: { 'test-user': 'alice', 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: 'hello' }),
        },
        env,
      )
    ).status,
  ).toBe(403)

  for (const body of [{ text: '' }, { text: '   ' }, { text: 5 }, {}, [], null]) {
    expect((await call('/api/chat', 'alice', 'POST', body)).status).toBe(400)
  }
  // Long pastes are accepted now, up to the documented ceiling.
  expect(
    (await call('/api/chat', 'alice', 'POST', { text: 'x'.repeat(60_001) })).status,
  ).toBe(400)
  expect(
    (await call('/api/chat', 'alice', 'POST', { text: 'x'.repeat(30_000) })).status,
  ).not.toBe(413)
  expect(
    (
      await app.request(
        'https://app.example.test/api/chat',
        {
          method: 'POST',
          headers: {
            'test-user': 'alice',
            Origin: ORIGIN,
            'Content-Type': 'application/json',
          },
          body: 'not JSON',
        },
        env,
      )
    ).status,
  ).toBe(400)

  const noKey = await call(
    '/api/chat',
    'alice',
    'POST',
    { text: 'hello' },
    ORIGIN,
    app,
    { ...env, GEMINI_API_KEY: undefined },
  )
  expect(noKey.status).toBe(503)
  expect(((await noKey.json()) as { error: string }).error).toContain(
    'API key',
  )

  const noDb = await call(
    '/api/state',
    'alice',
    'GET',
    undefined,
    ORIGIN,
    app,
    { ...env, DB: undefined },
  )
  expect(noDb.status).toBe(503)
})

test('a model failure never stores half a conversation', async () => {
  const failing = createApp(async (request) => {
    const sub = request.headers.get('test-user')
    return sub ? { sub } : null
  }, async () => {
    throw new AiError('Gemini is rate limited for now.', 'quota')
  })
  const response = await call(
    '/api/chat',
    'helen',
    'POST',
    { text: 'Will this be saved?' },
    ORIGIN,
    failing,
  )
  expect(response.status).toBe(429)
  const state = (await (
    await call('/api/state', 'helen')
  ).json()) as StateBody
  expect(state.conversations).toHaveLength(0)
})

test('an account can save its own Gemini key without it ever being echoed back', async () => {
  const usedKeys: string[] = []
  const scoped = createApp(
    async (request) => {
      const sub = request.headers.get('test-user')
      return sub ? { sub } : null
    },
    async (request) => {
      usedKeys.push(request.keys.gemini ?? '')
      return { reply: 'Answered with the account key.', rules: [], model: 'fake-model' }
    },
  )
  const noKey: Env = { ...env, GEMINI_API_KEY: undefined }

  expect(
    (
      await call('/api/chat', 'ivy', 'POST', { text: 'hi' }, ORIGIN, scoped, noKey)
    ).status,
  ).toBe(503)

  const key = 'AIzaSyTestKeyForTheSuite1234567890'
  for (const apiKey of ['short', 'x'.repeat(201), 42, null, {}]) {
    expect(
      (
        await call(
          '/api/settings/api-key',
          'ivy',
          'PUT',
          { apiKey },
          ORIGIN,
          scoped,
          noKey,
        )
      ).status,
    ).toBe(400)
  }

  const saved = await call(
    '/api/settings/api-key',
    'ivy',
    'PUT',
    { apiKey: `  "${key}"  ` },
    ORIGIN,
    scoped,
    noKey,
  )
  expect(saved.status).toBe(200)
  expect((await saved.json()) as { ai: unknown }).toMatchObject({
    ai: { configured: true, source: 'account' },
  })

  const state = (await (
    await call('/api/state', 'ivy', 'GET', undefined, ORIGIN, scoped, noKey)
  ).json()) as StateBody
  expect(state.ai).toEqual({
    configured: true,
    model: 'gemini-flash-lite-latest',
    provider: 'gemini',
    source: 'account',
    preference: 'auto',
    fallback: false,
    keys: { gemini: true },
  })
  expect(JSON.stringify(state)).not.toContain(key)

  expect(
    (
      await call('/api/chat', 'ivy', 'POST', { text: 'Use my key' }, ORIGIN, scoped, noKey)
    ).status,
  ).toBe(200)
  expect(usedKeys).toEqual([key])

  // One account's key never switches the assistant on for anybody else.
  expect(
    (
      await call('/api/chat', 'jack', 'POST', { text: 'hi' }, ORIGIN, scoped, noKey)
    ).status,
  ).toBe(503)

  const cleared = await call(
    '/api/settings/api-key',
    'ivy',
    'PUT',
    { apiKey: '' },
    ORIGIN,
    scoped,
    noKey,
  )
  expect(await cleared.json()).toMatchObject({
    ai: { configured: false, source: 'none' },
  })
  expect(
    (
      await call('/api/chat', 'ivy', 'POST', { text: 'hi again' }, ORIGIN, scoped, noKey)
    ).status,
  ).toBe(503)
})

test('the private login issues a session cookie and refuses wrong credentials', async () => {
  expect(await attemptLogin(OWNER, 'wrong', 'suite-a', env)).toBe('bad')
  expect(await attemptLogin('someone', PASSWORD, 'suite-a', env)).toBe('bad')
  expect(await attemptLogin(OWNER, PASSWORD, 'suite-a', env)).toBe('ok')
  expect(await attemptLogin(OWNER, PASSWORD, 'suite-b', { ASSETS: env.ASSETS })).toBe(
    'unconfigured',
  )

  const real = createApp()
  const signIn = (userId: string, password: string) =>
    real.request(
      `${ORIGIN}/api/login`,
      {
        method: 'POST',
        headers: { Origin: ORIGIN, 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, password }),
      },
      env,
    )

  const wrong = await signIn('lumina', 'not-the-password')
  expect(wrong.status).toBe(401)

  const good = await signIn(OWNER, PASSWORD)
  expect(good.status).toBe(200)
  const cookie = good.headers.get('set-cookie') ?? ''
  expect(cookie).toContain('lumina_session=')
  expect(cookie).toContain('HttpOnly')

  const session = await real.request(
    `${ORIGIN}/api/session`,
    { headers: { cookie: cookie.split(';')[0]! } },
    env,
  )
  expect(await session.json()).toEqual({ authenticated: true, database: true })

  // The same session works as a bearer token, for browsers that drop the
  // cookie because the app is embedded in another site.
  const token = ((await good.clone().json()) as { token?: string }).token ?? ''
  expect(token).toContain('.')
  const viaToken = await real.request(
    `${ORIGIN}/api/state`,
    { headers: { authorization: `Bearer ${token}` } },
    env,
  )
  expect(viaToken.status).toBe(200)
  expect(
    await currentUser(
      new Request(`${ORIGIN}/`, {
        headers: { authorization: 'Bearer 9.abc' },
      }),
      env,
    ),
  ).toBeNull()

  const state = await real.request(
    `${ORIGIN}/api/state`,
    { headers: { cookie: cookie.split(';')[0]! } },
    env,
  )
  expect(state.status).toBe(200)

  // A made-up or tampered cookie is not a session.
  expect(
    await currentUser(
      new Request(`${ORIGIN}/`, { headers: { cookie: 'lumina_session=9.abc' } }),
      env,
    ),
  ).toBeNull()
  expect(await currentUser(new Request(`${ORIGIN}/`), env)).toBeNull()
})

test('the web is checked on every turn, not just current-events ones', async () => {
  const lookups: { text: string; context?: string }[] = []
  const seen: { web?: unknown } = {}
  const model: AiClient = async (request) => {
    seen.web = request.web ?? null
    return { reply: 'Fresh answer', rules: [], model: 'fake-model' }
  }
  const local = createApp(
    async (request) =>
      request.headers.get('test-user') ? { sub: 'zed' } : null,
    model,
    async (text, context) => {
      lookups.push({ text, context })
      return {
        query: 'latest news',
        sources: [
          {
            title: 'Wire',
            url: 'https://example.com/story',
            snippet: 'Fresh',
          },
        ],
      }
    },
  )

  const live = await call(
    '/api/chat',
    'zed',
    'POST',
    { text: 'What is the latest news today?' },
    ORIGIN,
    local,
  )
  expect(live.status).toBe(200)
  expect(lookups).toHaveLength(1)
  expect(seen.web).toEqual({
    query: 'latest news',
    sources: [
      { title: 'Wire', url: 'https://example.com/story', snippet: 'Fresh' },
    ],
  })
  // The reply says what was looked up, so the check is visible in the UI.
  const liveBody = (await live.json()) as {
    conversation: { id: string }
    web?: unknown
  }
  expect(liveBody.web).toEqual({
    query: 'latest news',
    sources: [{ title: 'Wire', url: 'https://example.com/story' }],
  })

  const plain = await call(
    '/api/chat',
    'zed',
    'POST',
    { text: 'Explain photosynthesis simply' },
    ORIGIN,
    local,
  )
  expect(plain.status).toBe(200)
  expect(lookups).toHaveLength(2)

  // A follow-up carries the previous message, so it searches the topic.
  await call(
    '/api/chat',
    'zed',
    'POST',
    { conversationId: liveBody.conversation.id, text: 'And tomorrow?' },
    ORIGIN,
    local,
  )
  expect(lookups.at(-1)).toEqual({
    text: 'And tomorrow?',
    context: 'What is the latest news today?',
  })

  // Small talk needs no lookup, so the real search helper bails out first.
  expect(await lookupWeb('thanks!')).toBeNull()
})

test('lasting facts survive the conversation and reach the next one', async () => {
  const prompts: number[] = []
  const model: AiClient = async (request) => {
    prompts.push(request.memories?.length ?? 0)
    return {
      reply: `I know ${request.memories?.length ?? 0} things about you.`,
      rules: [],
      memories: [{ text: 'Runs a small design studio in Leeds.', kind: 'fact' }],
      model: 'fake-model',
    }
  }
  const local = createApp(
    async (request) =>
      request.headers.get('test-user') ? { sub: 'mira' } : null,
    model,
    async () => null,
  )

  const first = await call(
    '/api/chat',
    'mira',
    'POST',
    { text: 'I run a small design studio in Leeds' },
    ORIGIN,
    local,
  )
  const firstBody = (await first.json()) as {
    conversation: { id: string }
    newMemories: { text: string; kind: string }[]
  }
  expect(
    firstBody.newMemories.map((item) => ({
      text: item.text,
      kind: item.kind,
    })),
  ).toEqual([{ text: 'Runs a small design studio in Leeds.', kind: 'fact' }])

  // A different chat, later: the note is still in the prompt and is not stored
  // a second time.
  const second = await call(
    '/api/chat',
    'mira',
    'POST',
    { text: 'What should I focus on this week?' },
    ORIGIN,
    local,
  )
  const secondBody = (await second.json()) as {
    assistantMessage: { content: string }
    newMemories: unknown[]
  }
  expect(secondBody.assistantMessage.content).toBe(
    'I know 1 things about you.',
  )
  expect(secondBody.newMemories).toHaveLength(0)
  expect(prompts).toEqual([0, 1])

  const state = (await (
    await call('/api/state', 'mira', 'GET', undefined, ORIGIN, local)
  ).json()) as { memories: { id: string; text: string }[] }
  expect(state.memories).toHaveLength(1)

  // Notes can be added and cleared by hand too.
  const added = await call(
    '/api/memories',
    'mira',
    'POST',
    { text: '  Prefers  metric units. ', kind: 'preference' },
    ORIGIN,
    local,
  )
  expect(added.status).toBe(201)
  const memory = ((await added.json()) as { memory: { id: string; text: string } })
    .memory
  expect(memory.text).toBe('Prefers metric units.')
  expect(
    (
      await call('/api/memories', 'mira', 'POST', { text: 'prefers metric units' }, ORIGIN, local)
    ).status,
  ).toBe(409)
  expect(
    (
      await call(`/api/memories/${memory.id}`, 'mira', 'DELETE', undefined, ORIGIN, local)
    ).status,
  ).toBe(200)
  expect(
    (
      await call(`/api/memories/${memory.id}`, 'nora', 'DELETE', undefined, ORIGIN, local)
    ).status,
  ).toBe(404)
})

test('a stated fact is answered exactly in a new chat, with no model involved', async () => {
  const turns: { text: string; voice?: boolean; facts: number }[] = []
  const model: AiClient = async (request) => {
    turns.push({
      text: request.history.at(-1)?.text ?? '',
      voice: request.voice,
      facts: request.facts?.length ?? 0,
    })
    return {
      reply: 'Sure.',
      rules: [],
      // The model restates the birthday as a note: that must not be stored twice.
      memories: [{ text: 'Birthday is 30 October.', kind: 'fact' }],
      model: 'fake-model',
    }
  }
  const local = createApp(
    async (request) =>
      request.headers.get('test-user') ? { sub: 'omar' } : null,
    model,
    async () => null,
  )

  const first = await call(
    '/api/chat',
    'omar',
    'POST',
    { text: 'my birthday is 30 October' },
    ORIGIN,
    local,
  )
  const created = (await first.json()) as {
    newFacts?: { slot: string; value: string }[]
    newMemories: unknown[]
  }
  expect(created.newFacts?.map((fact) => [fact.slot, fact.value])).toEqual([
    ['birthday', '30 October'],
  ])
  expect(created.newMemories).toHaveLength(0)
  // A statement is a statement: the model was still asked that turn.
  expect(turns).toHaveLength(1)

  // A different chat, later: the answer comes from the slot, not a guess.
  const second = await call(
    '/api/chat',
    'omar',
    'POST',
    { text: 'when is my birthday?' },
    ORIGIN,
    local,
  )
  const answer = (await second.json()) as {
    assistantMessage: { content: string }
    web?: unknown
  }
  expect(answer.assistantMessage.content).toContain('30 October')
  expect(answer.web).toBeUndefined()
  expect(turns).toHaveLength(1)

  // A correction replaces the old value instead of sitting beside it.
  await call(
    '/api/chat',
    'omar',
    'POST',
    { text: 'actually my birthday is 31 October' },
    ORIGIN,
    local,
  )
  const corrected = await call(
    '/api/chat',
    'omar',
    'POST',
    { text: 'when is my birthday?' },
    ORIGIN,
    local,
  )
  expect(
    ((await corrected.json()) as { assistantMessage: { content: string } })
      .assistantMessage.content,
  ).toContain('31 October')

  const state = (await (
    await call('/api/state', 'omar', 'GET', undefined, ORIGIN, local)
  ).json()) as StateBody
  expect(state.facts?.map((fact) => [fact.slot, fact.value])).toEqual([
    ['birthday', '31 October'],
  ])

  // The person can forget a fact too.
  expect(
    (await call('/api/facts/birthday', 'omar', 'DELETE', undefined, ORIGIN, local))
      .status,
  ).toBe(200)
  expect(
    (await call('/api/facts/shoe-size', 'omar', 'DELETE', undefined, ORIGIN, local))
      .status,
  ).toBe(400)
})

test('a spoken turn asks the model for a short, readable-out-loud answer', async () => {
  const seen: { voice?: boolean }[] = []
  const model: AiClient = async (request) => {
    seen.push({ voice: request.voice })
    return { reply: 'Paris.', rules: [], model: 'fake-model' }
  }
  const local = createApp(
    async (request) =>
      request.headers.get('test-user') ? { sub: 'pia' } : null,
    model,
    async () => null,
  )
  await call(
    '/api/chat',
    'pia',
    'POST',
    { text: 'what is the capital of France', voice: true },
    ORIGIN,
    local,
  )
  expect(seen).toEqual([{ voice: true }])
})

test('speech asks for a key before it calls the voice model', async () => {
  const local = createApp(
    async (request) =>
      request.headers.get('test-user') ? { sub: 'zoe' } : null,
    fakeAi,
    async () => null,
  )
  const noKey: Env = { ...env, GEMINI_API_KEY: undefined }
  expect(
    (
      await call('/api/speech', 'zoe', 'POST', { text: '   ' }, ORIGIN, local, noKey)
    ).status,
  ).toBe(400)
  // A keyless account is told why, not handed a broken audio file.
  expect(
    (
      await call('/api/speech', 'zoe', 'POST', { text: 'hello' }, ORIGIN, local, noKey)
    ).status,
  ).toBe(503)
  expect(
    (
      await call(
        '/api/speech',
        'zoe',
        'POST',
        { text: 'hello' },
        'https://evil.example',
        local,
        noKey,
      )
    ).status,
  ).toBe(403)
})

test('voice settings persist and are clamped to sane values', async () => {
  const saved = await call('/api/settings', 'vera', 'PUT', {
    voiceEngine: 'device',
    neuralVoice: 'Puck',
    voiceVolume: 4,
  })
  expect(saved.status).toBe(200)
  const body = (await saved.json()) as {
    settings: { voiceEngine: string; neuralVoice: string; voiceVolume: number }
  }
  expect(body.settings.voiceEngine).toBe('device')
  expect(body.settings.neuralVoice).toBe('Puck')
  expect(body.settings.voiceVolume).toBe(1)

  const state = (await (await call('/api/state', 'vera')).json()) as StateBody
  expect(state.settings.voiceVolume).toBe(1)
  expect(state.settings.voiceEngine).toBe('device')

  // Unknown voices and engines fall back instead of poisoning the settings.
  const reset = await call('/api/settings', 'vera', 'PUT', {
    voiceEngine: 'telepathy',
    neuralVoice: 'Nobody',
    voiceVolume: -2,
  })
  const fallback = (await reset.json()) as {
    settings: { voiceEngine: string; neuralVoice: string; voiceVolume: number }
  }
  expect(fallback.settings.voiceEngine).toBe('neural')
  expect(fallback.settings.neuralVoice).toBe('Charon')
  expect(fallback.settings.voiceVolume).toBe(0)
})
