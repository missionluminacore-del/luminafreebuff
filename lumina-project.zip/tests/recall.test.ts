import { describe, expect, test } from 'bun:test'
import { extractFacts, parseBirthday, recallAnswer } from '../src/worker/recall'

const factsOf = (text: string) =>
  Object.fromEntries(extractFacts(text).map((fact) => [fact.slot, fact.value]))

describe('birthdays in every shape a person types them', () => {
  test('day first, month first, numeric and with a year', () => {
    expect(parseBirthday('30 October')).toBe('30 October')
    expect(parseBirthday('my birthday is october 30')).toBe('30 October')
    expect(parseBirthday('30th of October 1998')).toBe('30 October 1998')
    expect(parseBirthday('born 30/10')).toBe('30 October')
    expect(parseBirthday('10-30-1998')).toBe('30 October 1998')
    expect(parseBirthday('on the 3rd of March')).toBe('3 March')
  })

  test('nonsense is refused instead of guessed', () => {
    expect(parseBirthday('sometime in spring')).toBeNull()
    expect(parseBirthday('tomorrow')).toBeNull()
    expect(parseBirthday('99/99')).toBeNull()
  })
})

describe('facts are read from natural statements', () => {
  test('name, city, work', () => {
    expect(factsOf('my name is zayan and i live in pune')).toEqual({
      name: 'Zayan',
      city: 'Pune',
    })
    expect(factsOf('call me Sam')).toEqual({ name: 'Sam' })
    expect(factsOf('i work as a designer at Figma')).toEqual({
      job: 'designer',
      company: 'Figma',
    })
    expect(factsOf("i'm 24 years old")).toEqual({ age: '24' })
  })

  test('a birthday statement survives the trip through another note', () => {
    expect(factsOf('my birthday is 30 October')).toEqual({
      birthday: '30 October',
    })
    expect(factsOf("i was born on 30 october 1998")).toEqual({
      birthday: '30 October 1998',
    })
  })

  test('chatter is not a fact', () => {
    expect(extractFacts('that was a good movie')).toEqual([])
    expect(extractFacts('my name is not important')).toEqual([])
  })
})

describe('questions are answered from facts, statements are not', () => {
  const facts = [
    { slot: 'name' as const, value: 'Zayan', updatedAt: 0 },
    { slot: 'birthday' as const, value: '30 October', updatedAt: 0 },
    { slot: 'city' as const, value: 'Pune', updatedAt: 0 },
  ]

  test('direct answers use the stored value', () => {
    expect(recallAnswer('when is my birthday?', facts)).toContain('30 October')
    expect(recallAnswer("what's my name", facts)).toBe('You are Zayan, sir.')
    expect(recallAnswer('where do i live', facts)).toBe('You are in Pune, sir.')
  })

  test('a statement is stored, not answered', () => {
    expect(recallAnswer('my birthday is 30 October', facts)).toBeNull()
    expect(recallAnswer('i live in Pune', facts)).toBeNull()
    expect(recallAnswer('my name is Zayan', facts)).toBeNull()
  })

  test('every way of asking the same thing is answered', () => {
    for (const ask of [
      'when is my birthday',
      'when is my birthday?',
      'remind me what my birthday is',
      'whats my bday again',
      'do you remember my birthday',
    ])
      expect(recallAnswer(ask, facts) ?? '').toContain('30 October')
  })

  test('an unknown fact is admitted, never invented', () => {
    const bare = recallAnswer('when is my birthday?', [])
    expect(bare).toContain('on file')
    expect(bare).not.toContain('2026')
    expect(recallAnswer('how old am i', [])).toContain('on file')
  })

  test('what do you remember lists what is actually stored', () => {
    const answer = recallAnswer('what do you remember about me?', facts) ?? ''
    expect(answer).toContain('Zayan')
    expect(answer).toContain('30 October')
    expect(recallAnswer('what do you remember about me?', [])).toContain(
      'Nothing on file',
    )
  })

  test('unrelated questions are left to the model', () => {
    expect(recallAnswer('what is the weather in Pune', facts)).toBeNull()
    expect(recallAnswer('explain photosynthesis', facts)).toBeNull()
  })
})
