import { describe, expect, test } from 'bun:test'
import { describeBrain, generate, replyPrefix, targetsFor } from '../src/worker/ai'

describe('streamed JSON is readable before it closes', () => {
  test('the reply is decoded from a partial object', () => {
    expect(replyPrefix('{"reply":"Good evening')).toBe('Good evening')
    expect(replyPrefix('{"reply":"One\\ntwo')).toBe('One\ntwo')
    expect(replyPrefix('{"reply":"A \\"quote\\" here')).toBe('A "quote" here')
    expect(replyPrefix('{"rules":[]}')).toBe('')
  })

  test('a half-written escape is not emitted as garbage', () => {
    expect(replyPrefix('{"reply":"wait \\')).toBe('wait ')
    expect(replyPrefix('{"reply":"emoji \\u26')).toBe('emoji ')
    expect(replyPrefix('{"reply":"done\\u0021"')).toBe('done!')
  })
})

describe('which model answers', () => {
  const gemini = { gemini: 'AIza-key' }

  test('Gemini is the only provider, with its fallbacks', () => {
    const targets = targetsFor({ keys: gemini, history: [], rules: [] })
    expect(targets[0]).toMatchObject({
      provider: 'gemini',
      model: 'gemini-flash-lite-latest',
    })
    expect(targets.every((target) => target.provider === 'gemini')).toBe(true)
    expect(targets.length).toBeGreaterThan(1)
  })

  test('a configured model override leads the queue', () => {
    const targets = targetsFor({
      keys: gemini,
      geminiModel: 'gemini-3.6-flash',
      history: [],
      rules: [],
    })
    expect(targets[0]?.model).toBe('gemini-3.6-flash')
  })

  test('no key means no attempts', () => {
    expect(targetsFor({ keys: {}, history: [], rules: [] })).toHaveLength(0)
  })

  test('the settings summary names the model', () => {
    expect(describeBrain(gemini, 'auto')).toEqual({
      provider: 'gemini',
      model: 'gemini-flash-lite-latest',
      fallback: false,
    })
    expect(describeBrain({}, 'auto')).toEqual({
      provider: 'none',
      model: 'none',
      fallback: false,
    })
  })
})

test('a Gemini turn never sends additionalProperties, which it rejects', async () => {
  const original = globalThis.fetch
  let sent: Record<string, unknown> | null = null
  globalThis.fetch = (async (_input: RequestInfo | URL, init?: RequestInit) => {
    sent = JSON.parse(String(init?.body ?? '{}'))
    return new Response(
      JSON.stringify({
        candidates: [
          {
            content: {
              parts: [
                {
                  text: JSON.stringify({
                    reply: 'From Gemini.',
                    rules: [],
                    memories: [],
                  }),
                },
              ],
            },
          },
        ],
      }),
      { status: 200, headers: { 'content-type': 'application/json' } },
    )
  }) as typeof fetch

  try {
    const reply = await generate({
      keys: { gemini: 'AIza-test' },
      history: [{ role: 'user', text: 'hi' }],
      rules: [],
    })
    expect(reply.reply).toBe('From Gemini.')
    const body = JSON.stringify(sent)
    expect(body).toContain('responseSchema')
    expect(body).not.toContain('additionalProperties')
  } finally {
    globalThis.fetch = original
  }
})

test('a rejected key fails fast instead of trying every model', async () => {
  const original = globalThis.fetch
  let calls = 0
  globalThis.fetch = (async () => {
    calls += 1
    return new Response(
      JSON.stringify({
        error: { code: 400, message: 'API key not valid. Please pass a valid API key.' },
      }),
      { status: 400, headers: { 'content-type': 'application/json' } },
    )
  }) as unknown as typeof fetch

  try {
    await expect(
      generate({
        keys: { gemini: 'AIza-broken' },
        history: [{ role: 'user', text: 'hi' }],
        rules: [],
      }),
    ).rejects.toThrow(/API key/)
    expect(calls).toBe(1)
  } finally {
    globalThis.fetch = original
  }
})

test('a rate-limited model hands over to the next Gemini model', async () => {
  const original = globalThis.fetch
  const models: string[] = []
  globalThis.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
    expect(String(input)).toContain('generativelanguage.googleapis.com')
    const body = JSON.parse(String(init?.body ?? '{}'))
    models.push(body.model ?? '')
    if (models.length === 1)
      return new Response(JSON.stringify({ error: { message: 'rate limited' } }), {
        status: 429,
        headers: { 'content-type': 'application/json' },
      })
    return new Response(
      JSON.stringify({
        candidates: [
          {
            content: {
              parts: [
                {
                  text: JSON.stringify({
                    reply: 'Second model answered.',
                    rules: [],
                    memories: [],
                  }),
                },
              ],
            },
          },
        ],
      }),
      { status: 200, headers: { 'content-type': 'application/json' } },
    )
  }) as typeof fetch

  try {
    const reply = await generate({
      keys: { gemini: 'AIza-test' },
      history: [{ role: 'user', text: 'hi' }],
      rules: [],
    })
    expect(reply.reply).toBe('Second model answered.')
    expect(models.length).toBe(2)
  } finally {
    globalThis.fetch = original
  }
})
