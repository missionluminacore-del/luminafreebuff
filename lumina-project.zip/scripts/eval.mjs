#!/usr/bin/env bun
/**
 * Answer-quality evaluation for the assistant contract.
 *
 * Runs a small golden set through the real model, checks hard expectations
 * (required and forbidden phrases), then has a second model score each answer
 * against its rubric. Prompt changes are compared by this score, not by
 * intuition.
 *
 *   GEMINI_API_KEY=... bun run eval
 *   bun run eval -- --model gemini-3.5-flash --verbose
 *
 * Without a key in the environment the local development database is used.
 * This is a manual tool: it is never part of the test suite.
 */
import { Database } from 'bun:sqlite'
import { readFileSync, existsSync } from 'node:fs'
import { generate } from '../src/worker/ai.ts'

const args = process.argv.slice(2)
const flag = (name) => {
  const index = args.indexOf(`--${name}`)
  return index >= 0 ? args[index + 1] : undefined
}
const verbose = args.includes('--verbose')
const model = flag('model')
const threshold = Number(flag('threshold') ?? 3.5)

const localKey = () => {
  const path =
    '.wrangler/state/v3/d1/miniflare-D1DatabaseObject/' +
    '9ba2b04bf514d9facfd57ed57d849e77241a7adc99d1c1545d06688b43d84248.sqlite'
  if (!existsSync(path)) return ''
  try {
    const database = new Database(path, { readonly: true })
    const row = database.query('select gemini_key from api_keys limit 1').get()
    return row?.gemini_key?.trim() ?? ''
  } catch {
    return ''
  }
}

const key = process.env.GEMINI_API_KEY?.trim() || localKey()
if (!key) {
  console.error(
    'No Gemini key. Set GEMINI_API_KEY or sign in once in the local app.',
  )
  process.exit(2)
}

const cases = JSON.parse(
  readFileSync(new URL('../evals/cases.json', import.meta.url), 'utf8'),
)

const judge = async (prompt, reply, rubric) => {
  const response = await fetch(
    'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({
        systemInstruction: {
          parts: [
            {
              text: 'You are a strict evaluator of an assistant reply. Score 1-5 for how well it meets the rubric: 5 is excellent and unremarkable, 3 is acceptable, 1 is wrong or off-contract. Judge only the reply against the rubric, not the user message. Answer with JSON only.',
            },
          ],
        },
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: `RUBRIC: ${rubric}\n\nUSER MESSAGE: ${prompt}\n\nASSISTANT REPLY:\n${reply}`,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0,
          responseMimeType: 'application/json',
          responseSchema: {
            type: 'object',
            properties: {
              score: { type: 'number' },
              note: { type: 'string' },
            },
            required: ['score', 'note'],
          },
        },
      }),
      signal: AbortSignal.timeout(30_000),
    },
  )
  if (!response.ok) return { score: 0, note: `judge HTTP ${response.status}` }
  const data = await response.json()
  const text = (data?.candidates?.[0]?.content?.parts ?? [])
    .map((part) => part.text ?? '')
    .join('')
  try {
    const parsed = JSON.parse(text)
    return {
      score: Math.max(0, Math.min(5, Number(parsed.score) || 0)),
      note: String(parsed.note ?? '').slice(0, 200),
    }
  } catch {
    return { score: 0, note: 'judge returned unparseable JSON' }
  }
}

let total = 0
let failures = 0
const rows = []

for (const testCase of cases) {
  const started = Date.now()
  let reply = ''
  let error = ''
  try {
    const answer = await generate({
      keys: { gemini: key },
      geminiModel: model,
      history: [{ role: 'user', text: testCase.prompt }],
      rules: [],
      voice: testCase.voice === true,
    })
    reply = answer.reply
  } catch (failure) {
    error = failure instanceof Error ? failure.message : String(failure)
  }

  const lower = reply.toLowerCase()
  const missing = (testCase.expect ?? []).filter(
    (phrase) => !lower.includes(String(phrase).toLowerCase()),
  )
  const forbidden = (testCase.avoid ?? []).filter((phrase) =>
    lower.includes(String(phrase).toLowerCase()),
  )
  const graded = error
    ? { score: 0, note: error }
    : await judge(testCase.prompt, reply, testCase.rubric)
  // A judge that could not answer is a broken measurement, not a pass.
  const judgeBroken = /^judge HTTP/.test(graded.note)
  const hardFail =
    Boolean(error) || judgeBroken || missing.length > 0 || forbidden.length > 0
  if (hardFail) failures += 1
  total += graded.score
  rows.push({
    id: testCase.id,
    score: graded.score,
    hardFail,
    missing,
    forbidden,
    ms: Date.now() - started,
    note: graded.note,
    reply,
  })
  const mark = hardFail ? 'FAIL' : 'ok  '
  console.log(
    `${mark} ${testCase.id.padEnd(22)} ${String(graded.score).padStart(2)}/5  ${rows.at(-1).ms}ms  ${graded.note}`,
  )
  if (verbose) console.log(`\n${reply}\n${'-'.repeat(70)}`)
}

const average = total / rows.length
console.log(
  `\n${rows.length} cases · average ${average.toFixed(2)}/5 · ${failures} hard failure${failures === 1 ? '' : 's'}`,
)
process.exit(failures > 0 || average < threshold ? 1 : 0)
