# Lumina

A small private assistant you can reach from your phone, laptop and PC: talk to
it out loud, and it remembers what it is told and what it is taught.

- **Brain** — Gemini over plain REST, server-side only. The key is pasted once
  in Settings, stored per account and never sent back to a browser. When a
  model is rate limited the next Gemini model answers, so the chat keeps going
  on the free tier. Set `GEMINI_MODEL` to lead with a different model.
- **Voice** — browser speech recognition turns your voice into text (the audio
  never leaves the device); Gemini's audio model renders the reply as real
  speech (`/api/speech`), with the device's own voices as a fallback. Choose the
  engine, the neural voice and the volume in Settings. Click the core for a live
  conversation: it listens, sends when you stop talking, speaks the answer and
  opens the mic again, hands-free, until you stop it. Interrupting cuts the audio
  mid-sentence and returns to listening. Spoken replies are kept short and
  stripped of Markdown before they are read out.
- **Interface** — one fullscreen instrument, not a chat page: a silk ribbon
  swept into a closed, breathing loop, drawn live with Three.js shaders
  (`src/client/core.ts`). Its spine drifts on several harmonics, its width
  breathes and its face twists as it travels, shaded with a two-light sheen and
  fine filaments. It never repeats frame to frame. States are driven by real
  signal — microphone amplitude while listening, the synthesizer's word
  boundaries while speaking — plus thinking, idle and a short interference
  burst on error.
- **Chat** — the home screen always opens empty, so an old conversation is never
  left sitting there. `type` opens the text field, the latest exchange floats
  over the core, `chat` opens the whole conversation and `history` lists past
  sessions (opening one shows its full transcript). Clicking the core is still
  the fastest way in: it starts a hands-free voice conversation.
- **Memory** — three layers.
  *Facts* are personal details stated out loud ("my birthday is 30 October"):
  name, birthday, age, city, job and workplace, held in one slot each, so a
  correction replaces the old value. A question about them never reaches a
  model — it is answered from the database in milliseconds and cannot be
  invented.
  *Notes* are everything else worth keeping: people, projects, preferences.
  *Rules* are how it works, learned from corrections ("keep it to two lines").
  All of it is listed in Memory, can be added or forgotten by hand, and exports
  as Markdown.
- **Live web** — every message checks the web before the model answers (search
  results, recent headlines, plus exact weather and crypto readings), started in
  parallel with the database and cached for 90 seconds. Nothing suppresses the
  check: every turn looks, and only the wait is bounded — 7 s when the message
  asks about facts, 1.5 s otherwise. If the lookup returns nothing usable the
  prompt says so, so the reply admits the gap instead of inventing. Each reply
  shows the small *Checked the web · N sources*
  line, and a chip naming the model that answered with its latency, so nothing
  is pretending.

## Run it

```sh
bun install
bun run dev     # http://localhost:5173
bun run test
bun run typecheck
bun run build
```

The app needs a Gemini key (https://aistudio.google.com/apikey). Paste it in
**Settings → Brain** after signing in; it is stored for the account in D1 and
read only on the server. Alternatively copy `.env.example` to `.dev.vars` and
set `GEMINI_API_KEY` as a server-wide key. Without a key the UI loads, shows an
"add your key" banner and chat requests answer 503.

## Signing in

Lumina has one private owner, not a sign-up flow. The credentials come from
project secrets — `LUMINA_USER_ID` (defaults to `lumina`) and
`LUMINA_PASSWORD` — and are checked on the server; a successful login sets an
HttpOnly, HMAC-signed cookie that lasts 30 days. Set `LUMINA_SESSION_SECRET` to
a random value so rotating the password does not depend on the old one. None of
these are bundled into the browser, shown in the UI or written to the database.
Locally they go in `.dev.vars` (git-ignored); on Sites they go in Settings →
Secrets. Without `LUMINA_PASSWORD` the login route answers 503 rather than
falling back to a built-in password.

The interface is deliberately monochrome and dark: pure black, white and grey
with rare red interference. A stored `theme` setting from earlier versions is
kept in the database but no longer changes the visuals.

## Layout

- `src/client/main.tsx` — core console, live conversation loop, memory, settings.
- `src/client/core.ts` — the Three.js core: shaders, rings, streams, particles.
- `src/client/mic.ts` — microphone amplitude analyser for the core.
- `src/client/audio.ts` — neural speech playback: PCM to AudioBuffer, volume,
  real amplitude for the core, clean interruption.
- `src/client/speech.ts` — recognition plus the device-voice fallback, chunked
  speech, text cleanup, spoken cadence.
- `src/client/markdown.tsx` — small element-based Markdown renderer for replies.
- `src/worker/app.ts` — API routes, authorization, ownership checks and recall.
- `src/worker/ai.ts` — provider clients, prompt, schema, model fallbacks.
- `src/worker/recall.ts` — fact extraction and exact answers about the person.
- `src/worker/web.ts` — live lookup: search, news, weather, prices, relevance.
- `src/worker/db.ts` — D1 schema and row mapping.
- `src/shared/types.ts` — types plus settings defaults/validation.

Text is capped at 60000 characters, prompt context at the last 60 messages,
200 rules and 400 notes (the 60 most relevant reach the prompt). Every query
binds parameters and filters by the caller's `sub`; mutations reject foreign
origins and all API responses are `private, no-store`.

## Publishing

1. `sites_create` for the target environment.
2. `sites_add_storage` with kind `d1` and name `DB`.
3. Optional: `sites_set_secret` with `GEMINI_API_KEY` as a server-wide key.
   The owner can also paste the key in Settings.
4. `sites_deploy` with `deploy.json`.

`deploy.json` points at the single Worker module and the `dist/client` assets.
No third-party auth provider is needed: the login is handled by the Worker.
